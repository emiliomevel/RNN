#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Entrena en PC una LSTM de 250 pasos y exporta pesos compatibles con el S32K312.
Arquitectura: LSTM(3 -> 8) -> Dense(8)+ReLU -> Dense(5 logits).
Entrada equivalente al firmware: q=clip(round(p*200), 0, 255), x=q/200,
normalización por canal con media/desviación del conjunto train.
Entrada esperada en --datos:
  dataset_train.csv, dataset_val.csv, dataset_test.csv
Columnas CSV: sample_id,timestamp_ms,p1,p2,p3,label
Cada sample_id es una secuencia de 250 filas (si tiene más se toman las primeras
250 por timestamp; si tiene menos se detiene con error).
Salidas:
  lstm_weights.h        Header C para inferencia con pesos en Flash
  lstm_weights.npz      Pesos, normalización y dimensiones
  modelo_lstm_pc.pt     Checkpoint PyTorch
  metricas.json         Métricas finales del conjunto test
  curvas_entrenamiento.csv / curvas_entrenamiento.png
  matriz_confusion_test.csv / matriz_confusion_test.png
"""
from __future__ import annotations
import argparse
import copy
import json
import os
import random
import time
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F
ESCALA_ENTRADA = 200.0
M = 3
H = 8
D = 8
C = 5
G = 4 * H
NOMBRES_CLASE = {
    0: "0 STOP/otros",
    1: "1 Av.Rapido",
    2: "2 Av.Lento",
    3: "3 Rev.Rapida",
    4: "4 Rev.Lenta",
}
class ClasificadorLSTM(nn.Module):
    """Arquitectura equivalente a RNN_Forward()/RNN_InferWindow() en C."""
    def __init__(self, hidden: int = H, dense: int = D):
        super().__init__()
        self.rnn = nn.LSTM(input_size=M, hidden_size=hidden, batch_first=True)
        self.fc1 = nn.Linear(hidden, dense)
        self.fc2 = nn.Linear(dense, C)
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        salidas, _ = self.rnn(x)
        h_final = salidas[:, -1, :]
        return self.fc2(F.relu(self.fc1(h_final)))
def cargar_csv(ruta: Path, pasos: int, factor: int = 1) -> tuple[np.ndarray, np.ndarray]:
    """Carga secuencias y conserva una de cada `factor` muestras temporales."""
    if factor < 1:
        raise ValueError("El factor de submuestreo debe ser >= 1")
    if not ruta.exists():
        raise FileNotFoundError(f"No encuentro {ruta}")
    df = pd.read_csv(ruta)
    requeridas = {"sample_id", "timestamp_ms", "p1", "p2", "p3", "label"}
    faltan = requeridas.difference(df.columns)
    if faltan:
        raise ValueError(f"{ruta.name}: faltan columnas {sorted(faltan)}")
    df = df.sort_values(["sample_id", "timestamp_ms"], kind="stable")
    X_lista: list[np.ndarray] = []
    y_lista: list[int] = []
    longitudes: list[int] = []
    columnas = ["p1", "p2", "p3"]
    for sample_id, bloque in df.groupby("sample_id", sort=False):
        n = len(bloque)
        filas_requeridas = pasos * factor
        if n < filas_requeridas:
            raise ValueError(
                f"{ruta.name}: sample_id={sample_id} tiene {n} filas; para pasos={pasos} "
                f"y factor={factor} se requieren al menos {filas_requeridas}. "
                "Verifica que el CSV tenga secuencias completas."
            )
        if bloque["label"].nunique(dropna=False) != 1:
            raise ValueError(f"{ruta.name}: sample_id={sample_id} contiene más de una etiqueta")
        # Submuestreo temporal: factor=4 conserva filas 0, 4, 8, 12, ...
        # Se seleccionan los pasos después del submuestreo.
        bloque = bloque.iloc[::factor].iloc[:pasos]
        valores = bloque[columnas].to_numpy(dtype=np.float32)
        if not np.isfinite(valores).all():
            raise ValueError(f"{ruta.name}: NaN/Inf en sample_id={sample_id}")
        etiqueta = int(bloque["label"].iloc[0])
        if etiqueta not in range(C):
            raise ValueError(f"{ruta.name}: etiqueta {etiqueta} fuera de 0..{C-1}")
        X_lista.append(valores)
        y_lista.append(etiqueta)
        longitudes.append(n)
    if not X_lista:
        raise ValueError(f"{ruta.name}: no contiene secuencias")
    X = np.stack(X_lista).astype(np.float32)
    y = np.asarray(y_lista, dtype=np.int64)
    extra = sum(max(0, n - pasos * factor) for n in longitudes)
    if extra:
        print(f"[INFO] {ruta.name}: se ignoraron {extra} filas posteriores a las primeras {pasos * factor} filas consideradas.")
    return X, y
def cuantizar_como_firmware(X: np.ndarray) -> np.ndarray:
    """Equivale a clip(round(valor*200),0,255) y almacena uint8."""
    return np.clip(np.rint(X * ESCALA_ENTRADA), 0, 255).astype(np.uint8)
def preparar_datos(datos_dir: Path, pasos: int, factor: int):
    crudos = {
        nombre: cargar_csv(datos_dir / f"dataset_{nombre}.csv", pasos, factor)
        for nombre in ("train", "val", "test")
    }
    q = {k: cuantizar_como_firmware(X) for k, (X, _) in crudos.items()}
    y = {k: labels for k, (_, labels) in crudos.items()}
    # La normalización se calcula SOLO con train y sobre el dato ya cuantizado,
    # igual que hace el firmware al dividir q entre RNN_INPUT_SCALE.
    train_dequant = q["train"].astype(np.float32) / np.float32(ESCALA_ENTRADA)
    media = train_dequant.mean(axis=(0, 1), dtype=np.float64).astype(np.float32)
    desv = train_dequant.std(axis=(0, 1), dtype=np.float64).astype(np.float32)
    desv = np.where(desv < 1.0e-6, 1.0, desv).astype(np.float32)
    Xn = {
        k: ((q[k].astype(np.float32) / np.float32(ESCALA_ENTRADA) - media) / desv).astype(np.float32)
        for k in q
    }
    for k in ("train", "val", "test"):
        faltantes = sorted(set(range(C)) - set(np.unique(y[k]).tolist()))
        if faltantes:
            print(f"[AVISO] {k} no contiene clases {faltantes}; las métricas por clase pueden ser poco representativas.")
        print(f"{k:5s}: X={Xn[k].shape}, distribución={dict(zip(*np.unique(y[k], return_counts=True)))}")
    print("Media de normalización:", np.round(media, 6))
    print("Desv. de normalización:", np.round(desv, 6))
    return Xn, y, media, desv, q
def evaluar(modelo, X: np.ndarray, y: np.ndarray, device: torch.device, batch: int):
    modelo.eval()
    xt = torch.from_numpy(X)
    yt = torch.from_numpy(y)
    criterio = nn.CrossEntropyLoss(reduction="sum")
    perdida_total = 0.0
    predicciones: list[np.ndarray] = []
    with torch.no_grad():
        for inicio in range(0, len(X), batch):
            xb = xt[inicio:inicio + batch].to(device)
            yb = yt[inicio:inicio + batch].to(device)
            logits = modelo(xb)
            perdida_total += float(criterio(logits, yb).item())
            predicciones.append(logits.argmax(dim=1).cpu().numpy())
    pred = np.concatenate(predicciones) if predicciones else np.array([], dtype=np.int64)
    return perdida_total / max(1, len(y)), pred
def convertir_pesos(modelo: ClasificadorLSTM) -> dict[str, np.ndarray]:
    sd = {k: v.detach().cpu().numpy().astype(np.float32) for k, v in modelo.state_dict().items()}
    # PyTorch y el C del proyecto usan el mismo orden de compuertas: i, f, g, o.
    return {
        "w_ih": sd["rnn.weight_ih_l0"],
        "w_hh": sd["rnn.weight_hh_l0"],
        # En C se almacena un solo sesgo: bias_ih + bias_hh.
        "b": (sd["rnn.bias_ih_l0"] + sd["rnn.bias_hh_l0"]).astype(np.float32),
        "w1": sd["fc1.weight"],
        "b1": sd["fc1.bias"],
        "w2": sd["fc2.weight"],
        "b2": sd["fc2.bias"],
    }
def probabilidades_c_equivalente(P: dict[str, np.ndarray], media: np.ndarray,
                                  desv: np.ndarray, Xq: np.ndarray) -> np.ndarray:
    """Forward float32 con las mismas ecuaciones y dimensiones que el C del S32K312."""
    x = ((Xq.astype(np.float32) / np.float32(ESCALA_ENTRADA)) - media) / desv
    n, pasos, _ = x.shape
    probs = np.empty((n, C), dtype=np.float32)
    for bidx in range(n):
        h = np.zeros(H, dtype=np.float32)
        c = np.zeros(H, dtype=np.float32)
        for t in range(pasos):
            pre = P["w_ih"] @ x[bidx, t] + P["w_hh"] @ h + P["b"]
            gi = (1.0 / (1.0 + np.exp(-pre[:H]))).astype(np.float32)
            gf = (1.0 / (1.0 + np.exp(-pre[H:2*H]))).astype(np.float32)
            gg = np.tanh(pre[2*H:3*H]).astype(np.float32)
            go = (1.0 / (1.0 + np.exp(-pre[3*H:4*H]))).astype(np.float32)
            c = gf * c + gi * gg
            h = (go * np.tanh(c)).astype(np.float32)
        d1 = np.maximum(P["w1"] @ h + P["b1"], 0.0).astype(np.float32)
        logits = (P["w2"] @ d1 + P["b2"]).astype(np.float32)
        logits -= logits.max()
        e = np.exp(logits).astype(np.float32)
        probs[bidx] = e / e.sum()
    return probs
def c_float(valor: float) -> str:
    s = format(float(np.float32(valor)), ".9g")
    if "." not in s and "e" not in s.lower():
        s += ".0"
    return s + "f"
def escribir_array_c(f, nombre: str, arreglo: np.ndarray) -> None:
    a = np.asarray(arreglo, dtype=np.float32)
    dims = "".join(f"[{n}]" for n in a.shape)
    if a.ndim == 1:
        contenido = "{" + ", ".join(c_float(v) for v in a) + "}"
    elif a.ndim == 2:
        filas = ["    {" + ", ".join(c_float(v) for v in fila) + "}" for fila in a]
        contenido = "{\n" + ",\n".join(filas) + "\n}"
    else:
        raise ValueError("Solo se admiten arreglos C de 1 o 2 dimensiones")
    f.write(f"static const float {nombre}{dims} = {contenido};\n\n")
def exportar_header(ruta: Path, P: dict[str, np.ndarray], media: np.ndarray,
                    desv: np.ndarray, pasos: int) -> None:
    """Exporta símbolos LSTM_* y alias LSTM_BASE_* usados por las variantes de firmware."""
    with ruta.open("w", encoding="utf-8", newline="\n") as f:
        f.write("""#ifndef LSTM_WEIGHTS_H
#define LSTM_WEIGHTS_H
/* Generado por entrenar_lstm_pc_T250.py. No editar manualmente.
 * Arquitectura: LSTM(3->8) + Dense(8)+ReLU + Dense(5).
 * Entrada: q=clip(round(p*200),0,255), luego q/200 y normalizacion.
 * Compuertas LSTM en orden i, f, g, o. El C usa un sesgo b=b_ih+b_hh.
 */
""")
        f.write(f"#define LSTM_BASE_M {M}U\n#define LSTM_BASE_H {H}U\n#define LSTM_BASE_D {D}U\n")
        f.write(f"#define LSTM_BASE_C {C}U\n#define LSTM_BASE_G {G}U\n#define LSTM_BASE_T {pasos}U\n\n")
        escribir_array_c(f, "LSTM_MEAN", media)
        escribir_array_c(f, "LSTM_STD", desv)
        escribir_array_c(f, "LSTM_W_IH", P["w_ih"])
        escribir_array_c(f, "LSTM_W_HH", P["w_hh"])
        escribir_array_c(f, "LSTM_B", P["b"])
        escribir_array_c(f, "LSTM_W1", P["w1"])
        escribir_array_c(f, "LSTM_B1", P["b1"])
        escribir_array_c(f, "LSTM_W2", P["w2"])
        escribir_array_c(f, "LSTM_B2", P["b2"])
        f.write("""/* Aliases para el firmware que usa prefijo LSTM_BASE_. */
#define LSTM_BASE_MEAN LSTM_MEAN
#define LSTM_BASE_STD LSTM_STD
#define LSTM_BASE_W_IH LSTM_W_IH
#define LSTM_BASE_W_HH LSTM_W_HH
#define LSTM_BASE_B LSTM_B
#define LSTM_BASE_W1 LSTM_W1
#define LSTM_BASE_B1 LSTM_B1
#define LSTM_BASE_W2 LSTM_W2
#define LSTM_BASE_B2 LSTM_B2
#endif /* LSTM_WEIGHTS_H */
""")
def matriz_confusion(y: np.ndarray, pred: np.ndarray) -> np.ndarray:
    cm = np.zeros((C, C), dtype=np.int64)
    for real, estimada in zip(y, pred):
        if 0 <= int(real) < C and 0 <= int(estimada) < C:
            cm[int(real), int(estimada)] += 1
    return cm
def metricas(cm: np.ndarray) -> dict:
    cmf = cm.astype(np.float64)
    tp = np.diag(cmf)
    soporte = cmf.sum(axis=1)
    pred_tot = cmf.sum(axis=0)
    precision = np.divide(tp, pred_tot, out=np.zeros(C), where=pred_tot > 0)
    recall = np.divide(tp, soporte, out=np.zeros(C), where=soporte > 0)
    f1 = np.divide(2 * precision * recall, precision + recall,
                   out=np.zeros(C), where=(precision + recall) > 0)
    return {
        "accuracy": float(tp.sum() / max(1.0, cmf.sum())),
        "precision_macro": float(precision.mean()),
        "recall_macro": float(recall.mean()),
        "f1_macro": float(f1.mean()),
        "por_clase": {
            str(i): {"nombre": NOMBRES_CLASE[i], "precision": float(precision[i]),
                     "recall": float(recall[i]), "f1": float(f1[i]),
                     "soporte": int(soporte[i])}
            for i in range(C)
        },
        "matriz_confusion": cm.tolist(),
    }
def main() -> None:
    ap = argparse.ArgumentParser(description="Entrena una LSTM con submuestreo temporal opcional y exporta pesos C.")
    ap.add_argument("--datos", type=Path, default=Path("."), help="Carpeta con dataset_train.csv, dataset_val.csv y dataset_test.csv")
    ap.add_argument("--salida", type=Path, default=Path("resultados_pc_T250"), help="Carpeta de salida")
    ap.add_argument("--pasos", type=int, default=50, help="Número de pasos temporales que recibirá la LSTM")
    ap.add_argument("--factor", type=int, default=5, help="Submuestreo temporal: 1=todas las muestras, 2=una de cada 2, 4=una de cada 4, etc.")
    ap.add_argument("--epocas", type=int, default=200)
    ap.add_argument("--lote", type=int, default=16)
    ap.add_argument("--lr", type=float, default=0.01)
    ap.add_argument("--paciencia", type=int, default=30, help="Early stopping por pérdida de validación")
    ap.add_argument("--semilla", type=int, default=7)
    ap.add_argument("--hilos", type=int, default=4)
    ap.add_argument("--dispositivo", choices=("auto", "cpu", "cuda"), default="auto")
    args = ap.parse_args()
    if args.pasos < 1 or args.factor < 1 or args.epocas < 1 or args.lote < 1 or args.lr <= 0:
        ap.error("pasos, factor, épocas y lote deben ser positivos; lr debe ser mayor que cero")
    if H != 8 or D != 8 or C != 5:
        raise RuntimeError("Este exportador está hecho para el firmware LSTM(8)+Dense(8)+5 clases")
    random.seed(args.semilla)
    np.random.seed(args.semilla)
    torch.manual_seed(args.semilla)
    torch.set_num_threads(max(1, args.hilos))
    if args.dispositivo == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("Pediste --dispositivo cuda, pero PyTorch no detecta CUDA")
    device = torch.device("cuda" if args.dispositivo == "cuda" or (args.dispositivo == "auto" and torch.cuda.is_available()) else "cpu")
    args.salida.mkdir(parents=True, exist_ok=True)
    X, y, media, desv, Xq = preparar_datos(args.datos, args.pasos, args.factor)
    modelo = ClasificadorLSTM().to(device)
    criterio = nn.CrossEntropyLoss()
    optimizador = torch.optim.Adam(modelo.parameters(), lr=args.lr)
    rng = np.random.default_rng(args.semilla)
    hist: list[dict] = []
    mejor_loss = float("inf")
    mejor_epoca = 0
    mejor_estado = copy.deepcopy(modelo.state_dict())
    sin_mejora = 0
    inicio_total = time.perf_counter()
    Xtr_t = torch.from_numpy(X["train"])
    ytr_t = torch.from_numpy(y["train"])
    print(f"\nDispositivo: {device}")
    print(f"Modelo: LSTM({H}) + Dense({D}) + {C} clases; pasos={args.pasos}, factor={args.factor}")
    print(f"Frecuencia efectiva aproximada: {50.0 / args.factor:.3f} Hz; ventana aproximada: {args.pasos * args.factor / 50.0:.3f} s")
    print(f"Parámetros PyTorch entrenables: {sum(p.numel() for p in modelo.parameters())} (la exportación fusiona los dos sesgos LSTM)")
    print(f"Parámetros guardados en el formato C del micro: {G*M + G*H + G + D*H + D + C*D + C}")
    print("\nÉpoca | loss train | acc train | loss val | acc val | seg")
    for epoca in range(1, args.epocas + 1):
        t0 = time.perf_counter()
        modelo.train()
        orden = rng.permutation(len(Xtr_t))
        loss_suma = 0.0
        correctos = 0
        vistos = 0
        for inicio in range(0, len(orden), args.lote):
            idx_np = orden[inicio:inicio + args.lote]
            idx = torch.as_tensor(idx_np, dtype=torch.long)
            xb = Xtr_t[idx].to(device)
            yb = ytr_t[idx].to(device)
            optimizador.zero_grad(set_to_none=True)
            logits = modelo(xb)
            loss = criterio(logits, yb)
            loss.backward()
            nn.utils.clip_grad_norm_(modelo.parameters(), max_norm=1.0)
            optimizador.step()
            n_batch = len(idx_np)
            loss_suma += float(loss.item()) * n_batch
            correctos += int((logits.argmax(1) == yb).sum().item())
            vistos += n_batch
        loss_tr = loss_suma / max(1, vistos)
        acc_tr = correctos / max(1, vistos)
        loss_va, pred_va = evaluar(modelo, X["val"], y["val"], device, args.lote)
        acc_va = float(np.mean(pred_va == y["val"]))
        segundos = time.perf_counter() - t0
        hist.append({"epoca": epoca, "loss_train": loss_tr, "acc_train": acc_tr,
                     "loss_val": loss_va, "acc_val": acc_va, "segundos": segundos})
        if epoca == 1 or epoca % 5 == 0:
            print(f"{epoca:5d} | {loss_tr:10.4f} | {acc_tr:9.3f} | {loss_va:8.4f} | {acc_va:7.3f} | {segundos:5.1f}")
        if loss_va < mejor_loss - 1.0e-5:
            mejor_loss = loss_va
            mejor_epoca = epoca
            mejor_estado = copy.deepcopy(modelo.state_dict())
            sin_mejora = 0
        else:
            sin_mejora += 1
            if args.paciencia > 0 and sin_mejora >= args.paciencia:
                print(f"Early stopping: {args.paciencia} épocas sin mejora; mejor época={mejor_epoca}.")
                break
    modelo.load_state_dict(mejor_estado)
    tiempo_total = time.perf_counter() - inicio_total
    loss_test, pred_test = evaluar(modelo, X["test"], y["test"], device, args.lote)
    cm = matriz_confusion(y["test"], pred_test)
    resumen = metricas(cm)
    resumen.update({
        "loss_test": loss_test,
        "epoca_mejor_validacion": mejor_epoca,
        "loss_mejor_validacion": mejor_loss,
        "epocas_ejecutadas": len(hist),
        "tiempo_entrenamiento_segundos": tiempo_total,
        "pasos_por_secuencia": args.pasos,
        "factor_submuestreo": args.factor,
        "paso_temporal": args.factor,
        "frecuencia_origen_hz": 50,
        "frecuencia_efectiva_hz": 50.0 / args.factor,
        "ventana_aproximada_segundos": args.pasos * args.factor / 50.0,
        "arquitectura": {"M": M, "H": H, "D": D, "C": C, "G": G, "parametros_entrenables_pytorch": sum(p.numel() for p in modelo.parameters()), "parametros_exportados_formato_C": G*M + G*H + G + D*H + D + C*D + C},
        "normalizacion": {"escala_entrada": ESCALA_ENTRADA, "mean": media.tolist(), "std": desv.tolist()},
        "origen_datos": str(args.datos.resolve()),
        "nota_datos": "El script usa exactamente los CSV de train/val/test indicados; no detecta automáticamente datos sintéticos.",
    })
    P = convertir_pesos(modelo)
    # Comprueba que la conversión de pesos a las ecuaciones usadas por C no altera la predicción.
    p_c = probabilidades_c_equivalente(P, media, desv, Xq["test"])
    p_torch = []
    modelo.eval()
    with torch.no_grad():
        for ini in range(0, len(X["test"]), args.lote):
            logits = modelo(torch.from_numpy(X["test"][ini:ini + args.lote]).to(device))
            p_torch.append(torch.softmax(logits, dim=1).cpu().numpy())
    p_torch_np = np.concatenate(p_torch, axis=0)
    dif_max = float(np.max(np.abs(p_c - p_torch_np)))
    pred_c = p_c.argmax(axis=1)
    resumen["verificacion_exportacion"] = {
        "diferencia_maxima_probabilidades_torch_vs_forward_c": dif_max,
        "predicciones_identicas_test": bool(np.array_equal(pred_c, pred_test)),
    }
    if not np.array_equal(pred_c, pred_test):
        print("[AVISO] La validación numérica obtuvo alguna predicción distinta entre PyTorch y forward C-equivalente.")
    else:
        print(f"\nConversión de pesos verificada: predicciones idénticas; diferencia máxima de probabilidad={dif_max:.2e}")
    # Archivos de pesos: matrices y parámetros de normalización necesarios para el micro.
    ruta_npz = args.salida / "lstm_weights.npz"
    np.savez_compressed(
        ruta_npz, **P, mean=media.astype(np.float32), std=desv.astype(np.float32),
        M=np.array(M), H=np.array(H), D=np.array(D), C=np.array(C), G=np.array(G),
        T=np.array(args.pasos), factor_submuestreo=np.array(args.factor), escala=np.array(ESCALA_ENTRADA, dtype=np.float32),
    )
    ruta_h = args.salida / "lstm_weights.h"
    exportar_header(ruta_h, P, media, desv, args.pasos)
    ruta_pt = args.salida / "modelo_lstm_pc.pt"
    torch.save({
        "state_dict": modelo.state_dict(), "mean": media, "std": desv,
        "config": {"M": M, "H": H, "D": D, "C": C, "T": args.pasos, "factor_submuestreo": args.factor, "scale": ESCALA_ENTRADA},
        "best_epoch": mejor_epoca,
    }, ruta_pt)
    hist_df = pd.DataFrame(hist)
    hist_df.to_csv(args.salida / "curvas_entrenamiento.csv", index=False)
    np.savetxt(args.salida / "matriz_confusion_test.csv", cm, delimiter=",", fmt="%d")
    with (args.salida / "metricas.json").open("w", encoding="utf-8") as f:
        json.dump(resumen, f, indent=2, ensure_ascii=False)
    ep = hist_df["epoca"].to_numpy()
    fig, axs = plt.subplots(1, 2, figsize=(11, 4))
    axs[0].plot(ep, hist_df["loss_train"], label="train")
    axs[0].plot(ep, hist_df["loss_val"], label="val")
    axs[0].set(title="Pérdida", xlabel="Época", ylabel="Cross-entropy")
    axs[1].plot(ep, hist_df["acc_train"], label="train")
    axs[1].plot(ep, hist_df["acc_val"], label="val")
    axs[1].set(title="Accuracy", xlabel="Época", ylabel="Accuracy", ylim=(0, 1.02))
    for ax in axs:
        ax.grid(alpha=0.3)
        ax.legend()
    fig.tight_layout()
    fig.savefig(args.salida / "curvas_entrenamiento.png", dpi=140)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(6.3, 5.4))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(C), [str(i) for i in range(C)])
    ax.set_yticks(range(C), [str(i) for i in range(C)])
    ax.set_xlabel("Clase predicha")
    ax.set_ylabel("Clase real")
    ax.set_title("Matriz de confusión - test")
    for i in range(C):
        for j in range(C):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                    color="white" if cm[i, j] > (cm.max() / 2 if cm.max() else 0) else "black")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(args.salida / "matriz_confusion_test.png", dpi=140)
    plt.close(fig)
    print("\n--- RESULTADO TEST ---")
    print(f"Loss={loss_test:.4f} | Accuracy={resumen['accuracy']:.3f} | F1 macro={resumen['f1_macro']:.3f}")
    for clase, m in resumen["por_clase"].items():
        print(f"{clase} {m['nombre']:<14}: precision={m['precision']:.3f} recall={m['recall']:.3f} F1={m['f1']:.3f} n={m['soporte']}")
    print("\nExportación completada:")
    print(f"  Header C : {ruta_h.resolve()}")
    print(f"  Pesos NPZ: {ruta_npz.resolve()}")
    print(f"  Modelo PC: {ruta_pt.resolve()}")
    print(f"  Métricas : {(args.salida / 'metricas.json').resolve()}")
    print("\nIMPORTANTE: copia lstm_weights.h a la carpeta src/ml del firmware y configura la compilación en modo inferencia.")
    print(f"Confirma que RNN_T={args.pasos}, LIVE_PASO={args.factor}, RNN_M={M}, RNN_H={H}, RNN_D={D}, RNN_C={C}.")
    print("Prueba inicialmente con motores deshabilitados y valida que las clases coincidan antes de activar el control.")
if __name__ == "__main__":
    main()
