"""
CLASIFICADOR DE SECUENCIAS CON RNN / GRU / LSTM (PyTorch)
=========================================================
Arquitectura (mínima, como pide la actividad):

    Entrada (T pasos x M sensores)
        -> LSTM (16 unidades)         lee la secuencia paso a paso y deja un resumen h_T
        -> Dense (8) + ReLU
        -> Dense (n_clases)           logits; el softmax lo aplica la función de pérdida

Registra : loss y accuracy (train/val), número de parámetros, tiempo de entrenamiento.
Genera   : curvas, matriz de confusión, precisión/recall/F1 y estudios de
           tipo de celda, neuronas, longitud de ventana, sensores, learning rate,
           épocas y submuestreo.

Requiere : dataset_train.csv, dataset_val.csv, dataset_test.csv
           (salida de 03_dividir_dataset.py)  y  pip install torch

Regla de uso: los estudios y las decisiones se toman con VALIDACIÓN.
La PRUEBA se evalúa una sola vez, al final.
"""

import json
import os
import time
import warnings

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import (ConfusionMatrixDisplay, accuracy_score, classification_report,
                             confusion_matrix, precision_recall_fscore_support)

warnings.filterwarnings('ignore')

# ==========================================
# CONFIGURACIÓN
# ==========================================
ARCHIVOS = dict(train='dataset_train.csv', val='dataset_val.csv', test='dataset_test.csv')
SALIDA = 'resultados_lstm'
SEMILLAS = (0, 1, 2)       # los estudios promedian varias semillas (dataset pequeño)
BATCH = 16

# T = muestras (a 50 Hz) que se usan desde el inicio de la ventana (None = todas)
# paso = submuestreo: 1 usa las 50 muestras/s, 5 usa 1 de cada 5 (10 muestras/s)
BASE = dict(tipo='lstm', hidden=8, dense=8, lr=0.01, epochs=200,
            T=None, paso=5, canales=(0, 1, 2))

ESTUDIOS = {
    'tipo_celda': ('tipo', ['rnn', 'gru', 'lstm']),
    'neuronas':   ('hidden', [2, 4, 8, 16, 32, 64]),
    'ventana':    ('T', [25, 50, 100, 150, 200, 250]),
    'sensores':   ('canales', [(0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]),
    'lr':         ('lr', [1e-4, 1e-3, 5e-3, 1e-2, 1e-1]),
    'epocas':     ('epochs', [10, 25, 50, 100, 200]),
    'submuestreo': ('paso', [1, 2, 5, 10]),
}

NOMBRES_CLASE = {0: "0 STOP/otros", 1: "1 Av.Rápido", 2: "2 Av.Lento",
                 3: "3 Rev.Rápida", 4: "4 Rev.Lenta"}


# ==========================================
# DATOS
# ==========================================
def cargar(archivo):
    df = pd.read_csv(archivo).sort_values(['sample_id', 'timestamp_ms'])
    ids = df['sample_id'].unique()
    X = df[['p1', 'p2', 'p3']].to_numpy().reshape(len(ids), -1, 3)   # (muestras, T, 3)
    y = df.groupby('sample_id')['label'].first().loc[ids].to_numpy()
    return X, y


def recortar(X, T, paso, canales):
    """(n, T_total, 3) -> (n, pasos, M): primeras T muestras, 1 de cada `paso`, canales elegidos."""
    return X[:, :T:paso, :][:, :, list(canales)]


# ==========================================
# MODELO
# ==========================================
class Red(nn.Module):
    def __init__(self, tipo, n_in, hidden, dense, n_clases):
        super().__init__()
        celda = {'rnn': nn.RNN, 'gru': nn.GRU, 'lstm': nn.LSTM}[tipo]
        # batch_first=True -> la entrada se organiza como (lote, tiempo, sensores)
        self.rnn = celda(n_in, hidden, batch_first=True)
        self.fc1 = nn.Linear(hidden, dense)
        self.fc2 = nn.Linear(dense, n_clases)

    def forward(self, x):
        # La capa recurrente recorre los T pasos y devuelve el estado oculto de CADA paso
        salidas, _ = self.rnn(x)                 # (lote, T, hidden)
        h_final = salidas[:, -1, :]              # resumen de toda la secuencia (último paso)
        return self.fc2(torch.relu(self.fc1(h_final)))


# ==========================================
# ENTRENAMIENTO
# ==========================================
def entrenar(datos, tipo, hidden, dense, lr, epochs, T, paso, canales, semilla=0):
    torch.manual_seed(semilla)
    T = T or datos['train'][0].shape[1]

    # Recorte + submuestreo + selección de sensores
    V = {k: recortar(datos[k][0], T, paso, canales) for k in datos}

    # Normalización por canal: media y desviación SOLO del conjunto de entrenamiento
    media = V['train'].mean(axis=(0, 1), keepdims=True)
    std = V['train'].std(axis=(0, 1), keepdims=True) + 1e-8
    X = {k: torch.tensor((V[k] - media) / std, dtype=torch.float32) for k in V}

    clases = np.unique(np.concatenate([datos[k][1] for k in datos]))
    mapa = {c: i for i, c in enumerate(clases)}
    y = {k: torch.tensor([mapa[c] for c in datos[k][1]], dtype=torch.long) for k in datos}

    modelo = Red(tipo, len(canales), hidden, dense, len(clases))
    opt = torch.optim.Adam(modelo.parameters(), lr=lr)
    perdida = nn.CrossEntropyLoss()
    g = torch.Generator().manual_seed(semilla)
    n = len(X['train'])

    hist = dict(loss_tr=[], loss_va=[], acc_tr=[], acc_va=[])
    t_train = 0.0
    for _ in range(epochs):
        t0 = time.perf_counter()
        modelo.train()
        orden = torch.randperm(n, generator=g)
        for ini in range(0, n, BATCH):
            idx = orden[ini:ini + BATCH]
            opt.zero_grad()
            loss = perdida(modelo(X['train'][idx]), y['train'][idx])   # pasada hacia adelante en el tiempo
            loss.backward()                                            # retropropagación a través del tiempo
            nn.utils.clip_grad_norm_(modelo.parameters(), 1.0)         # evita gradientes explosivos
            opt.step()                                                 # se actualizan los pesos (1 vez por lote)
        t_train += time.perf_counter() - t0

        # Evaluación al final de cada época (no cuenta para el tiempo de entrenamiento)
        modelo.eval()
        with torch.no_grad():
            for k, (lk, ak) in (('train', ('loss_tr', 'acc_tr')), ('val', ('loss_va', 'acc_va'))):
                logits = modelo(X[k])
                hist[lk].append(perdida(logits, y[k]).item())
                hist[ak].append((logits.argmax(dim=1) == y[k]).float().mean().item())

    n_params = sum(p.numel() for p in modelo.parameters())
    return dict(modelo=modelo, X=X, clases=clases, hist=hist, tiempo=t_train, params=n_params,
                tipo=tipo, hidden=hidden, dense=dense, lr=lr, epochs=epochs, T=T,
                paso=paso, canales=canales, media=media, std=std)


# ==========================================
# GRÁFICAS Y REPORTES
# ==========================================
def graficar_curvas(res, ruta, titulo):
    h = res['hist']
    ep = np.arange(1, len(h['loss_tr']) + 1)
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    ax[0].plot(ep, h['loss_tr'], label='entrenamiento')
    ax[0].plot(ep, h['loss_va'], label='validación')
    ax[0].set(title='Loss (entropía cruzada)', xlabel='época', ylabel='loss')
    ax[1].plot(ep, h['acc_tr'], label='entrenamiento')
    ax[1].plot(ep, h['acc_va'], label='validación')
    ax[1].set(title='Accuracy', xlabel='época', ylabel='accuracy', ylim=(0, 1.02))
    for a in ax:
        a.grid(alpha=0.3)
        a.legend()
    fig.suptitle(titulo)
    fig.tight_layout()
    fig.savefig(ruta, dpi=140)
    plt.close(fig)


def reporte_final(res, datos, split, prefijo):
    """Matriz de confusión + precisión/recall/F1 en el conjunto indicado."""
    modelo = res['modelo']
    modelo.eval()
    with torch.no_grad():
        pred = res['clases'][modelo(res['X'][split]).argmax(dim=1).numpy()]
    y = datos[split][1]

    etiquetas = sorted(np.unique(np.concatenate([y, pred])))
    nombres = [NOMBRES_CLASE.get(c, str(c)) for c in etiquetas]
    texto = classification_report(y, pred, labels=etiquetas, target_names=nombres,
                                  digits=3, zero_division=0)
    acc = accuracy_score(y, pred)
    print(f"\n--- Resultados en {split.upper()} ---")
    print(f"Accuracy: {acc:.3f}")
    print(texto)
    with open(f'{prefijo}_reporte_{split}.txt', 'w', encoding='utf-8') as f:
        f.write(f"Accuracy: {acc:.4f}\n\n{texto}")

    cm = confusion_matrix(y, pred, labels=etiquetas)
    fig, ax = plt.subplots(figsize=(6, 5))
    ConfusionMatrixDisplay(cm, display_labels=nombres).plot(ax=ax, cmap='Blues',
                                                            xticks_rotation=30, colorbar=False)
    ax.set_title(f'Matriz de confusión ({split})')
    fig.tight_layout()
    fig.savefig(f'{prefijo}_confusion_{split}.png', dpi=140)
    plt.close(fig)

    p, r, f1, _ = precision_recall_fscore_support(y, pred, average='macro', zero_division=0)
    return dict(acc=acc, precision_macro=p, recall_macro=r, f1_macro=f1)


# ==========================================
# ESTUDIOS (con VALIDACIÓN)
# ==========================================
def estudio(datos, nombre, clave, valores):
    filas = []
    for v in valores:
        cfg = dict(BASE)
        cfg[clave] = v
        r = [entrenar(datos, semilla=s, **cfg) for s in SEMILLAS]
        filas.append(dict(
            valor=str(v),
            acc_val=np.mean([x['hist']['acc_va'][-1] for x in r]),
            acc_val_std=np.std([x['hist']['acc_va'][-1] for x in r]),
            acc_train=np.mean([x['hist']['acc_tr'][-1] for x in r]),
            loss_val=np.mean([x['hist']['loss_va'][-1] for x in r]),
            loss_train=np.mean([x['hist']['loss_tr'][-1] for x in r]),
            parametros=r[0]['params'],
            tiempo_s=np.mean([x['tiempo'] for x in r]),
        ))
        f = filas[-1]
        print(f"  {nombre} = {v!s:<12} acc_val {f['acc_val']:.3f} ± {f['acc_val_std']:.3f} "
              f"| loss_val {f['loss_val']:.3f} | params {f['parametros']} "
              f"| {f['tiempo_s']:.1f} s")

    tabla = pd.DataFrame(filas)
    tabla.to_csv(os.path.join(SALIDA, f'estudio_{nombre}.csv'), index=False)

    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    x = np.arange(len(tabla))
    ax[0].errorbar(x, tabla['acc_val'], yerr=tabla['acc_val_std'], marker='o',
                   capsize=3, label='validación')
    ax[0].plot(x, tabla['acc_train'], marker='s', linestyle='--', label='entrenamiento')
    ax[0].set(title=f'Accuracy vs {nombre}', ylim=(0, 1.02))
    ax[1].plot(x, tabla['loss_val'], marker='o', label='validación')
    ax[1].plot(x, tabla['loss_train'], marker='s', linestyle='--', label='entrenamiento')
    ax[1].set(title=f'Loss vs {nombre}')
    for a in ax:
        a.set_xticks(x)
        a.set_xticklabels(tabla['valor'], rotation=30)
        a.grid(alpha=0.3)
        a.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(SALIDA, f'estudio_{nombre}.png'), dpi=140)
    plt.close(fig)
    return tabla


# ==========================================
# MAIN
# ==========================================
def main():
    os.makedirs(SALIDA, exist_ok=True)
    datos = {k: cargar(v) for k, v in ARCHIVOS.items()}
    for k, (X, y) in datos.items():
        print(f"{k:<6} X {X.shape}  clases {dict(zip(*np.unique(y, return_counts=True)))}")

    # ---------- 1. Modelo base ----------
    print("\n=== MODELO BASE ===")
    res = entrenar(datos, semilla=0, **BASE)
    print(res['modelo'])
    h = res['hist']
    pasos = recortar(datos['train'][0][:1], res['T'], BASE['paso'], BASE['canales']).shape[1]
    resumen = dict(
        loss_entrenamiento=h['loss_tr'][-1], loss_validacion=h['loss_va'][-1],
        acc_entrenamiento=h['acc_tr'][-1], acc_validacion=h['acc_va'][-1],
        parametros=int(res['params']), tiempo_entrenamiento_s=res['tiempo'],
        pasos_de_tiempo=int(pasos), config={k: str(v) for k, v in BASE.items()},
    )
    print(f"\nPasos de tiempo por secuencia: {pasos}")
    for k, v in resumen.items():
        print(f"  {k}: {v}")

    prefijo = os.path.join(SALIDA, 'lstm')
    graficar_curvas(res, f'{prefijo}_curvas.png', f"{BASE['tipo'].upper()} ({BASE['hidden']} unidades)")
    reporte_final(res, datos, 'val', prefijo)
    test = reporte_final(res, datos, 'test', prefijo)        # evaluación final, una sola vez
    resumen['test'] = {k: float(v) for k, v in test.items()}
    with open(os.path.join(SALIDA, 'resumen_lstm.json'), 'w', encoding='utf-8') as f:
        json.dump(resumen, f, indent=2, ensure_ascii=False)

    # Comparación con el modelo base sin memoria (si ya lo ejecutaste)
    ruta_base = os.path.join('resultados_baseline', 'resumen_baseline.json')
    if os.path.exists(ruta_base):
        with open(ruta_base, encoding='utf-8') as f:
            b = json.load(f)
        print("\n=== COMPARACIÓN CON EL BASELINE (validación) ===")
        print(f"{'':<12}{'acc_val':>9}{'loss_val':>10}{'params':>9}{'tiempo_s':>10}")
        print(f"{'Baseline MLP':<12}{b['acc_validacion']:>9.3f}{b['loss_validacion']:>10.3f}"
              f"{b['parametros']:>9}{b['tiempo_entrenamiento_s']:>10.1f}")
        print(f"{BASE['tipo'].upper():<12}{resumen['acc_validacion']:>9.3f}"
              f"{resumen['loss_validacion']:>10.3f}{resumen['parametros']:>9}"
              f"{resumen['tiempo_entrenamiento_s']:>10.1f}")

    # ---------- 2. Estudios ----------
    print(f"\n=== ESTUDIOS (validación, promedio de {len(SEMILLAS)} semillas) ===")
    for nombre, (clave, valores) in ESTUDIOS.items():
        print(f"\n[{nombre}]")
        estudio(datos, nombre, clave, valores)

    print(f"\nTodo guardado en la carpeta '{SALIDA}/'")


if __name__ == '__main__':
    main()