"""
MODELO DE REFERENCIA SIN MEMORIA TEMPORAL (BASELINE)
====================================================
Ventana (T, 3)  ->  [promedio, RMS, máximo, varianza] por canal  ->  MLP  ->  clase

Cada secuencia completa se reduce a 12 números (4 estadísticos x 3 sensores),
así que el orden y el momento en que ocurren las cosas dentro de la ventana
se pierde. Ese es el punto de comparación contra la LSTM.

Registra: loss y accuracy (train/val), número de parámetros, tiempo de entrenamiento.
Genera  : curvas de entrenamiento, matriz de confusión, precisión/recall/F1 y
          estudios del efecto de neuronas, longitud de ventana, sensores,
          learning rate y épocas.

Requiere: dataset_train.csv, dataset_val.csv, dataset_test.csv
          (salida de 03_dividir_dataset.py)

Regla de uso: los estudios y las decisiones se toman con VALIDACIÓN.
El conjunto de PRUEBA solo se evalúa una vez, al final, con la configuración elegida.
"""

import json
import os
import time
import warnings

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import (ConfusionMatrixDisplay, accuracy_score, classification_report,
                             confusion_matrix, log_loss, precision_recall_fscore_support)
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings('ignore')

# ==========================================
# CONFIGURACIÓN
# ==========================================
ARCHIVOS = dict(train='dataset_train.csv', val='dataset_val.csv', test='dataset_test.csv')
SALIDA = 'resultados_baseline'
SEMILLAS = (0, 1, 2)            # los estudios promedian varias semillas (dataset pequeño)

# Configuración base del MLP (T=None usa la ventana completa)
BASE = dict(hidden=(16,), lr=1e-3, epochs=200, T=None, canales=(0, 1, 2))

# Valores a probar en cada estudio
ESTUDIOS = {
    'neuronas':  ('hidden', [(2,), (4,), (8,), (16,), (32,), (64,)]),
    'lr':        ('lr', [1e-4, 1e-3, 1e-2, 1e-1]),
    'epocas':    ('epochs', [10, 25, 50, 100, 200, 400]),
    'ventana':   ('T', [25, 50, 100, 150, 200, 250]),
    'sensores':  ('canales', [(0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]),
}

NOMBRES_CLASE = {0: "0 STOP/otros", 1: "1 Av.Rápido", 2: "2 Av.Lento",
                 3: "3 Rev.Rápida", 4: "4 Rev.Lenta"}


# ==========================================
# DATOS Y CARACTERÍSTICAS
# ==========================================
def cargar(archivo):
    df = pd.read_csv(archivo).sort_values(['sample_id', 'timestamp_ms'])
    ids = df['sample_id'].unique()
    X = df[['p1', 'p2', 'p3']].to_numpy().reshape(len(ids), -1, 3)
    y = df.groupby('sample_id')['label'].first().loc[ids].to_numpy()
    return X, y


def extraer(X, T, canales):
    """(n, T_total, 3) -> (n, 4 * n_canales): promedio, RMS, máximo, varianza."""
    V = X[:, :T, :][:, :, list(canales)]
    media = V.mean(axis=1)
    rms = np.sqrt((V ** 2).mean(axis=1))
    maxi = V.max(axis=1)
    var = V.var(axis=1)
    return np.hstack([media, rms, maxi, var])


# ==========================================
# ENTRENAMIENTO
# ==========================================
def entrenar(datos, hidden, lr, epochs, T, canales, semilla=0, batch=32):
    T = T or datos['train'][0].shape[1]
    Xtr = extraer(datos['train'][0], T, canales)
    Xva = extraer(datos['val'][0], T, canales)
    ytr, yva = datos['train'][1], datos['val'][1]
    clases = np.unique(np.concatenate([ytr, yva, datos['test'][1]]))

    # Normalización: el escalador se ajusta SOLO con entrenamiento
    esc = StandardScaler().fit(Xtr)
    Xtr, Xva = esc.transform(Xtr), esc.transform(Xva)

    mlp = MLPClassifier(hidden_layer_sizes=hidden, solver='adam', learning_rate_init=lr,
                        batch_size=min(batch, len(Xtr)), random_state=semilla)

    hist = dict(loss_tr=[], loss_va=[], acc_tr=[], acc_va=[])
    t_train = 0.0
    for _ in range(epochs):
        t0 = time.perf_counter()
        mlp.partial_fit(Xtr, ytr, classes=clases)      # una época
        t_train += time.perf_counter() - t0

        ptr, pva = mlp.predict_proba(Xtr), mlp.predict_proba(Xva)
        hist['loss_tr'].append(log_loss(ytr, ptr, labels=clases))
        hist['loss_va'].append(log_loss(yva, pva, labels=clases))
        hist['acc_tr'].append(accuracy_score(ytr, mlp.classes_[ptr.argmax(axis=1)]))
        hist['acc_va'].append(accuracy_score(yva, mlp.classes_[pva.argmax(axis=1)]))

    n_params = sum(w.size for w in mlp.coefs_) + sum(b.size for b in mlp.intercepts_)
    return dict(mlp=mlp, esc=esc, hist=hist, tiempo=t_train, params=n_params,
                T=T, canales=canales, hidden=hidden, lr=lr, epochs=epochs)


# ==========================================
# GRÁFICAS Y REPORTES
# ==========================================
def graficar_curvas(res, ruta, titulo):
    h = res['hist']
    ep = np.arange(1, len(h['loss_tr']) + 1)
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    ax[0].plot(ep, h['loss_tr'], label='entrenamiento')
    ax[0].plot(ep, h['loss_va'], label='validación')
    ax[0].set(title='Loss (entropía cruzada)', xlabel='época', ylabel='loss')
    ax[1].plot(ep, h['acc_tr'], label='entrenamiento')
    ax[1].plot(ep, h['acc_va'], label='validación')
    ax[1].set(title='Accuracy', xlabel='época', ylabel='accuracy', ylim=(0, 1.02))
    for a in ax:
        a.grid(alpha=0.3)
        a.legend()
    fig.suptitle(titulo)
    fig.tight_layout()
    fig.savefig(ruta, dpi=140)
    plt.close(fig)


def evaluar_split(res, datos, split):
    X, y = datos[split]
    Xf = res['esc'].transform(extraer(X, res['T'], res['canales']))
    pred = res['mlp'].predict(Xf)
    return y, pred


def reporte_final(res, datos, split, prefijo):
    """Matriz de confusión + precisión/recall/F1 en el conjunto indicado."""
    y, pred = evaluar_split(res, datos, split)
    etiquetas = sorted(np.unique(np.concatenate([y, pred])))
    nombres = [NOMBRES_CLASE.get(c, str(c)) for c in etiquetas]

    texto = classification_report(y, pred, labels=etiquetas, target_names=nombres,
                                  digits=3, zero_division=0)
    print(f"\n--- Resultados en {split.upper()} ---")
    print(f"Accuracy: {accuracy_score(y, pred):.3f}")
    print(texto)
    with open(f'{prefijo}_reporte_{split}.txt', 'w', encoding='utf-8') as f:
        f.write(f"Accuracy: {accuracy_score(y, pred):.4f}\n\n{texto}")

    cm = confusion_matrix(y, pred, labels=etiquetas)
    fig, ax = plt.subplots(figsize=(6, 5))
    ConfusionMatrixDisplay(cm, display_labels=nombres).plot(ax=ax, cmap='Blues',
                                                            xticks_rotation=30, colorbar=False)
    ax.set_title(f'Matriz de confusión ({split})')
    fig.tight_layout()
    fig.savefig(f'{prefijo}_confusion_{split}.png', dpi=140)
    plt.close(fig)

    p, r, f1, _ = precision_recall_fscore_support(y, pred, average='macro', zero_division=0)
    return dict(acc=accuracy_score(y, pred), precision_macro=p, recall_macro=r, f1_macro=f1)


# ==========================================
# ESTUDIOS DE HIPERPARÁMETROS (con VALIDACIÓN)
# ==========================================
def estudio(datos, nombre, clave, valores):
    filas = []
    for v in valores:
        cfg = dict(BASE)
        cfg[clave] = v
        r = [entrenar(datos, semilla=s, **cfg) for s in SEMILLAS]
        filas.append(dict(
            valor=str(v),
            acc_val=np.mean([x['hist']['acc_va'][-1] for x in r]),
            acc_val_std=np.std([x['hist']['acc_va'][-1] for x in r]),
            acc_train=np.mean([x['hist']['acc_tr'][-1] for x in r]),
            loss_val=np.mean([x['hist']['loss_va'][-1] for x in r]),
            loss_train=np.mean([x['hist']['loss_tr'][-1] for x in r]),
            parametros=r[0]['params'],
            tiempo_s=np.mean([x['tiempo'] for x in r]),
        ))
        print(f"  {nombre} = {v!s:<14} acc_val {filas[-1]['acc_val']:.3f} "
              f"± {filas[-1]['acc_val_std']:.3f} | loss_val {filas[-1]['loss_val']:.3f} "
              f"| params {filas[-1]['parametros']}")

    tabla = pd.DataFrame(filas)
    tabla.to_csv(os.path.join(SALIDA, f'estudio_{nombre}.csv'), index=False)

    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    x = np.arange(len(tabla))
    ax[0].errorbar(x, tabla['acc_val'], yerr=tabla['acc_val_std'], marker='o',
                   capsize=3, label='validación')
    ax[0].plot(x, tabla['acc_train'], marker='s', linestyle='--', label='entrenamiento')
    ax[0].set(title=f'Accuracy vs {nombre}', ylim=(0, 1.02))
    ax[1].plot(x, tabla['loss_val'], marker='o', label='validación')
    ax[1].plot(x, tabla['loss_train'], marker='s', linestyle='--', label='entrenamiento')
    ax[1].set(title=f'Loss vs {nombre}')
    for a in ax:
        a.set_xticks(x)
        a.set_xticklabels(tabla['valor'], rotation=30)
        a.grid(alpha=0.3)
        a.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(SALIDA, f'estudio_{nombre}.png'), dpi=140)
    plt.close(fig)
    return tabla


# ==========================================
# MAIN
# ==========================================
def main():
    os.makedirs(SALIDA, exist_ok=True)
    datos = {k: cargar(v) for k, v in ARCHIVOS.items()}
    for k, (X, y) in datos.items():
        print(f"{k:<6} X {X.shape}  clases {dict(zip(*np.unique(y, return_counts=True)))}")

    # ---------- 1. Modelo base ----------
    print("\n=== MODELO BASE ===")
    res = entrenar(datos, semilla=0, **BASE)
    h = res['hist']
    resumen = dict(
        loss_entrenamiento=h['loss_tr'][-1], loss_validacion=h['loss_va'][-1],
        acc_entrenamiento=h['acc_tr'][-1], acc_validacion=h['acc_va'][-1],
        parametros=int(res['params']), tiempo_entrenamiento_s=res['tiempo'],
        config={k: str(v) for k, v in BASE.items()},
    )
    for k, v in resumen.items():
        print(f"  {k}: {v}")
    with open(os.path.join(SALIDA, 'resumen_baseline.json'), 'w', encoding='utf-8') as f:
        json.dump(resumen, f, indent=2, ensure_ascii=False)

    prefijo = os.path.join(SALIDA, 'baseline')
    graficar_curvas(res, f'{prefijo}_curvas.png', 'Baseline: promedio/RMS/máx/varianza + MLP')
    reporte_final(res, datos, 'val', prefijo)
    reporte_final(res, datos, 'test', prefijo)      # evaluación final, una sola vez

    # ---------- 2. Estudios (con validación) ----------
    print("\n=== ESTUDIOS DE HIPERPARÁMETROS (validación, promedio de "
          f"{len(SEMILLAS)} semillas) ===")
    for nombre, (clave, valores) in ESTUDIOS.items():
        print(f"\n[{nombre}]")
        estudio(datos, nombre, clave, valores)

    print(f"\nTodo guardado en la carpeta '{SALIDA}/'")


if __name__ == '__main__':
    main()