"""Host de entrenamiento en linea: Python dirige, el micro entrena.
Uso: python Host_entrenamiento_compacto.py --datos . --epocas 100
"""

import argparse,json,os,subprocess,time
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import lstm_pesos as lstm_pesos

PUERTO='COM10'
BAUDIOS=115200
ESCALA=200.0
N_CLASES=5
NOMBRES_CLASE={0:'0 STOP/otros',1:'1 Av.Rapido',2:'2 Av.Lento',3:'3 Rev.Rapida',4:'4 Rev.Lenta'}
M,H,D,C=3,8,8,5
G=4*H

class Enlace:
    def __init__(self,puerto=None,sim=None,baud=115200,timeout=2.0):
        self.sim=sim is not None
        if self.sim:
            self.p=subprocess.Popen([sim],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,bufsize=1)
        else:
            import serial
            self.s=serial.Serial(puerto,baud,timeout=timeout)
            time.sleep(0.5)
            self.s.reset_input_buffer()
    def timeout(self,seg):
        if not self.sim:self.s.timeout=seg
    def enviar(self,linea):
        if self.sim:
            self.p.stdin.write(linea+'\n');self.p.stdin.flush()
        else:self.s.write((linea+'\n').encode())
    def leer(self):
        if self.sim:r=self.p.stdout.readline();err='el simulador termino'
        else:r=self.s.readline().decode(errors='ignore');err='el micro no respondio a tiempo'
        if r=='':raise TimeoutError(err)
        return r.strip()
    def cmd(self,linea,esperado='OK'):
        self.enviar(linea);r=self.leer()
        while r.startswith('READY'):r=self.leer()
        if not r.startswith(esperado):raise RuntimeError(f"'{linea[:40]}' -> {r}")
        return r
    def cerrar(self):
        if self.sim:
            self.p.stdin.close();self.p.wait(timeout=5)
        else:self.s.close()

def cargar(archivo):
    df=pd.read_csv(archivo).sort_values(['sample_id','timestamp_ms'])
    ids=df['sample_id'].unique()
    X=df[['p1','p2','p3']].to_numpy().reshape(len(ids),-1,3)
    y=df.groupby('sample_id')['label'].first().loc[ids].to_numpy()
    return X,y

def preparar(X,T,paso):
    V=X[:,:T:paso,:]
    return np.clip(np.rint(V*ESCALA),0,255).astype(np.uint8)

def pasada(enl,comando,Xq,y,orden):
    cm=np.zeros((N_CLASES,N_CLASES),dtype=int);loss=0.0;us=0
    for i in orden:
        vals=','.join(str(int(v)) for v in Xq[i].reshape(-1))
        enl.enviar(f'{comando},{int(y[i])},{vals}')
        r=enl.leer().split(',')
        if r[0]!='R':raise RuntimeError(f"{comando} -> {','.join(r)}")
        loss+=int(r[1])/1e6
        real,pred=int(y[i]),int(r[2])
        if not 0<=pred<N_CLASES:raise RuntimeError(f'Clase predicha fuera de rango: {pred}')
        cm[real,pred]+=1;us+=int(r[3])
    n=len(orden)
    if n==0:return 0.0,0.0,cm,us
    return loss/n,np.trace(cm)/n,cm,us

def metricas_de_cm(cm):
    cm=np.asarray(cm,dtype=float);tp=np.diag(cm)
    prec=np.divide(tp,cm.sum(axis=0),out=np.zeros_like(tp),where=cm.sum(axis=0)>0)
    rec=np.divide(tp,cm.sum(axis=1),out=np.zeros_like(tp),where=cm.sum(axis=1)>0)
    f1=np.divide(2*prec*rec,prec+rec,out=np.zeros_like(tp),where=(prec+rec)>0)
    return prec,rec,f1,cm.sum(axis=1)

def reporte(nombre,loss,acc,cm):
    prec,rec,f1,soporte=metricas_de_cm(cm)
    print(f'\n--- {nombre.upper()} (n={int(cm.sum())}) | loss {loss:.4f} | accuracy {acc:.3f} ---')
    print(f"{'clase':<14}{'precision':>10}{'recall':>9}{'f1':>8}{'n':>6}")
    for c in range(len(prec)):
        print(f"{NOMBRES_CLASE.get(c,str(c)):<14}{prec[c]:>10.3f}{rec[c]:>9.3f}{f1[c]:>8.3f}{int(soporte[c]):>6}")
    print(f"{'macro':<14}{prec.mean():>10.3f}{rec.mean():>9.3f}{f1.mean():>8.3f}")
    return {'loss':float(loss),'acc':float(acc),'n':int(cm.sum()),'cm':cm.astype(int).tolist(),'precision':prec.tolist(),'recall':rec.tolist(),'f1':f1.tolist()}

def graficar(hist,cm,ruta):
    ep=[h['epoca'] for h in hist]
    fig,ax=plt.subplots(1,3,figsize=(16,4.2))
    ax[0].plot(ep,[h['loss_tr'] for h in hist],label='entrenamiento');ax[0].plot(ep,[h['loss_va'] for h in hist],label='validacion');ax[0].set(title='Loss',xlabel='epoca',ylabel='loss')
    ax[1].plot(ep,[h['acc_tr'] for h in hist],label='entrenamiento');ax[1].plot(ep,[h['acc_va'] for h in hist],label='validacion');ax[1].set(title='Accuracy',xlabel='epoca',ylabel='accuracy',ylim=(0,1.02))
    for a in ax[:2]:a.grid(alpha=0.3);a.legend()
    ax[2].imshow(cm,cmap='Blues')
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):ax[2].text(j,i,cm[i,j],ha='center',va='center',color='white' if cm[i,j]>cm.max()/2 else 'black')
    ax[2].set(title='Matriz de confusion (test)',xlabel='predicha',ylabel='real',xticks=range(cm.shape[1]),yticks=range(cm.shape[0]))
    fig.tight_layout();fig.savefig(ruta,dpi=140);plt.close(fig)

def recibir_pesos(enl, mean_ref=None, std_ref=None):
    """Recibe los parametros con el comando DUMP que ya implementa el firmware.
    DUMP envia floats como bits IEEE-754 hex: evita errores de formato decimal.
    """
    print("\nSolicitando pesos finales al S32K312 (DUMP)...")
    n=G*M+G*H+G+D*H+D+C*D+C
    plano,mean_micro,std_micro=lstm_pesos.volcar(enl,n)
    if plano.size!=n or not np.isfinite(plano).all():raise RuntimeError(f"DUMP incompleto: parametros invalidos {np.isfinite(plano).sum()}/{n}")
    if mean_micro.shape!=(M,) or std_micro.shape!=(M,) or not np.isfinite(mean_micro).all() or not np.isfinite(std_micro).all():raise RuntimeError("Normalizacion recibida por DUMP invalida")
    if mean_ref is not None and not np.allclose(mean_micro,np.asarray(mean_ref,dtype=np.float32),rtol=0,atol=3e-6):raise RuntimeError(f"mean del micro no coincide con host: MCU={mean_micro}, host={mean_ref}")
    if std_ref is not None and not np.allclose(std_micro,np.asarray(std_ref,dtype=np.float32),rtol=0,atol=3e-6):raise RuntimeError(f"std del micro no coincide con host: MCU={std_micro}, host={std_ref}")
    pesos=lstm_pesos.separar(plano,H,D,C,M)
    print(f"  Pesos recibidos: {n}/{n}")
    print("  Transferencia DUMP correcta; normalizacion leida del micro.")
    return pesos,mean_micro,std_micro

def guardar_pesos_npz(pesos,mean,std,ruta,pasos):
    np.savez(ruta,w_ih=pesos['w_ih'],w_hh=pesos['w_hh'],b=pesos['b'],w1=pesos['w1'],b1=pesos['b1'],w2=pesos['w2'],b2=pesos['b2'],mean=np.asarray(mean,dtype=np.float32),std=np.asarray(std,dtype=np.float32),M=np.array(M),H=np.array(H),D=np.array(D),C=np.array(C),G=np.array(G),T=np.array(pasos),escala=np.array(ESCALA))
    print('Modelo guardado en:',ruta)

def escribir_array_c(f,nombre,array):
    a=np.asarray(array,dtype=np.float32);shape=''.join(f'[{d}]' for d in a.shape)
    def cf(x):
        v=f'{float(x):.9g}'
        if '.' not in v and 'e' not in v.lower():v+='.0'
        return v+'f'
    if a.ndim==1:init='{'+','.join(cf(x) for x in a)+'}'
    elif a.ndim==2:init='{\n'+',\n'.join('    {'+','.join(cf(x) for x in row)+'}' for row in a)+'\n}'
    else:raise ValueError('Solo se soportan arrays 1D y 2D.')
    f.write(f'static const float {nombre}{shape} = {init};\n')

def generar_weights_h(pesos,mean,std,ruta,pasos):
    with open(ruta,'w',encoding='utf-8') as f:
        f.write('#ifndef LSTM_WEIGHTS_H\n#define LSTM_WEIGHTS_H\n\n#include <stdint.h>\n\n')
        f.write(f'/* Pesos exportados desde el S32K312. T={pasos}, M={M}, H={H}, D={D}, C={C}. */\n')
        f.write(f'#define LSTM_BASE_M {M}U\n#define LSTM_BASE_H {H}U\n#define LSTM_BASE_D {D}U\n#define LSTM_BASE_C {C}U\n#define LSTM_BASE_G {G}U\n#define LSTM_BASE_T {pasos}U\n\n')
        escribir_array_c(f,'LSTM_MEAN',mean);escribir_array_c(f,'LSTM_STD',std)
        escribir_array_c(f,'LSTM_W_IH',pesos['w_ih']);escribir_array_c(f,'LSTM_W_HH',pesos['w_hh']);escribir_array_c(f,'LSTM_B',pesos['b'])
        escribir_array_c(f,'LSTM_W1',pesos['w1']);escribir_array_c(f,'LSTM_B1',pesos['b1']);escribir_array_c(f,'LSTM_W2',pesos['w2']);escribir_array_c(f,'LSTM_B2',pesos['b2'])
        f.write('\n#endif /* LSTM_WEIGHTS_H */\n')
    print('Header generado:',ruta)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--puerto',default=PUERTO);ap.add_argument('--sim',default=None);ap.add_argument('--baud',type=int,default=BAUDIOS)
    ap.add_argument('--datos',default='.');ap.add_argument('--salida',default='resultados_micro');ap.add_argument('--epocas',type=int,default=50)
    ap.add_argument('--lr',type=float,default=0.01);ap.add_argument('--lote',type=int,default=16);ap.add_argument('--clip',type=float,default=1.0);ap.add_argument('--semilla',type=int,default=1)
    ap.add_argument('--T',type=int,default=240);ap.add_argument('--paso',type=int,default=4)
    a=ap.parse_args();os.makedirs(a.salida,exist_ok=True)

    crudo={k:cargar(os.path.join(a.datos,f'dataset_{k}.csv')) for k in ('train','val','test')}
    dq={k:(preparar(X,a.T,a.paso),y) for k,(X,y) in crudo.items()}
    deq=dq['train'][0].astype(float)/ESCALA
    mean=deq.mean(axis=(0,1));std=deq.std(axis=(0,1));std=np.where(std<1e-6,1.0,std)
    print({k:v[0].shape for k,v in dq.items()},'media',mean.round(3),'desv',std.round(3))
    Xtr,ytr=dq['train'];Xva,yva=dq['val'];Xte,yte=dq['test']
    if Xtr.shape[1]!=20 or Xtr.shape[2]!=M:print(f'[INFO] Secuencia generada: {Xtr.shape[1]}x{Xtr.shape[2]}')

    enl=Enlace(puerto=a.puerto,sim=a.sim,baud=a.baud,timeout=2.0)
    try:
        for intento in range(5):
            try:enl.cmd('PING');break
            except(RuntimeError,TimeoutError):
                if intento==4:raise
        enl.timeout(30.0)
        info=enl.cmd('INFO','INFO').split(',')
        version=info[1];params,H_micro,D_micro,C_micro,T_micro,M_micro,mem_modelo=map(int,info[2:9])
        print(f'Micro: {version} | LSTM({H_micro})+Dense({D_micro})+{C_micro} clases | {params} parametros | modelo+cache {mem_modelo} B')
        pasos=Xtr.shape[1]
        if (pasos,Xtr.shape[2])!=(T_micro,M_micro) or C_micro!=N_CLASES:raise SystemExit(f'[ERROR] Los datos tienen {pasos} pasos x {Xtr.shape[2]} sensores y {N_CLASES} clases; el firmware espera {T_micro} x {M_micro} y {C_micro}.')
        if params!=501:raise SystemExit(f'[ERROR] El firmware declara {params} parametros; este host espera 501.')

        enl.cmd(f'INIT,{a.semilla}')
        enl.cmd('NORM,'+','.join(str(int(round(v*1e6))) for v in (*mean,*std)))
        enl.cmd(f'CFG,{int(round(a.lr*1e6))},{int(round(a.clip*1e6))},{a.lote}')
        enl.cmd('MODE,TRAIN')

        rng=np.random.default_rng(a.semilla);hist=[];t_micro_us=0
        print(f'\nEntrenando {a.epocas} epocas en el micro...')
        print(f"{'epoca':>6}{'loss_tr':>10}{'acc_tr':>8}{'loss_va':>10}{'acc_va':>8}{'ms_micro':>10}")
        try:
            for ep in range(1,a.epocas+1):
                orden=rng.permutation(len(Xtr));l_tr,a_tr,_,us=pasada(enl,'TSEQ',Xtr,ytr,orden);enl.cmd('STEP');l_va,a_va,_,_=pasada(enl,'PSEQ',Xva,yva,range(len(Xva)));t_micro_us+=us
                hist.append({'epoca':ep,'loss_tr':l_tr,'acc_tr':a_tr,'loss_va':l_va,'acc_va':a_va,'ms':us/1000.0})
                if ep==1 or ep%10==0:print(f'{ep:>6}{l_tr:>10.4f}{a_tr:>8.3f}{l_va:>10.4f}{a_va:>8.3f}{us/1000.0:>10.1f}')
        except KeyboardInterrupt:print('Detenido por el usuario.')

        print(f'Tiempo de computo de entrenamiento en el micro: {t_micro_us/1e6:.2f} s')
        print('\nBloqueando pesos...');enl.cmd('MODE,LOCK','OK,MODE,LOCK')
        l_va,a_va,cm_va,_=pasada(enl,'PSEQ',Xva,yva,range(len(Xva)))
        l_te,a_te,cm_te,us_te=pasada(enl,'PSEQ',Xte,yte,range(len(Xte)))
        res={'val':reporte('val',l_va,a_va,cm_va),'test':reporte('test',l_te,a_te,cm_te)}
        t_inf_us=us_te/max(1,len(Xte));print(f'\nTiempo de inferencia en el micro: {t_inf_us:.0f} us por secuencia')

        enl.enviar(f"TSEQ,{int(ytr[0])},"+','.join(str(int(v)) for v in Xtr[0].reshape(-1)));bloqueo=enl.leer();enl.enviar('STEP');bloqueo2=enl.leer()
        l_va2,_,_,_=pasada(enl,'PSEQ',Xva,yva,range(len(Xva)));igual=abs(l_va2-l_va)<1e-6
        print(f"LOCK: TSEQ -> '{bloqueo}' | STEP -> '{bloqueo2}' | los pesos {'NO cambiaron' if igual else 'CAMBIARON (revisar)'}")

        pesos,mean_export,std_export=recibir_pesos(enl,mean,std)
        pasos_export=Xtr.shape[1]
        archivo_npz=os.path.join(a.salida,'lstm_weights.npz');guardar_pesos_npz(pesos,mean_export,std_export,archivo_npz,pasos_export)
        archivo_h=os.path.join(a.salida,'lstm_weights.h');generar_weights_h(pesos,mean_export,std_export,archivo_h,pasos_export)
        resumen={'parametros':params,'memoria_modelo_cache_bytes':mem_modelo,'tiempo_entrenamiento_micro_us':t_micro_us,'tiempo_inferencia_us':t_inf_us,'epocas':len(hist),'config':vars(a),'arquitectura':{'M':M,'H':H,'D':D,'C':C,'G':G,'parametros_pesos':501},'normalizacion':{'mean':mean_export.tolist(),'std':std_export.tolist(),'escala':ESCALA},'val':res['val'],'test':res['test'],'lock_verificado':bool(igual),'pesos_guardados':True,'archivos':{'npz':'lstm_weights.npz','header':'lstm_weights.h'}}
        with open(os.path.join(a.salida,'resumen_micro.json'),'w',encoding='utf-8') as f:json.dump(resumen,f,indent=2,ensure_ascii=False)
        pd.DataFrame(hist).to_csv(os.path.join(a.salida,'curvas_micro.csv'),index=False)
        if hist:graficar(hist,cm_te,os.path.join(a.salida,'entrenamiento_micro.png'))
        print('\n========================================');print(' ENTRENAMIENTO COMPLETADO');print('========================================');print(f'Pesos: {archivo_npz}');print(f'Header C: {archivo_h}');print('\nEstos pesos corresponden al modelo entrenado y bloqueado en el micro.')
    finally:enl.cerrar()

if __name__=='__main__':main()
