"""
PRUEBA DE ROBUSTEZ: ¿qué tan estable es lo que aprendió cada modelo?
====================================================================
Se entrenan los dos modelos con los datos ORIGINALES (nunca ven perturbaciones):
    - MLP sin memoria  (promedio/RMS/máx/varianza)  -> 04_baseline_mlp.py
    - RNN/LSTM/GRU                                   -> 05_lstm.py
y se evalúan sobre secuencias perturbadas de forma controlada:
    ruido de medición, cambio de amplitud, cambio de velocidad,
    cambio de duración del patrón y pérdida ocasional de muestras.

Salida (carpeta resultados_robustez/):
    robustez_resultados.csv  -> accuracy por perturbación, nivel y modelo
    robustez.png             -> curvas accuracy vs intensidad + peor caso

Requiere, en la misma carpeta: 04_baseline_mlp.py, 05_lstm.py, perturbaciones.py
y dataset_train/val/test.csv.

Nota metodológica: aquí no se elige ningún hiperparámetro. Los modelos usan la
configuración que ya decidiste con los estudios (CFG_*); la prueba solo mide.
"""

import importlib
import os
import warnings

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from sklearn.metrics import accuracy_score

from perturbaciones import PERTURBACIONES

warnings.filterwarnings('ignore')

mlp = importlib.import_module('baseline_mlp')
lstm = importlib.import_module('LSTM')

# ==========================================
# CONFIGURACIÓN
# ==========================================
CONJUNTO = 'test'                 # 'val', 'test' o 'val+test' (ninguno se usa para entrenar)
SEMILLAS_MODELO = (0, 1, 2)       # se entrena cada modelo con varias semillas
N_REP = 20                        # repeticiones de las perturbaciones aleatorias
SEMILLA_PERTURBACION = 123
SALIDA = 'resultados_robustez'

# Cambia estas configuraciones por las que elegiste con los estudios de validación
CFG_MLP = dict(mlp.BASE)
CFG_RED = dict(lstm.BASE)

NOM_MLP = 'MLP (sin memoria)'
NOM_RED = CFG_RED['tipo'].upper()


# ==========================================
# PREDICCIÓN SOBRE SECUENCIAS NUEVAS (sin tocar el entrenamiento)
# ==========================================
def pred_mlp(res, X):
    Xf = res['esc'].transform(mlp.extraer(X, res['T'], res['canales']))
    return res['mlp'].predict(Xf)


def pred_red(res, X):
    V = lstm.recortar(X, res['T'], res['paso'], res['canales'])
    Xn = torch.tensor((V - res['media']) / res['std'], dtype=torch.float32)
    res['modelo'].eval()
    with torch.no_grad():
        return res['clases'][res['modelo'](Xn).argmax(dim=1).numpy()]


PRED = {NOM_MLP: pred_mlp, NOM_RED: pred_red}


def conjunto_evaluacion(datos):
    if CONJUNTO == 'val+test':
        X = np.concatenate([datos['val'][0], datos['test'][0]])
        y = np.concatenate([datos['val'][1], datos['test'][1]])
        return X, y
    return datos[CONJUNTO]


# ==========================================
# GRÁFICAS
# ==========================================
def graficar(tabla, ruta):
    nombres = list(PERTURBACIONES)
    modelos = [NOM_MLP, NOM_RED]
    colores = {NOM_MLP: 'tab:orange', NOM_RED: 'tab:blue'}

    fig, ax = plt.subplots(2, 3, figsize=(15, 8))
    ax = ax.ravel()
    for a, nombre in zip(ax, nombres):
        cfg = PERTURBACIONES[nombre]
        for m in modelos:
            t = tabla[(tabla.perturbacion == nombre) & (tabla.modelo == m)].sort_values('nivel')
            a.errorbar(t.nivel, t.acc_media, yerr=t.acc_std, marker='o', capsize=3,
                       color=colores[m], label=m)
        a.axvline(cfg['original'], color='gray', linestyle='--', alpha=0.6)
        a.set(title=nombre, xlabel=cfg['eje'], ylabel='accuracy', ylim=(0, 1.02))
        a.grid(alpha=0.3)
        a.legend(loc='lower center', fontsize=8)

    # Último panel: peor caso de cada perturbación
    a = ax[5]
    x = np.arange(len(nombres))
    ancho = 0.38
    for k, m in enumerate(modelos):
        peor = [tabla[(tabla.perturbacion == n) & (tabla.modelo == m)].acc_media.min()
                for n in nombres]
        a.bar(x + (k - 0.5) * ancho, peor, ancho, label=m, color=colores[m])
    orig = tabla[tabla.original].groupby('modelo').acc_media.mean()
    for m in modelos:
        a.axhline(orig[m], color=colores[m], linestyle=':', alpha=0.8)
    a.set_xticks(x)
    a.set_xticklabels(nombres, rotation=20)
    a.set(title='Peor caso por perturbación (líneas: accuracy original)', ylim=(0, 1.2))
    a.grid(alpha=0.3, axis='y')
    a.legend(fontsize=8, loc='upper left', ncol=2)

    fig.suptitle(f'Robustez a perturbaciones (conjunto: {CONJUNTO})')
    fig.tight_layout()
    fig.savefig(ruta, dpi=140)
    plt.close(fig)


# ==========================================
# MAIN
# ==========================================
def main():
    os.makedirs(SALIDA, exist_ok=True)
    datos = {k: lstm.cargar(v) for k, v in lstm.ARCHIVOS.items()}
    X, y = conjunto_evaluacion(datos)
    print(f"Conjunto de evaluación '{CONJUNTO}': {X.shape[0]} secuencias, "
          f"clases {dict(zip(*np.unique(y, return_counts=True)))}")

    print("\nEntrenando modelos con datos originales...")
    modelos = {NOM_MLP: [], NOM_RED: []}
    for s in SEMILLAS_MODELO:
        modelos[NOM_MLP].append(mlp.entrenar(datos, semilla=s, **CFG_MLP))
        modelos[NOM_RED].append(lstm.entrenar(datos, semilla=s, **CFG_RED))
        print(f"  semilla {s} lista")

    rng = np.random.default_rng(SEMILLA_PERTURBACION)
    filas = []
    for nombre, cfg in PERTURBACIONES.items():
        print(f"\n[{nombre}]  {cfg['eje']}")
        print(f"  {'nivel':<7}{NOM_MLP:>26}{NOM_RED:>22}")
        for nivel in cfg['niveles']:
            accs = {m: [] for m in modelos}
            for _ in range(1 if cfg['det'] else N_REP):
                Xp = cfg['f'](X, nivel, rng)        # la MISMA secuencia perturbada para ambos modelos
                for m, lista in modelos.items():
                    for res in lista:
                        accs[m].append(accuracy_score(y, PRED[m](res, Xp)))
            linea = f"  {nivel:<7}"
            for m in modelos:
                media, std = float(np.mean(accs[m])), float(np.std(accs[m]))
                filas.append(dict(perturbacion=nombre, nivel=nivel, modelo=m,
                                  acc_media=media, acc_std=std,
                                  original=bool(np.isclose(nivel, cfg['original']))))
                linea += f"{media:>18.3f} ± {std:.3f}"
            print(linea)

    tabla = pd.DataFrame(filas)
    tabla.to_csv(os.path.join(SALIDA, 'robustez_resultados.csv'), index=False)
    graficar(tabla, os.path.join(SALIDA, 'robustez.png'))

    # Resumen: caída de accuracy en el peor caso de cada perturbación
    print("\n=== RESUMEN: caída en el peor caso ===")
    print(f"{'perturbación':<13}{'modelo':<20}{'original':>9}{'peor':>8}{'caída':>8}")
    for nombre in PERTURBACIONES:
        for m in modelos:
            t = tabla[(tabla.perturbacion == nombre) & (tabla.modelo == m)]
            orig = t[t.original].acc_media.iloc[0]
            peor = t.acc_media.min()
            print(f"{nombre:<13}{m:<20}{orig:>9.3f}{peor:>8.3f}{orig - peor:>8.3f}")

    print(f"\nTodo guardado en la carpeta '{SALIDA}/'")


if __name__ == '__main__':
    main()