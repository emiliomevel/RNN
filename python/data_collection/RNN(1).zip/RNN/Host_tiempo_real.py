"""
EVALUACION EN TIEMPO REAL (NO entrena): potenciometros -> micro -> clase, comparado con el PC
===========================================================================================
El micro esta en MODE,RUN: lee los 3 potenciometros a 50 Hz, arma la ventana, ejecuta la
LSTM y manda la clase. Este script solo OBSERVA y compara:

    * micro            : clase calculada por el micro (float32, LSTM de lstm_pesos.h)
    * PC (mismos pesos): la misma ventana evaluada en numpy con lstm_pesos.npz
    * PC2 (opcional)   : un modelo entrenado aparte en PC (entrenar_pc.py -> lstm_pc.npz)
    * referencia automatica: reglas independientes sobre los valores de los potenciometros
      para identificar los patrones definidos en Dataset.py. En replay se usa la etiqueta
      conocida del CSV.

IMPORTANTE: en vivo la matriz compara la LSTM contra una referencia basada en reglas; no
reemplaza un test etiquetado de forma independiente. Usa --replay dataset_test.csv para
medir accuracy contra las etiquetas reales del dataset.

Uso:
    python Host_tiempo_real.py --pesos resultados_micro/lstm_weights.npz
    python Host_tiempo_real.py --pesos ... --replay dataset_test.csv
    python Host_tiempo_real.py --pesos ... --telemetria  # grafica referencia vs RPM y calcula respuesta a escalones

Teclas en vivo: q = terminar. La referencia en vivo se estima con reglas de patrones; no es etiqueta humana.
Genera gráficas de clasificación, tiempo, respuesta real por telemetría y/o respuesta ilustrativa.
"""

import argparse
import json
import os
import subprocess
import sys
import time

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import lstm_pesos

try:
    import msvcrt            # teclado en Windows
except ImportError:          # Linux/Mac: sin teclas (usa --replay)
    msvcrt = None

# ==========================================
# CONEXION CON EL MICRO (edita aqui)
# ==========================================
PUERTO = 'COM10'          # puerto serie del micro
BAUDIOS = 115200          # debe coincidir con DesireBaudrate del LPUART6 en el .mex

# Valores por defecto para ejecutar con el boton "Play" (sin argumentos). Los argumentos de
# la terminal, si los das, tienen prioridad.
ARCHIVO_PESOS = 'resultados_micro/lstm_weights.npz'   # pesos con los que el PC calcula (los mismos que el micro)
ARCHIVO_PC2 = None                   # p. ej. 'lstm_pc.npz' para comparar con un segundo modelo
CARGAR_PESOS = False                 # True = Python sube los pesos al micro; False = el micro usa los de flash


N_CLASES = 5
NOMBRES_CLASE = {0: "0 STOP/otros", 1: "1 Av.Rapido", 2: "2 Av.Lento",
                 3: "3 Rev.Rapida", 4: "4 Rev.Lenta"}


# ==========================================
# ENLACE (puerto serie o simulador)
# ==========================================
class Enlace:
    def __init__(self, puerto=None, sim=None, baud=115200, timeout=2.0):
        self.sim = sim is not None
        if self.sim:
            self.p = subprocess.Popen([sim], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                      text=True, bufsize=1)
        else:
            import serial
            self.s = serial.Serial(puerto, baud, timeout=timeout)
            time.sleep(0.5)
            self.s.reset_input_buffer()

    def timeout(self, seg):
        if not self.sim:
            self.s.timeout = seg

    def enviar(self, linea):
        if self.sim:
            self.p.stdin.write(linea + "\n")
            self.p.stdin.flush()
        else:
            self.s.write((linea + "\n").encode())

    def leer(self):
        if self.sim:
            r = self.p.stdout.readline()
            if r == "":
                raise ConnectionError("el simulador termino")
        else:
            r = self.s.readline().decode(errors='ignore')
            if r == "":
                raise TimeoutError("el micro no respondio a tiempo")
        return r.strip()

    def cmd(self, linea, esperado="OK"):
        """Envia una linea y exige una respuesta que empiece por `esperado`."""
        self.enviar(linea)
        r = self.leer()
        while r.startswith("READY"):          # el micro lo manda al arrancar: se descarta
            r = self.leer()
        if not r.startswith(esperado):
            raise RuntimeError(f"'{linea[:40]}' -> {r}")
        return r

    def cerrar(self):
        if self.sim:
            self.p.stdin.close()
            self.p.wait(timeout=5)
        else:
            self.s.close()



def cargar(archivo):
    df = pd.read_csv(archivo).sort_values(['sample_id', 'timestamp_ms'])
    ids = df['sample_id'].unique()
    X = df[['p1', 'p2', 'p3']].to_numpy().reshape(len(ids), -1, 3)
    y = df.groupby('sample_id')['label'].first().loc[ids].to_numpy()
    return X, y



def metricas_de_cm(cm):
    cm = np.asarray(cm, dtype=float)
    tp = np.diag(cm)
    prec = np.divide(tp, cm.sum(axis=0), out=np.zeros_like(tp), where=cm.sum(axis=0) > 0)
    rec = np.divide(tp, cm.sum(axis=1), out=np.zeros_like(tp), where=cm.sum(axis=1) > 0)
    f1 = np.divide(2 * prec * rec, prec + rec, out=np.zeros_like(tp), where=(prec + rec) > 0)
    return prec, rec, f1, cm.sum(axis=1)



PERIODO_MS = 20
N_PRE = 5
ESCALA_ENTRADA = 200.0       # TRAINER_SCALE: uint8 = round(sensor * 200)
UMBRAL_RANGO = 0.10          # igual que Dataset.py
TOL_NIVEL = 0.12             # tolerancia de inicio/final de los patrones
CANALES = ("P1", "P2", "P3")
PATRONES = {
    1: (("P1", "P2", "P3"), 0.0, 1.0),
    2: (("P1", "P2", "P3"), 0.0, 0.5),
    3: (("P3", "P2", "P1"), 1.0, 0.0),
    4: (("P3", "P2", "P1"), 1.0, 0.5),
}
RPM_POR_CLASE = {0: 0, 1: 150, 2: 50, 3: -150, 4: -50}


# ==========================================
# ENLACE TOLERANTE AL FLUJO DE LINEAS S/V/C
# ==========================================
def cmd(enl, linea, esperado="OK"):
    enl.enviar(linea)
    for _ in range(5000):
        r = enl.leer()
        if r.startswith(esperado):
            return r
        if r.startswith("ERR"):
            raise RuntimeError(f"'{linea[:40]}' -> {r}")
    raise RuntimeError(f"'{linea[:40]}' sin respuesta")


# ==========================================
# ANALISIS
# ==========================================
def matriz(y, p):
    cm = np.zeros((N_CLASES, N_CLASES), dtype=int)
    for a, b in zip(y, p):
        cm[int(a), int(b)] += 1
    return cm


def etiqueta_referencia_reglas(ventana, trigger, cuantizada=False):
    """Referencia automatica usando los patrones del Dataset.py, sin usar la prediccion LSTM.

    Retorna (clase, motivo). Clase 0 significa reposo/otro/incompleto si no coincide
    con alguno de los cuatro gestos definidos. El evento STATIC siempre es STOP.
    """
    if int(trigger) == 1:
        return 0, "evento estatico: STOP"

    x = np.asarray(ventana, dtype=float).reshape(-1, 3)
    if cuantizada:
        x = x / ESCALA_ENTRADA
    if x.shape[0] < 3:
        return 0, "ventana insuficiente"

    rango = np.ptp(x, axis=0)
    movidas = []
    t50 = {}
    for j, nombre in enumerate(CANALES):
        if rango[j] >= UMBRAL_RANGO:
            idx = np.flatnonzero(np.abs(x[:, j] - x[0, j]) >= rango[j] / 2.0)
            if idx.size:
                movidas.append(nombre)
                t50[nombre] = int(idx[0])
    orden = tuple(sorted(movidas, key=lambda nombre: t50[nombre]))

    if len(movidas) == 3:
        for clase, (orden_esp, inicio_esp, fin_esp) in PATRONES.items():
            if orden != orden_esp:
                continue
            inicio_ok = np.all(np.abs(x[0] - inicio_esp) <= TOL_NIVEL)
            fin_ok = np.all(np.abs(x[-1] - fin_esp) <= TOL_NIVEL)
            direccion_ok = (np.all(np.diff(x, axis=0).sum(axis=0) > 0) if clase in (1, 2)
                            else np.all(np.diff(x, axis=0).sum(axis=0) < 0))
            if inicio_ok and fin_ok and direccion_ok:
                return clase, f"patron valido: {'->'.join(orden)}; {inicio_esp:.1f}->{fin_esp:.1f}"

    ord_txt = "->".join(orden) if orden else "ninguna"
    return 0, f"STOP/otro: patron incompleto o no valido (orden={ord_txt})"


def reporte(nombre, cm):
    prec, rec, f1, soporte = metricas_de_cm(cm)
    acc = np.trace(cm) / max(1, cm.sum())
    print(f"\n--- {nombre} (n={int(cm.sum())}) | accuracy {acc:.3f} ---")
    print(f"{'clase':<14}{'precision':>10}{'recall':>9}{'f1':>8}{'n':>6}")
    for c in range(N_CLASES):
        print(f"{NOMBRES_CLASE[c]:<14}{prec[c]:>10.3f}{rec[c]:>9.3f}{f1[c]:>8.3f}{int(soporte[c]):>6}")
    print(f"{'macro':<14}{prec.mean():>10.3f}{rec.mean():>9.3f}{f1.mean():>8.3f}")
    return dict(accuracy=float(acc), n=int(cm.sum()), cm=cm.tolist(), precision=prec.tolist(),
                recall=rec.tolist(), f1=f1.tolist(), f1_macro=float(f1.mean()))


def estad(x):
    x = np.asarray(x, dtype=float)
    if len(x) == 0:
        return dict(media=None, p95=None, max=None)
    return dict(media=float(x.mean()), p95=float(np.percentile(x, 95)), max=float(x.max()))


def respuesta_escalon(t, y, t0, objetivo, t_fin):
    """Metricas de una respuesta de velocidad entre t0 y t_fin (s). y en rpm."""
    m = (t >= t0) & (t <= t_fin)
    if m.sum() < 5:
        return None
    tt, yy = t[m] - t0, y[m]
    y0 = yy[0]
    salto = objetivo - y0
    if abs(salto) < 1e-6:
        return None
    frac = (yy - y0) / salto
    def primero(umbral):
        i = np.argmax(frac >= umbral)
        return float(tt[i]) if frac[i] >= umbral else None
    t10, t90 = primero(0.1), primero(0.9)
    sobre = max(0.0, float((frac.max() - 1.0) * 100.0))
    fuera = np.where(np.abs(yy - objetivo) > 0.02 * abs(salto))[0]
    t_est = float(tt[fuera[-1]]) if len(fuera) else 0.0
    cola = yy[tt >= tt[-1] - 1.0]
    return dict(objetivo=objetivo, t_respuesta=(t90 - t10 if (t10 is not None and t90 is not None) else None),
                t_subida_90=t90, sobreimpulso_pct=sobre,
                t_establecimiento=t_est if t_est < tt[-1] else None,
                error_estable=float(cola.mean() - objetivo), desv_estable=float(cola.std()))


def graficar(cms, ruta):
    n = len(cms)
    fig, ax = plt.subplots(1, n, figsize=(4.6 * n, 4.2), squeeze=False)
    for a, (nombre, cm) in zip(ax[0], cms.items()):
        a.imshow(cm, cmap='Blues')
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                a.text(j, i, cm[i, j], ha='center', va='center',
                       color='white' if cm[i, j] > max(1, cm.max()) / 2 else 'black')
        a.set(title=nombre, xlabel='predicha', ylabel='real',
              xticks=range(cm.shape[1]), yticks=range(cm.shape[0]))
    fig.tight_layout()
    fig.savefig(ruta, dpi=140)
    plt.close(fig)


def graficar_respuesta_control(telem, ruta):
    """Grafica consigna solicitada y filtrada, RPM medida y PWM."""
    T=np.asarray(telem,dtype=float)
    if T.ndim!=2 or T.shape[0]<2 or T.shape[1]!=5:
        return False
    t,sp,sp_filtrada,rpm,pwm=T.T
    fig,ax=plt.subplots(2,1,figsize=(11,7),sharex=True)
    ax[0].plot(t,sp,label='Referencia solicitada (RPM)',linewidth=1.8)
    ax[0].plot(t,sp_filtrada,label='Referencia filtrada (RPM)',linewidth=1.5)
    ax[0].plot(t,rpm,label='RPM medida (encoder)',linewidth=1.5)
    ax[0].set_title('Respuesta del control: referencia vs velocidad medida')
    ax[0].set_ylabel('Velocidad (RPM)')
    ax[0].grid(True,alpha=0.3)
    ax[0].legend()
    ax[1].plot(t,pwm,label='PWM aplicado',linewidth=1.3)
    ax[1].set_xlabel('Tiempo desde el inicio de la prueba (s)')
    ax[1].set_ylabel('PWM')
    ax[1].grid(True,alpha=0.3)
    ax[1].legend()
    fig.tight_layout()
    fig.savefig(ruta,dpi=160)
    plt.close(fig)
    return True


def metricas_respuesta_control(telem):
    """Estima métricas por escalón detectando cambios en SP_User de la telemetría.

    La telemetría se consulta aproximadamente cada 100 ms, así que los tiempos
    tienen esa resolución aproximada. Para precisión alta, instrumentar el MCU.
    """
    T=np.asarray(telem,dtype=float)
    columnas=['escalon','t_inicio_s','referencia_rpm','rpm_previa','t_10_pct_s','t_90_pct_s',
              'tiempo_subida_10_90_s','sobreimpulso_pct','tiempo_establecimiento_2pct_s',
              'error_estacionario_rpm','desv_estacionaria_rpm','n_muestras']
    if T.ndim!=2 or T.shape[0]<6 or T.shape[1]!=5:
        return [],columnas
    t,sp,sp_filt,rpm,pwm=T.T
    indices=(np.where(np.abs(np.diff(sp))>=1.0)[0]+1).tolist()
    out=[]
    for i0,i in enumerate(indices):
        j=indices[i0+1] if i0+1<len(indices) else len(t)-1
        if i==0 or j-i<4:
            continue
        objetivo=float(sp[i]); y0=float(rpm[i-1]); delta=objetivo-y0
        if abs(delta)<1e-6:
            continue
        tt=t[i:j+1]-t[i]; yy=rpm[i:j+1]; frac=(yy-y0)/delta
        def primero(th):
            ix=np.flatnonzero(frac>=th)
            return float(tt[ix[0]]) if len(ix) else None
        t10,t90=primero(.1),primero(.9)
        banda=.02*abs(delta)
        fuera=np.flatnonzero(np.abs(yy-objetivo)>banda)
        if len(fuera)==0:
            t_est=0.0
        elif fuera[-1]>=len(tt)-1:
            t_est=None
        else:
            t_est=float(tt[fuera[-1]+1])
        sobre=max(0.0,float((np.max(frac)-1.0)*100.0))
        cola=yy[tt>=max(0.0,tt[-1]-1.0)]
        out.append(dict(escalon=len(out)+1,t_inicio_s=float(t[i]),referencia_rpm=objetivo,
                        rpm_previa=y0,t_10_pct_s=t10,t_90_pct_s=t90,
                        tiempo_subida_10_90_s=(t90-t10 if t10 is not None and t90 is not None else None),
                        sobreimpulso_pct=sobre,tiempo_establecimiento_2pct_s=t_est,
                        error_estacionario_rpm=float(np.mean(cola)-objetivo),
                        desv_estacionaria_rpm=float(np.std(cola)),n_muestras=int(len(yy))))
    return out,columnas


def graficar_metricas_control(rob, ruta, fuente='telemetria'):
    """Guarda metricas por escalon; la fuente puede ser telemetria o modelo ilustrativo."""
    fig, axes = plt.subplots(3, 2, figsize=(13, 10))
    titulo_fuente = 'telemetría MCU (muestreada)' if fuente == 'telemetria' else 'modelo ilustrativo, NO medido'
    fig.suptitle(f'Métricas de respuesta del control — {titulo_fuente}')
    if not rob:
        for ax in axes.flat:
            ax.axis('off')
        fig.text(0.5, 0.53,
                 'No hay escalones de referencia suficientes para calcular metricas.\n'
                 'Habilita el motor, ejecuta con --telemetria y provoca cambios de referencia.\n'
                 'Se requieren varios segundos de respuesta despues de cada cambio.',
                 ha='center', va='center', fontsize=12)
        fig.tight_layout(rect=(0, 0, 1, 0.92))
        fig.savefig(ruta, dpi=160)
        plt.close(fig)
        return False

    etiquetas = [f"{r['escalon']}\n{r['referencia_rpm']:+.0f} RPM" for r in rob]
    paneles = [
        ('t_90_pct_s', 'Tiempo de respuesta hasta 90 % (s)'),
        ('tiempo_subida_10_90_s', 'Tiempo de subida 10–90 % (s)'),
        ('tiempo_establecimiento_2pct_s', 'Tiempo de establecimiento ±2 % (s)'),
        ('sobreimpulso_pct', 'Sobreimpulso (%)'),
        ('error_estacionario_rpm', 'Error de seguimiento estacionario (RPM)'),
        ('desv_estacionaria_rpm', 'Estabilidad: desviación estable (RPM)'),
    ]
    for ax, (campo, titulo) in zip(axes.flat, paneles):
        valores = [np.nan if r.get(campo) is None else float(r[campo]) for r in rob]
        if not np.isfinite(valores).any():
            ax.text(0.5, 0.5, 'No calculable con las muestras disponibles', ha='center', va='center', wrap=True)
            ax.set_title(titulo)
            ax.set_xticks([])
            ax.set_yticks([])
            continue
        x = np.arange(len(valores))
        ax.bar(x, valores)
        ax.set_xticks(x, etiquetas)
        ax.set_title(titulo)
        ax.grid(True, axis='y', alpha=0.3)
        if campo == 'error_estacionario_rpm':
            ax.axhline(0.0, linewidth=1)
    for ax in list(axes.flat)[len(paneles):]:
        ax.axis('off')
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(ruta, dpi=160)
    plt.close(fig)
    return True



def graficar_sensores(muestras, ruta):
    """P1/P2/P3 capturados en tiempo real; el eje temporal usa 50 Hz nominales."""
    fig, ax = plt.subplots(figsize=(12, 5.5))
    M = np.asarray(muestras, dtype=float)
    if M.ndim != 2 or len(M) < 2 or M.shape[1] < 4:
        ax.text(0.5, 0.5, 'No hay suficientes muestras de sensores', ha='center', va='center')
        ax.set_axis_off()
    else:
        t = M[:, 0]
        for j, name in enumerate(('P1', 'P2', 'P3'), start=1):
            ax.plot(t, M[:, j], label=name, linewidth=1.25)
        ax.set_title('Potenciómetros capturados durante la prueba')
        ax.set_xlabel('Tiempo reconstruido (s; periodo nominal 20 ms)')
        ax.set_ylabel('Valor normalizado')
        ax.grid(True, alpha=0.3)
        ax.legend(ncol=3)
    fig.tight_layout()
    fig.savefig(ruta, dpi=150)
    plt.close(fig)


def graficar_metricas_clasificacion(cms, ruta):
    """Precisión, recall, F1 por clase y accuracy; CM normalizada por clase real."""
    nombres_cortos = ['STOP/otros', 'Av. rápida', 'Av. lenta', 'Rev. rápida', 'Rev. lenta']
    if not cms:
        fig, ax = plt.subplots(figsize=(10, 4))
        ax.text(0.5, 0.5, 'No hubo eventos etiquetables para calcular métricas', ha='center', va='center')
        ax.set_axis_off()
        fig.tight_layout(); fig.savefig(ruta, dpi=150); plt.close(fig)
        return
    fig, axes = plt.subplots(len(cms), 2, figsize=(14, max(5, 4.2 * len(cms))), squeeze=False)
    for row, (nombre, cm_raw) in enumerate(cms.items()):
        cm = np.asarray(cm_raw, dtype=float)
        prec, rec, f1, soporte = metricas_de_cm(cm)
        accuracy = float(np.trace(cm) / max(1.0, cm.sum()))
        ax = axes[row, 0]
        x = np.arange(N_CLASES); w = 0.24
        ax.bar(x - w, prec, width=w, label='Precision')
        ax.bar(x, rec, width=w, label='Recall')
        ax.bar(x + w, f1, width=w, label='F1-score')
        ax.set_xticks(x, nombres_cortos, rotation=18, ha='right')
        ax.set_ylim(0, 1.08)
        ax.set_ylabel('Puntuación (0–1)')
        ax.set_title(f'{nombre}\nAccuracy={accuracy:.3f} | n={int(cm.sum())}')
        ax.grid(True, axis='y', alpha=0.3)
        ax.legend(ncol=3, fontsize=8)
        ax = axes[row, 1]
        denom = cm.sum(axis=1, keepdims=True)
        cm_norm = np.divide(cm, denom, out=np.zeros_like(cm), where=denom > 0)
        im = ax.imshow(cm_norm, cmap='Blues', vmin=0, vmax=1)
        for i in range(N_CLASES):
            for j in range(N_CLASES):
                val = cm_norm[i, j]
                ax.text(j, i, f'{val:.0%}\n({int(cm[i,j])})', ha='center', va='center',
                        color='white' if val > 0.55 else 'black', fontsize=8)
        ax.set_xticks(range(N_CLASES), nombres_cortos, rotation=22, ha='right')
        ax.set_yticks(range(N_CLASES), nombres_cortos)
        ax.set_xlabel('Clase predicha'); ax.set_ylabel('Clase de referencia')
        ax.set_title('Matriz normalizada por clase real')
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.suptitle('Desempeño de clasificación', y=1.0, fontsize=14)
    fig.tight_layout()
    fig.savefig(ruta, dpi=160, bbox_inches='tight')
    plt.close(fig)


def graficar_tiempos(tim, ruta):
    """Resume tiempos medidos en MCU y latencias estimadas por longitud de ventana."""
    fig, axes = plt.subplots(1, 3, figsize=(16, 5.5))
    # 1) Costos internos del firmware, en ms.
    items = [
        ('Adquisición ADC', tim.get('adquisicion_adc_us', {}).get('media')),
        ('Actualizar ventana', tim.get('actualizar_ventana_us', {}).get('media')),
        ('Inferencia', tim.get('inferencia_us', {}).get('media')),
        ('Decisión→consigna MCU', tim.get('decision_a_actualizacion_consigna_us', {}).get('media')),
        ('Decisión→PWM (telemetría)', tim.get('decision_a_pwm_observado_ms', {}).get('media', None) * 1000.0
         if tim.get('decision_a_pwm_observado_ms', {}).get('media') is not None else None),
    ]
    vals = [np.nan if v is None else float(v) / 1000.0 for _, v in items]
    ax = axes[0]
    valid = [(n, v) for n, v in zip([q[0] for q in items], vals) if np.isfinite(v)]
    if valid:
        labels, vv = zip(*valid); xx = np.arange(len(vv))
        ax.bar(xx, vv)
        ax.set_xticks(xx, labels, rotation=25, ha='right')
        for i, v in enumerate(vv): ax.text(i, v, f'{v:.3f}', ha='center', va='bottom', fontsize=8)
    else:
        ax.text(0.5, 0.5, 'Sin tiempos medidos', ha='center', va='center')
    ax.set_title('Costos internos (medidos en MCU)')
    ax.set_ylabel('Tiempo medio (ms)'); ax.grid(True, axis='y', alpha=0.3)
    # 2) Latencia end-to-end de captura e inferencia.
    ax = axes[1]
    items2 = [
        ('Adquirir ventana', tim.get('latencia_ventana_s')),
        ('Sensor→decisión\n(estimada)', tim.get('latencia_sensor_decision_estimada_s')),
    ]
    val2 = [(n, float(v)) for n, v in items2 if v is not None and np.isfinite(v)]
    if val2:
        labels, vv = zip(*val2); xx = np.arange(len(vv)); ax.bar(xx, vv)
        ax.set_xticks(xx, labels)
        for i, v in enumerate(vv): ax.text(i, v, f'{v:.3f} s', ha='center', va='bottom', fontsize=8)
    else:
        ax.text(0.5, 0.5, 'No calculable', ha='center', va='center')
    ax.set_title('Latencia de la ventana completa'); ax.set_ylabel('Segundos (s)'); ax.grid(True, axis='y', alpha=0.3)
    # 3) Throughput: distinguir cota de cómputo y frecuencia observada.
    ax = axes[2]
    freqs = [
        ('Cota por\ninferencia mínima', tim.get('frecuencia_pico_computo_hz')),
        ('Eventos observados', tim.get('frecuencia_eventos_observada_hz')),
    ]
    vv = [(n, float(v)) for n, v in freqs if v is not None and np.isfinite(v)]
    if vv:
        labels, values = zip(*vv); xx = np.arange(len(values)); ax.bar(xx, values)
        ax.set_xticks(xx, labels)
        for i, v in enumerate(values): ax.text(i, v, f'{v:.2f} Hz', ha='center', va='bottom', fontsize=8)
    else:
        ax.text(0.5, 0.5, 'Sin inferencias', ha='center', va='center')
    ax.set_title('Frecuencia de inferencia')
    ax.set_ylabel('Hz'); ax.grid(True, axis='y', alpha=0.3)
    fig.suptitle('Desempeño temporal (la latencia de ventana es estimada)', y=1.02)
    fig.tight_layout()
    fig.savefig(ruta, dpi=160, bbox_inches='tight')
    plt.close(fig)


def graficar_decisiones(eventos, ruta):
    """Compara etiqueta de referencia y clase MCU por evento; marca errores."""
    ev = [e for e in eventos if e.get('verdad') is not None]
    fig, axes = plt.subplots(2, 1, figsize=(12, 7), gridspec_kw={'height_ratios': [2, 1]})
    if not ev:
        for ax in axes: ax.axis('off')
        fig.text(0.5, 0.5, 'No hay decisiones etiquetables', ha='center', va='center')
    else:
        x = np.arange(1, len(ev) + 1)
        truth = np.array([int(e['verdad']) for e in ev]); pred = np.array([int(e['micro']) for e in ev])
        wrong = truth != pred
        axes[0].plot(x, truth, 'o-', label='Referencia', markersize=4)
        axes[0].plot(x, pred, 's--', label='Clase MCU', markersize=4)
        if wrong.any(): axes[0].scatter(x[wrong], pred[wrong], marker='x', s=85, label='Decisión incorrecta')
        axes[0].set_yticks(range(N_CLASES), [NOMBRES_CLASE[i] for i in range(N_CLASES)])
        axes[0].set_xlabel('Número de evento'); axes[0].set_ylabel('Clase')
        axes[0].set_title(f'Decisiones por evento — errores: {int(wrong.sum())}/{len(ev)}')
        axes[0].grid(True, alpha=0.3); axes[0].legend(ncol=3, fontsize=8)
        errores_por_clase = [int(np.sum((truth == c) & wrong)) for c in range(N_CLASES)]
        axes[1].bar(np.arange(N_CLASES), errores_por_clase)
        axes[1].set_xticks(range(N_CLASES), ['STOP', 'Av.Rap', 'Av.Len', 'Rev.Rap', 'Rev.Len'])
        axes[1].set_ylabel('Número de errores'); axes[1].set_title('Errores agrupados por clase de referencia')
        axes[1].grid(True, axis='y', alpha=0.3)
    fig.tight_layout()
    fig.savefig(ruta, dpi=150, bbox_inches='tight')
    plt.close(fig)


def graficar_error_seguimiento(t, ref, rpm, ruta, fuente='telemetria'):
    """Error r(t)-y(t), real con telemetría o ilustrativo con modelo simple."""
    t = np.asarray(t, dtype=float); ref = np.asarray(ref, dtype=float); rpm = np.asarray(rpm, dtype=float)
    fig, ax = plt.subplots(figsize=(11, 4.5))
    if len(t) and len(t) == len(ref) == len(rpm):
        err = ref - rpm
        mae = float(np.mean(np.abs(err))); rmse = float(np.sqrt(np.mean(err ** 2)))
        ax.plot(t, err, label='Error de seguimiento: referencia − RPM', linewidth=1.3)
        ax.axhline(0, linewidth=1)
        ax.set_title(('Error de seguimiento medido por telemetría' if fuente == 'telemetria'
                      else 'Error de seguimiento estimado — modelo ilustrativo, NO medido')
                     + f' | MAE={mae:.1f} RPM, RMSE={rmse:.1f} RPM')
        ax.set_xlabel('Tiempo (s)'); ax.set_ylabel('Error (RPM)'); ax.grid(True, alpha=0.3); ax.legend()
    else:
        ax.text(0.5, 0.5, 'No hay datos para el error de seguimiento', ha='center', va='center'); ax.set_axis_off()
    fig.tight_layout(); fig.savefig(ruta, dpi=150); plt.close(fig)


def simular_control_ilustrativo(eventos, n_muestras, tau_s=0.35):
    """Modelo de primer orden para visualizar una respuesta hipotética, nunca una medición.

    La velocidad responde a la consigna con constante de tiempo tau_s. El modelo no reproduce
    fricción, saturación, carga, PWM, encoder ni sobreimpulso reales; por defecto no genera sobreimpulso.
    """
    dt = PERIODO_MS / 1000.0
    max_t_muestra = max(0.0, (int(n_muestras) - 1) * dt)
    t_eventos = [float(e.get('t_muestra_s', e.get('n_muestra', 0) * dt)) for e in eventos]
    t_end = max(max_t_muestra + 2.5, (max(t_eventos) + 2.5) if t_eventos else 2.5)
    t = np.arange(0.0, t_end + dt / 2, dt)
    ref = np.zeros_like(t)
    prev = 0.0
    for ev, te in sorted(zip(eventos, t_eventos), key=lambda z: z[1]):
        prev = float(ev.get('rpm', RPM_POR_CLASE.get(int(ev.get('micro', 0)), 0)))
        ref[t >= te] = prev
    rpm = np.zeros_like(t)
    if tau_s <= 0: tau_s = 0.35
    alpha = 1.0 - np.exp(-dt / float(tau_s))
    for i in range(1, len(t)):
        rpm[i] = rpm[i - 1] + alpha * (ref[i - 1] - rpm[i - 1])
    return t, ref, rpm


def graficar_respuesta_aproximada(t, ref, rpm, tau_s, ruta):
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.plot(t, ref, label='Consigna derivada de eventos (RPM)', linewidth=1.8)
    ax.plot(t, rpm, label='RPM hipotéticas: modelo de 1er orden', linewidth=1.5)
    ax.set_title(f'Respuesta ROBÓTICA ILUSTRATIVA — NO MEDIDA (tau asumida={tau_s:.2f} s)')
    ax.set_xlabel('Tiempo reconstruido (s)'); ax.set_ylabel('RPM')
    ax.grid(True, alpha=0.3); ax.legend()
    ax.text(0.01, 0.02, 'No usar como resultado experimental. Para medición real ejecutar --telemetria.',
            transform=ax.transAxes, fontsize=9, bbox={'facecolor': 'white', 'alpha': 0.7, 'edgecolor': 'none'})
    fig.tight_layout(); fig.savefig(ruta, dpi=160); plt.close(fig)


def retraso_pwm_observado(telem, evento, umbral=5.0):
    """Latencia aproximada decisión→primer cambio de PWM visible a través de telemetría."""
    if len(telem) < 2 or not evento.get('aplicado'):
        return None
    arr = np.asarray(telem, dtype=float)
    t0 = evento.get('t_host_s')
    if t0 is None: return None
    pre = arr[arr[:, 0] < float(t0)]
    post = arr[arr[:, 0] >= float(t0)]
    if len(post) == 0: return None
    base_pwm = float(pre[-1, 4]) if len(pre) else float(post[0, 4])
    target = float(evento.get('rpm', 0))
    for row in post:
        ref_ok = abs(float(row[1]) - target) <= 2.0
        pwm_changed = abs(float(row[4]) - base_pwm) >= umbral
        if ref_ok and pwm_changed:
            return max(0.0, float(row[0]) - float(t0))
    return None


def resumen_robotico(telem, rob):
    """Resumen global de tracking y estabilidad, sobre telemetría real del MCU."""
    if len(telem) < 2:
        return {'fuente': 'sin telemetría suficiente'}
    T = np.asarray(telem, dtype=float)
    sp, rpm = T[:, 1], T[:, 3]
    err = sp - rpm
    return {
        'fuente': 'telemetría MCU solicitada aproximadamente cada 100 ms',
        'error_seguimiento_mae_rpm': float(np.mean(np.abs(err))),
        'error_seguimiento_rmse_rpm': float(np.sqrt(np.mean(err ** 2))),
        'error_seguimiento_max_abs_rpm': float(np.max(np.abs(err))),
        'desv_estacionaria_media_rpm': (float(np.mean([r['desv_estacionaria_rpm'] for r in rob])) if rob else None),
        'n_escalones_evaluados': len(rob),
        'nota': 'La resolución de respuesta queda limitada por el muestreo de telemetría (~10 Hz).'
    }


def abrir_imagen(ruta):
    """Abre un PNG con la aplicacion predeterminada si se solicita."""
    try:
        if sys.platform.startswith('win'):
            os.startfile(os.path.abspath(ruta))
        elif sys.platform == 'darwin':
            subprocess.Popen(['open', os.path.abspath(ruta)])
        else:
            subprocess.Popen(['xdg-open', os.path.abspath(ruta)])
        return True
    except Exception as exc:
        print(f"[AVISO] No pude abrir {ruta}: {exc}")
        return False


# ==========================================
# MAIN
# ==========================================
def _ruta(nombre):
    """Busca el archivo tal cual, y si no esta, en resultados_micro/ y con los nombres lstm_weights /
    lstm_pesos, tanto en la carpeta actual como junto a este script."""
    base = os.path.basename(nombre)
    carpetas = [os.path.dirname(nombre) or '.', '.', 'resultados_micro']
    nombres = [base] + [n for n in ('lstm_weights.npz', 'lstm_pesos.npz') if n != base]
    aqui = os.path.dirname(os.path.abspath(__file__))
    vistos = []
    for raiz in ('', aqui):
        for c in carpetas:
            for n in nombres:
                ruta = os.path.join(raiz, c, n) if raiz else os.path.join(c, n)
                if os.path.isfile(ruta):
                    print(f"Pesos: {os.path.abspath(ruta)}")
                    return ruta
                vistos.append(ruta)
    raise SystemExit("[ERROR] No encuentro el archivo de pesos. Busque en:\n  " + "\n  ".join(vistos[:8]) +
                     "\nEdita ARCHIVO_PESOS al inicio del script.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--puerto', default=PUERTO)
    ap.add_argument('--sim', default=None)
    ap.add_argument('--baud', type=int, default=BAUDIOS)
    ap.add_argument('--pesos', default=ARCHIVO_PESOS, help=f'.npz con los pesos (por defecto {ARCHIVO_PESOS})')
    ap.add_argument('--pc', default=ARCHIVO_PC2, help='lstm_pc.npz: modelo entrenado aparte en PC (opcional)')
    ap.add_argument('--cargar', action='store_true', default=CARGAR_PESOS, help='sube los pesos al micro antes de empezar')
    ap.add_argument('--sin_estatico', action='store_true', help='apaga el disparo por quietud (STOP estatico)')
    ap.add_argument('--replay', default=None, help='CSV a reproducir en vez de usar los potenciometros')
    ap.add_argument('--pad', type=int, default=120, help='replay: muestras de reposo antes de cada secuencia')
    ap.add_argument('--telemetria', action='store_true', help='pide T al micro (requiere APP_ENABLE_MOTOR=1); guarda graficas de control')
    ap.add_argument('--abrir-graficas', action='store_true', help='abre las graficas PNG al finalizar (ademas de guardarlas)')
    ap.add_argument('--live-paso', type=int, default=5, help='LIVE_PASO de firmware; la ventana cruda es RNN_T*LIVE_PASO muestras')
    ap.add_argument('--tau-estimada-s', type=float, default=0.35, help='constante de tiempo SOLO para la respuesta robótica ilustrativa sin telemetría')
    ap.add_argument('--sin-modelo-aproximado', action='store_true', help='no generar la gráfica hipotética si no llega telemetría del motor')
    ap.add_argument('--salida', default='resultados_tiempo_real')
    a = ap.parse_args()
    os.makedirs(a.salida, exist_ok=True)

    a.pesos = _ruta(a.pesos)
    if a.pc:
        a.pc = _ruta(a.pc)
    P, mean, std, dims = lstm_pesos.cargar_npz(a.pesos)
    H = dims[0]
    P2 = None
    if a.pc:
        P2, mean2, std2, dims2 = lstm_pesos.cargar_npz(a.pc)

    enl = Enlace(puerto=a.puerto, sim=a.sim, baud=a.baud, timeout=2.0)
    try:
        for intento in range(5):
            try:
                cmd(enl, "PING")
                break
            except (RuntimeError, TimeoutError):
                if intento == 4:
                    raise
        enl.timeout(5.0)
        info = cmd(enl, "INFO", "INFO").split(",")
        print(f"Micro: {info[1]} | {info[2]} parametros | modelo+cache {info[8]} B")
        # INFO,fw,parametros,H,D,C,T,M,memoria,...; las matrices de pesos no dependen de T,
        # pero el tamaño de la ventana UART sí. Se alinea T al firmware para permitir pruebas
        # exploratorias con pesos aprendidos en otra longitud temporal.
        if len(info) >= 8:
            H_fw, D_fw, C_fw, T_fw, M_fw = [int(info[i]) for i in (3, 4, 5, 6, 7)]
            H_npz, D_npz, C_npz, T_npz, M_npz = dims
            if (H_fw, D_fw, C_fw, M_fw) != (H_npz, D_npz, C_npz, M_npz):
                raise RuntimeError(
                    f"La arquitectura de pesos no coincide con firmware: NPZ (H={H_npz},D={D_npz},C={C_npz},M={M_npz}) "
                    f"vs MCU (H={H_fw},D={D_fw},C={C_fw},M={M_fw})."
                )
            if T_npz != T_fw:
                print(f"[AVISO] El NPZ indica T={T_npz}, pero el firmware usa T={T_fw}. "
                      "Se probarán los mismos pesos con la ventana disponible del MCU; el resultado no es equivalente "
                      "al modelo evaluado con T del entrenamiento.")
                dims = (H_npz, D_npz, C_npz, T_fw, M_npz)
        if a.cargar:
            cmd(enl, "MODE,TRAIN")
            lstm_pesos.subir(enl, np.concatenate([P[k].ravel() for k in
                             ("w_ih", "w_hh", "b", "w1", "b1", "w2", "b2")]), mean, std)
            print("Pesos del NPZ subidos al micro para esta ejecución.")
        else:
            print("[INFO] --cargar no está activo: el MCU usará los pesos que ya tenga cargados/en Flash; "
                  "el NPZ se usa para la comparación PC. Usa --cargar si quieres probar los pesos de este archivo en el MCU.")
        cmd(enl, "SRC," + ("FEED" if (a.replay or a.sim) else "ADC"))
        cmd(enl, "LIVECFG," + ("0" if a.sin_estatico else "1"))
        cmd(enl, "MODE,RUN")

        eventos, muestras, telem = [], [], []
        us_push, us_adc = [], []
        if a.live_paso < 1:
            raise SystemExit('--live-paso debe ser >= 1')
        ventana_muestras = int(dims[3]) * a.live_paso  # debe coincidir con LIVE_VENTANA=RNN_T*LIVE_PASO
        estado = dict(etiqueta_csv=None, ult_V=None, evento_pendiente=None, t0=time.monotonic(), n=0)

        def registrar_evento(ev):
            """Registra C despues de recibir su S correspondiente, para usar la ventana cruda completa."""
            cls, conf, us_inf = ev['cls'], ev['conf'], ev['us_inf']
            trig, rpm, aplicado = ev['trig'], ev['rpm'], ev['aplicado']
            us_act, us_vent = ev['us_act'], ev['us_vent']
            W = ev['W'].reshape(1, dims[3], dims[4])
            pc1 = int(lstm_pesos.predecir(P, mean, std, W, H)[0])
            pc2 = int(lstm_pesos.predecir(P2, mean2, std2, W, H)[0]) if P2 is not None else None

            if int(trig) == 1:
                verdad, motivo_ref, fuente_ref = 0, "evento estatico: STOP", "regla_estatico"
            elif a.replay and estado['etiqueta_csv'] is not None:
                verdad, motivo_ref, fuente_ref = int(estado['etiqueta_csv']), "etiqueta conocida del CSV", "dataset_csv"
            else:
                # S se transmite despues de C. Ahora la muestra actual ya esta en muestras;
                # se pueden evaluar los 100/250 puntos a 50 Hz, sin perder resolucion temporal.
                if len(muestras) >= ventana_muestras:
                    x_ref = np.asarray(muestras[-ventana_muestras:], dtype=float)[:, 1:4]
                    motivo_fuente = "ventana_sensor_completa"
                else:
                    x_ref = ev['W'].reshape(dims[3], dims[4]).astype(float) / ESCALA_ENTRADA
                    motivo_fuente = "ventana_RNN_submuestreada"
                verdad, motivo_ref = etiqueta_referencia_reglas(x_ref, trig, cuantizada=False)
                fuente_ref = "reglas_sensores"
                motivo_ref = f"{motivo_ref}; {motivo_fuente}"

            registro = dict(n_muestra=estado['n'],
                            t_muestra_s=max(0.0, (estado['n'] - 1) * PERIODO_MS / 1000.0),
                            t_host_s=ev.get('t_host_s', time.monotonic() - estado['t0']),
                            disparo='quieto' if trig else 'onset',
                            verdad=verdad, fuente_referencia=fuente_ref, motivo_referencia=motivo_ref,
                            micro=cls, pc=pc1, pc2=pc2, conf=conf / 1e4,
                            us_inf=us_inf, us_ventana=us_vent, rpm=rpm,
                            aplicado=aplicado, us_decision=us_act)
            eventos.append(registro)
            ok = 'OK' if cls == verdad else 'DIF'
            print(f"\n[evento {len(eventos):>3} {registro['disparo']:<6}] ref {verdad} ({motivo_ref}) | "
                  f"micro {cls} ({conf / 1e4:.2f}) | PC {pc1}" + (f" | PC2 {pc2}" if pc2 is not None else "") +
                  f" | {us_inf / 1000:.2f} ms | rpm {rpm:+d} {'(aplicado)' if aplicado else '(ignorado)'} {ok}")

        def manejar(r):
            k = r[0]
            if k == "S":
                p = [int(v) / 1e4 for v in r[1:4]]
                estado['n'] += 1
                muestras.append([estado['n'] * PERIODO_MS / 1000.0, *p, int(r[4])])
                us_push.append(int(r[5]))
                if int(r[6]) > 0:
                    us_adc.append(int(r[6]))
                if not a.replay:
                    print(f"\rP1 {p[0]:.3f} P2 {p[1]:.3f} P3 {p[2]:.3f} | estado {r[4]} | referencia automatica   ",
                          end='', flush=True)
                # El firmware manda C antes de S en la misma muestra; finalizar ahora garantiza
                # que la ventana usada como referencia incluya esa muestra mas reciente.
                if estado['evento_pendiente'] is not None:
                    ev = estado['evento_pendiente']
                    estado['evento_pendiente'] = None
                    registrar_evento(ev)
            elif k == "V":
                estado['ult_V'] = np.array([int(v) for v in r[1:]], dtype=np.uint8)
            elif k == "C":
                cls, conf, us_inf, trig, rpm, aplicado, us_act, us_vent = (int(v) for v in r[1:9])
                if estado['ult_V'] is None or estado['ult_V'].size != dims[3] * dims[4]:
                    raise RuntimeError("La trama V no tiene el tamano esperado para la ventana RNN")
                estado['evento_pendiente'] = dict(cls=cls, conf=conf, us_inf=us_inf, trig=trig,
                                                  rpm=rpm, aplicado=aplicado, us_act=us_act,
                                                  us_vent=us_vent, t_host_s=time.monotonic() - estado['t0'],
                                                  W=estado['ult_V'].copy())
            elif k == 'TEL' and len(r) == 5:
                try:
                    telem.append([time.monotonic() - estado['t0'], *[float(v) for v in r[1:5]]])
                except ValueError:
                    print(f"\n[AVISO] Telemetria TEL invalida: {r}")
            elif k and (k[0].isdigit() or k[0] == '-') and len(r) == 4:
                # Compatibilidad con firmware anterior que no anteponia TEL.
                try:
                    telem.append([time.monotonic() - estado['t0'], *[float(v) for v in r]])
                except ValueError:
                    pass

        if a.replay:
            X, y = cargar(a.replay)
            Xr = np.clip(np.rint(X * 1e4), 0, 40000).astype(int)
            print(f"Reproduciendo {len(X)} secuencias de '{a.replay}' por el pipeline del micro...")
            for i in range(len(X)):
                estado['etiqueta_csv'] = int(y[i])
                cmd(enl, "MODE,RUN")                                          # reinicia el pipeline (como un reposo largo)
                seq = [Xr[i][0]] * a.pad + list(Xr[i])                       # reposo + secuencia completa
                for m in seq:
                    enl.enviar("FEED," + ",".join(str(int(v)) for v in m))
                    while True:                                            # V y C (si hay) y al final la S
                        r = enl.leer().split(",")
                        manejar(r)
                        if r[0] == "S":
                            break
        else:
            print("Listo. Mueve los potenciometros siguiendo los patrones definidos en Dataset.py; no necesitas etiquetar a mano. q = terminar.\n")
            t_telem = 0.0
            try:
                while True:
                    if msvcrt and msvcrt.kbhit():
                        c = msvcrt.getwch().lower()
                        if c == 'q':
                            break
                    if a.telemetria and time.time() - t_telem > 0.1:
                        enl.enviar("T")
                        t_telem = time.time()
                    try:
                        manejar(enl.leer().split(","))
                    except TimeoutError:
                        pass
            except KeyboardInterrupt:
                pass

        # Detener el actuador al terminar la captura, antes de generar archivos.
        try:
            cmd(enl, "STOP", "OK,idle")
            print("\nSTOP confirmado por el micro; referencia y PWM enviados a cero.")
        except Exception as exc:
            print(f"\n[AVISO] No se pudo confirmar STOP al finalizar la prueba: {exc}")

        # ---------------- resultados ----------------
        print("\n\n=========== RESULTADOS ===========")
        if not a.replay:
            print("Nota: la referencia de la matriz en vivo se obtiene con reglas de patron sobre los sensores; no es etiqueta humana independiente.")
        cms, res = {}, {}
        ev = [e for e in eventos if e['verdad'] is not None]
        if ev:
            yv = [e['verdad'] for e in ev]
            cms['micro vs referencia'] = matriz(yv, [e['micro'] for e in ev])
            nombre_ref = 'etiquetas del CSV' if a.replay else 'reglas de patrones'
            res['micro'] = reporte(f'MICRO vs {nombre_ref}', cms['micro vs referencia'])
            cms['PC (mismos pesos) vs referencia'] = matriz(yv, [e['pc'] for e in ev])
            res['pc'] = reporte(f'PC (mismos pesos) vs {nombre_ref}', cms['PC (mismos pesos) vs referencia'])
            if P2 is not None:
                cms['PC2 vs referencia'] = matriz(yv, [e['pc2'] for e in ev])
                res['pc2'] = reporte(f'PC2 vs {nombre_ref}', cms['PC2 vs referencia'])
            print("\nEventos por clase de referencia:", {NOMBRES_CLASE[i]: int(sum(e['verdad'] == i for e in ev)) for i in range(N_CLASES)})
            res['metodo_referencia'] = 'dataset_csv' if a.replay else 'reglas_sobre_ventana_sensor; referencia automatica, no verdad absoluta'
            res['por_disparo'] = {d: dict(n=len(q), accuracy=float(np.mean([e['micro'] == e['verdad'] for e in q])))
                                  for d in ('onset', 'quieto') for q in [[e for e in ev if e['disparo'] == d]] if q}
            print('\nPor tipo de disparo:', {d: (v['n'], round(v['accuracy'], 3)) for d, v in res['por_disparo'].items()})
            res['decisiones_incorrectas'] = int(sum(e['micro'] != e['verdad'] for e in ev))
            res['decisiones_incorrectas_por_clase'] = {
                NOMBRES_CLASE[c]: int(sum((int(e['verdad']) == c) and (int(e['micro']) != int(e['verdad'])) for e in ev))
                for c in range(N_CLASES)
            }
        if eventos:
            res['acuerdo_micro_pc'] = float(np.mean([e['micro'] == e['pc'] for e in eventos]))
            if P2 is not None:
                res['acuerdo_micro_pc2'] = float(np.mean([e['micro'] == e['pc2'] for e in eventos]))
            print(f"\nAcuerdo micro vs PC (mismos pesos): {res['acuerdo_micro_pc']:.3f}  "
                  f"({len(eventos)} eventos)")
        dur = max(1e-9, estado['n'] * PERIODO_MS / 1000.0)
        inf = estad([e['us_inf'] for e in eventos])
        inf_vals = [float(e['us_inf']) for e in eventos if e.get('us_inf') is not None and float(e['us_inf']) > 0]
        calc_us = estad([e['us_inf'] + e['us_ventana'] for e in eventos])
        ventana_s = max(0, ventana_muestras - 1) * PERIODO_MS / 1000.0
        sensor_decision_s = ventana_s + ((calc_us['media'] or 0.0) / 1e6)
        freq_peak = (1e6 / min(inf_vals)) if inf_vals else None
        freq_mean_compute = (1e6 / inf['media']) if inf['media'] else None
        events_hz = len(eventos) / dur
        tim = dict(
            inferencia_us=inf,
            actualizar_ventana_us=estad(us_push),
            adquisicion_adc_us=estad(us_adc),
            decision_a_actualizacion_consigna_us=estad([e['us_decision'] for e in eventos]),
            # Cota de cálculo: 1 / menor tiempo de inferencia observado; NO significa frecuencia real de eventos.
            frecuencia_pico_computo_hz=freq_peak,
            frecuencia_media_por_inferencia_hz=freq_mean_compute,
            frecuencia_eventos_observada_hz=events_hz,
            latencia_ventana_s=ventana_s,
            latencia_sensor_decision_estimada_s=sensor_decision_s,
            latencia_calculo_us=calc_us,
            eventos_por_s=events_hz,
            carga_cpu_pct=float(100.0 * ((np.mean(us_push) if us_push else 0) + (np.mean(us_adc) if us_adc else 0)
                                       + (inf['media'] or 0) * len(eventos) / max(1, estado['n']))
                                       / (PERIODO_MS * 1000.0)),
            nota_latencia='La latencia de ventana se estima desde el primer hasta el último punto a 50 Hz. No es el instante físico exacto del inicio del gesto.'
        )
        res['tiempos'] = tim
        print("\nTiempos (us): inferencia media %.0f max %.0f | actualizar ventana media %.1f | ADC media %s | "
              "decision->actualizacion consigna media %.1f" % (inf['media'] or 0, inf['max'] or 0,
              np.mean(us_push) if us_push else 0, ("%.1f" % np.mean(us_adc)) if us_adc else "n/d (replay)",
              tim['decision_a_actualizacion_consigna_us']['media'] or 0))
        print(f"Latencia estimada: ventana {tim['latencia_ventana_s']:.2f} s + cálculo {sensor_decision_s-ventana_s:.3f} s "
              f"= sensor→decisión ~{sensor_decision_s:.2f} s | cota por cálculo {freq_peak or 0:.1f} Hz | "
              f"eventos observados {events_hz:.3f} Hz | carga CPU estimada ~{tim['carga_cpu_pct']:.2f} %")
        print("Nota: decision_a_actualizacion_consigna mide el tiempo de la función MCU para fijar la referencia, "
              "no el tiempo mecánico hasta que el motor responde. Este último se aproxima con telemetría PWM/RPM.")

        archivos_graficas = []
        # Sensores y desempeño temporal/clasificación (se generan aunque no haya telemetría de motor).
        archivo_sens = os.path.join(a.salida, 'senales_potenciometros.png')
        graficar_sensores(muestras, archivo_sens); archivos_graficas.append(archivo_sens)
        archivo_time = os.path.join(a.salida, 'metricas_temporales.png')
        graficar_tiempos(tim, archivo_time); archivos_graficas.append(archivo_time)
        archivo_dec = os.path.join(a.salida, 'decisiones_clasificador.png')
        graficar_decisiones(eventos, archivo_dec); archivos_graficas.append(archivo_dec)
        archivo_clas = os.path.join(a.salida, 'metricas_clasificacion.png')
        graficar_metricas_clasificacion(cms, archivo_clas); archivos_graficas.append(archivo_clas)

        telemetria_real = bool(a.telemetria and len(telem) >= 2)
        if telemetria_real:
            T = np.asarray(telem, dtype=float)
            archivo_telem = os.path.join(a.salida, 'telemetria.csv')
            pd.DataFrame(T, columns=['t_s','sp_usuario','sp_filtrado','rpm','pwm']).to_csv(archivo_telem, index=False)
            archivo_resp = os.path.join(a.salida, 'respuesta_control.png')
            graficar_respuesta_control(T, archivo_resp); archivos_graficas.append(archivo_resp)
            rob, columnas_rob = metricas_respuesta_control(T)
            res['robotico'] = rob
            res['robotico_resumen'] = resumen_robotico(telem, rob)
            res['fuente_metricas_roboticas'] = 'telemetria_real_mcu_muestreada_aprox_10Hz'
            archivo_err = os.path.join(a.salida, 'error_seguimiento.png')
            graficar_error_seguimiento(T[:,0], T[:,1], T[:,3], archivo_err, fuente='telemetria')
            archivos_graficas.append(archivo_err)
            # Añade latencia aproximada hasta que la telemetría refleja una consigna y PWM nuevos.
            retrasos = [retraso_pwm_observado(telem, e) for e in eventos]
            retrasos = [v for v in retrasos if v is not None]
            res['tiempos']['decision_a_pwm_observado_ms'] = estad(np.asarray(retrasos) * 1000.0)
            res['robotico_resumen']['decision_a_pwm_observado_ms'] = res['tiempos']['decision_a_pwm_observado_ms']
            # Se vuelve a guardar la gráfica temporal para incluir la latencia observada decisión→PWM si se pudo estimar.
            graficar_tiempos(res['tiempos'], archivo_time)
            archivo_metricas = os.path.join(a.salida, 'metricas_respuesta_control.csv')
            pd.DataFrame(rob, columns=columnas_rob).to_csv(archivo_metricas, index=False)
            archivo_plot_metricas = os.path.join(a.salida, 'metricas_control.png')
            graficar_metricas_control(rob, archivo_plot_metricas, fuente='telemetria')
            archivos_graficas.append(archivo_plot_metricas)
            print(f"\nTelemetría recibida: {len(T)} muestras ({T[-1,0]-T[0,0]:.1f} s aprox.)")
            print(f"CSV: {os.path.abspath(archivo_telem)}")
            print(f"Gráfica de respuesta real: {os.path.abspath(archivo_resp)}")
            print(f"Gráfica de error de seguimiento: {os.path.abspath(archivo_err)}")
            print(f"Métricas de respuesta: {os.path.abspath(archivo_plot_metricas)}")
            print(f"Métricas por escalón: {os.path.abspath(archivo_metricas)}")
            if rob:
                print('\n--- RESPUESTA DEL CONTROL (estimada desde telemetría real) ---')
                for rr in rob:
                    print(f"Escalón {rr['escalon']}: referencia={rr['referencia_rpm']:+.0f} RPM | "
                          f"subida 10-90%={rr['tiempo_subida_10_90_s']} s | "
                          f"establecimiento={rr['tiempo_establecimiento_2pct_s']} s | "
                          f"sobreimpulso={rr['sobreimpulso_pct']:.1f}% | "
                          f"error estacionario={rr['error_estacionario_rpm']:+.1f} RPM | "
                          f"desv. estable={rr['desv_estacionaria_rpm']:.1f} RPM")
            else:
                print('No se detectaron escalones con suficientes muestras de telemetría. Cambia de referencia y deja responder al motor varios segundos.')
        else:
            print("\nNo hay telemetría real suficiente. Se calculará una respuesta hipotética de primer orden para visualizar métricas aproximadas; NO equivale a medición del robot.")
            res['fuente_metricas_roboticas'] = 'modelo_hipotetico_no_medicion'
            if eventos and not a.sin_modelo_aproximado:
                tau = max(0.01, float(a.tau_estimada_s))
                tt, ref_sim, rpm_sim = simular_control_ilustrativo(eventos, estado['n'], tau_s=tau)
                archivo_resp = os.path.join(a.salida, 'respuesta_control_estimada.png')
                graficar_respuesta_aproximada(tt, ref_sim, rpm_sim, tau, archivo_resp)
                archivos_graficas.append(archivo_resp)
                archivo_err = os.path.join(a.salida, 'error_seguimiento_estimado.png')
                graficar_error_seguimiento(tt, ref_sim, rpm_sim, archivo_err, fuente='modelo')
                archivos_graficas.append(archivo_err)
                T_sim = np.column_stack([tt, ref_sim, ref_sim, rpm_sim, np.zeros_like(tt)])
                rob_sim, columnas_rob = metricas_respuesta_control(T_sim)
                res['robotico'] = rob_sim
                res['robotico_resumen'] = {
                    'fuente': 'modelo hipotético de primer orden; no es medición',
                    'tau_asumida_s': tau,
                    'error_seguimiento_mae_rpm': float(np.mean(np.abs(ref_sim-rpm_sim))),
                    'error_seguimiento_rmse_rpm': float(np.sqrt(np.mean((ref_sim-rpm_sim)**2))),
                    'desv_estacionaria_media_rpm': (float(np.mean([r['desv_estacionaria_rpm'] for r in rob_sim])) if rob_sim else None),
                    'nota': 'Sobreimpulso y establecimiento son propiedades de un modelo simplificado; no deben reportarse como datos medidos del motor.'
                }
                archivo_metricas = os.path.join(a.salida, 'metricas_control_estimadas.csv')
                pd.DataFrame(rob_sim, columns=columnas_rob).to_csv(archivo_metricas, index=False)
                archivo_plot_metricas = os.path.join(a.salida, 'metricas_control_estimadas.png')
                graficar_metricas_control(rob_sim, archivo_plot_metricas, fuente='modelo')
                archivos_graficas.append(archivo_plot_metricas)
                print(f"Respuesta ilustrativa (NO medida): {os.path.abspath(archivo_resp)}")
                print(f"Métricas ilustrativas (NO medidas): {os.path.abspath(archivo_plot_metricas)}")
            else:
                res['robotico_resumen'] = {
                    'fuente': 'sin telemetria y sin eventos suficientes',
                    'nota': 'Ejecuta con --telemetria para medir el motor o permite el modelo ilustrativo.'
                }
            if a.telemetria:
                print('[AVISO] --telemetria estaba activo pero no llegaron suficientes muestras TEL. Comprueba APP_ENABLE_MOTOR=1 y que el firmware responda a T con TEL,...')
            else:
                print('Para graficar la respuesta REAL del motor, usa --telemetria y firmware con APP_ENABLE_MOTOR=1.')

        res['configuracion_evaluacion'] = {
            'ventana_lstm_pasos_en_micro': int(dims[3]),
            'live_paso': int(a.live_paso),
            'ventana_cruda_estimada_muestras': int(ventana_muestras),
            'periodo_muestreo_nominal_ms': PERIODO_MS,
            'tau_modelo_ilustrativo_s': float(a.tau_estimada_s),
            'referencia_clasificacion': ('etiquetas CSV' if a.replay else 'reglas automáticas sobre sensores; no es verdad absoluta'),
            'telemetria_real_habilitada': bool(telemetria_real),
        }
        pd.DataFrame(eventos).to_csv(os.path.join(a.salida, 'eventos.csv'), index=False)
        pd.DataFrame(muestras, columns=['t_s', 'p1', 'p2', 'p3', 'estado']).to_csv(
            os.path.join(a.salida, 'muestras.csv'), index=False)
        with open(os.path.join(a.salida, 'resumen_tiempo_real.json'), 'w', encoding='utf-8') as f:
            json.dump(res, f, indent=2, ensure_ascii=False)
        archivo_cm = None
        if cms:
            archivo_cm=os.path.join(a.salida,'matrices_confusion.png')
            graficar(cms, archivo_cm)
            archivos_graficas.append(archivo_cm)
            print(f"Matriz de confusion (conteos): {os.path.abspath(archivo_cm)}")
        print(f"\nGráficas generadas:")
        for archivo in archivos_graficas:
            print(f"  {os.path.abspath(archivo)}")
        print(f"\nResultados guardados en: {os.path.abspath(a.salida)}/")
        if a.abrir_graficas:
            for archivo in archivos_graficas:
                abrir_imagen(archivo)
    finally:
        try:
            enl.timeout(0.2)
            enl.enviar("STOP")
            limite = time.monotonic() + 0.8
            while time.monotonic() < limite:
                try:
                    r_stop = enl.leer().split(",")
                except TimeoutError:
                    break
                if r_stop[:2] == ["OK", "idle"]:
                    break
        except Exception:
            pass
        enl.cerrar()


if __name__ == '__main__':
    main()
