"""
DIVISIÓN DEL DATASET EN ENTRENAMIENTO / VALIDACIÓN / PRUEBA
===========================================================
- Entrada : dataset_completo.csv  (sample_id, timestamp_ms, p1, p2, p3, label)
- Salida  : dataset_train.csv (70 %), dataset_val.csv (15 %), dataset_test.csv (15 %)
            (porcentajes sobre el TOTAL de muestras)

La división se hace por sample_id (una secuencia completa nunca se parte) y
estratificada por clase, para que cada conjunto tenga la misma proporción de
clases. El conjunto de prueba no se toca hasta la evaluación final.
"""

import sys

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

ARCHIVO = 'dataset_completo.csv'
SEMILLA = 42
FRAC_TEST = 0.15           # 15 % del total
FRAC_VAL = 0.15            # 15 % del total (queda dentro del 85 % restante)
COLS = ['p1', 'p2', 'p3']


def limpiar(df):
    """Elimina muestras con valores inválidos, longitud distinta o etiquetas mezcladas."""
    total = df['sample_id'].nunique()
    df = df.replace([np.inf, -np.inf], np.nan)

    # 1. Valores inválidos (NaN / inf)
    malos = df.loc[df[COLS + ['label']].isna().any(axis=1), 'sample_id'].unique()
    df = df[~df['sample_id'].isin(malos)]

    # 2. Todas las muestras con la misma longitud
    largos = df.groupby('sample_id').size()
    L = int(largos.mode().iloc[0])
    malos_len = largos[largos != L].index
    df = df[~df['sample_id'].isin(malos_len)]

    # 3. Una sola etiqueta por muestra
    n_etq = df.groupby('sample_id')['label'].nunique()
    malos_lab = n_etq[n_etq != 1].index
    df = df[~df['sample_id'].isin(malos_lab)]

    print(f"Muestras leídas: {total} | descartadas: {total - df['sample_id'].nunique()} "
          f"(inválidas {len(malos)}, longitud {len(malos_len)}, etiqueta {len(malos_lab)})")
    print(f"Longitud de ventana: {L} muestras\n")
    return df


def main():
    df = pd.read_csv(ARCHIVO)
    df = limpiar(df)

    resumen = df.groupby('sample_id')['label'].first()
    ids = resumen.index.to_numpy()
    y = resumen.to_numpy()

    if pd.Series(y).value_counts().min() < 3:
        print("[ERROR] Alguna clase tiene menos de 3 muestras; no se puede estratificar.")
        sys.exit(1)

    # 85 % (entrenamiento + validación) / 15 % prueba
    ids_tv, ids_test, y_tv, _ = train_test_split(
        ids, y, test_size=FRAC_TEST, stratify=y, random_state=SEMILLA)

    # De ese 85 %, tomar 15 % DEL TOTAL como validación (15/85 de lo que queda)
    ids_train, ids_val = train_test_split(
        ids_tv, test_size=FRAC_VAL / (1.0 - FRAC_TEST), stratify=y_tv, random_state=SEMILLA)

    conjuntos = {'train': ids_train, 'val': ids_val, 'test': ids_test}
    etiqueta_de = resumen.to_dict()

    print(f"{'conjunto':<8} {'muestras':>9} {'%':>6}   muestras por clase")
    for nombre, grupo in conjuntos.items():
        sub = df[df['sample_id'].isin(grupo)].sort_values(['sample_id', 'timestamp_ms'])
        sub.to_csv(f'dataset_{nombre}.csv', index=False)
        por_clase = pd.Series([etiqueta_de[i] for i in grupo]).value_counts().sort_index()
        det = ' | '.join(f"{c}:{n}" for c, n in por_clase.items())
        print(f"{nombre:<8} {len(grupo):>9} {100 * len(grupo) / len(ids):>5.1f}%   {det}")

    print("\nArchivos generados: dataset_train.csv, dataset_val.csv, dataset_test.csv")


if __name__ == '__main__':
    main()