"""
PERTURBACIONES CONTROLADAS PARA LA PRUEBA DE ROBUSTEZ
=====================================================
Todas las funciones reciben X de forma (n, T, M) en la escala original del
sensor (0-1, antes de normalizar) y devuelven un X' de la MISMA forma.

Firma común:  f(X, nivel, rng) -> X'
    nivel : intensidad de la perturbación
    rng   : np.random.Generator (solo lo usan las perturbaciones aleatorias)

Cada perturbación tiene un nivel "original" que no modifica nada
(ruido 0, ganancia 1, velocidad 1, ...), para tener el punto de referencia.
"""

import numpy as np

UMBRAL_GESTO = 0.04     # desviación mínima para considerar que "ya empezó / ya terminó" el gesto


def ruido(X, sigma, rng):
    """Ruido de medición gaussiano de desviación `sigma` (escala 0-1) en cada muestra.
    Se suma después del filtro del micro, así que es un caso más severo que el real."""
    return X + rng.normal(0.0, sigma, X.shape)


def ganancia(X, g, rng):
    """Cambio de amplitud: todos los canales se multiplican por `g` (error de ganancia/calibración).
    Ojo: ganancias grandes cambian el significado del gesto (100 % -> 70 % se parece a 50 %)."""
    return X * g


def velocidad(X, s, rng):
    """Cambio de velocidad: se remuestrea TODO el eje de tiempo con factor `s`.
    s > 1: más rápido (el gesto ocurre antes y el resto de la ventana queda en reposo).
    s < 1: más lento (el gesto se estira y el final de la ventana se corta)."""
    n, T, M = X.shape
    t = np.arange(T) * s
    out = np.empty_like(X)
    for i in range(n):
        for c in range(M):
            out[i, :, c] = np.interp(t, np.arange(T), X[i, :, c])   # fuera de rango mantiene el borde
    return out


def _estirar_gesto(x, factor):
    """Estira/comprime solo el tramo activo del gesto, manteniendo fijo el inicio."""
    T = len(x)
    mov_ini = np.abs(x - x[0]).max(axis=1) > UMBRAL_GESTO
    mov_fin = np.abs(x - x[-1]).max(axis=1) > UMBRAL_GESTO
    if not mov_ini.any() or not mov_fin.any():
        return x.copy()                       # no hay gesto (p. ej. reposo)
    ini = int(np.argmax(mov_ini))
    fin = T - int(np.argmax(mov_fin[::-1]))   # primer índice ya en el reposo final
    if fin - ini < 2:
        return x.copy()

    seg = x[ini:fin]
    L = len(seg)
    L2 = max(2, int(round(L * factor)))
    tt = np.linspace(0, L - 1, L2)
    nuevo = np.stack([np.interp(tt, np.arange(L), seg[:, c]) for c in range(x.shape[1])], axis=1)
    out = np.concatenate([x[:ini], nuevo, x[fin:]])      # se conserva la cola original (reposo)
    if len(out) < T:                                     # gesto más corto: se rellena con el valor final
        out = np.concatenate([out, np.repeat(x[-1:], T - len(out), axis=0)])
    return out[:T]


def duracion(X, factor, rng):
    """Cambio de duración del patrón: el tramo activo del gesto dura `factor` veces lo original.
    A diferencia de `velocidad`, el inicio del gesto no se mueve y el tiempo sobrante/faltante
    se compensa con reposo al final."""
    return np.stack([_estirar_gesto(x, factor) for x in X])


def perdida_muestras(X, p, rng):
    """Pérdida ocasional de muestras: cada muestra se pierde con probabilidad `p` y se
    repite la última recibida (lo que haría un receptor al perder un paquete)."""
    n, T, M = X.shape
    out = X.copy()
    perdidas = rng.random((n, T)) < p
    perdidas[:, 0] = False
    for t in range(1, T):
        m = perdidas[:, t]
        out[m, t, :] = out[m, t - 1, :]
    return out


PERTURBACIONES = {
    'ruido': dict(f=ruido, niveles=[0.0, 0.01, 0.02, 0.05, 0.10, 0.20], original=0.0,
                  det=False, eje='σ del ruido (escala 0-1)'),
    'amplitud': dict(f=ganancia, niveles=[0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3], original=1.0,
                     det=True, eje='ganancia'),
    'velocidad': dict(f=velocidad, niveles=[0.5, 0.7, 0.85, 1.0, 1.2, 1.5, 2.0], original=1.0,
                      det=True, eje='factor de velocidad (>1 = más rápido)'),
    'duracion': dict(f=duracion, niveles=[0.5, 0.75, 1.0, 1.25, 1.5], original=1.0,
                     det=True, eje='factor de duración del gesto'),
    'perdida': dict(f=perdida_muestras, niveles=[0.0, 0.02, 0.05, 0.10, 0.20, 0.30], original=0.0,
                    det=False, eje='probabilidad de perder una muestra'),
}