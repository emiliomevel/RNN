import pandas as pd

archivos = ['dataset_completosin.csv', 'dataset_clase24.csv']
partes, offset = [], 0

for a in archivos:
    df = pd.read_csv(a)
    df['sample_id'] += offset          # evita IDs repetidos
    offset = df['sample_id'].max()
    partes.append(df)

pd.concat(partes).to_csv('dataset_completo.csv', index=False)