"""
PESOS DE LA LSTM: volcado desde el micro, header .h, copia en PC y forward en numpy
===================================================================================
Lo usan Host_entrenamiento.py (al terminar de entrenar) y, mas adelante, el script
de evaluacion en tiempo real. Orden plano de los parametros (igual que RnnParams en C):
    w_ih[4H][M], w_hh[4H][H], b[4H], w1[D][H], b1[D], w2[C][D], b2[C]
"""

import struct
import time

import numpy as np

ESCALA = 200.0


def _bits_a_float(h):
    return struct.unpack('<f', struct.pack('<I', int(h, 16)))[0]


def volcar(enl, n_params):
    """Pide DUMP al micro. Devuelve (pesos_planos float32, mean float32[M], std float32[M])."""
    enl.enviar("DUMP")
    w = np.full(n_params, np.nan, dtype=np.float32)
    mean = std = None
    while True:
        r = enl.leer().split(",")
        if r[0] == "W":
            i = int(r[1])
            for k, h in enumerate(r[2:]):
                w[i + k] = _bits_a_float(h)
        elif r[0] == "N":
            v = np.array([_bits_a_float(h) for h in r[1:]], dtype=np.float32)
            mean, std = v[:len(v) // 2], v[len(v) // 2:]
        elif r[0] == "DONE":
            break
        else:
            raise RuntimeError("DUMP -> " + ",".join(r))
    if np.isnan(w).any() or mean is None:
        raise RuntimeError("DUMP incompleto: se perdieron lineas")
    return w, mean, std


def subir(enl, w, mean, std):
    """Carga pesos y normalizacion en el micro (debe estar en MODE,TRAIN)."""
    def hx(x):
        return format(struct.unpack('<I', struct.pack('<f', float(x)))[0], '08X')
    for i in range(0, len(w), 8):
        enl.cmd(f"LOAD,{i}," + ",".join(hx(v) for v in w[i:i + 8]))
    enl.cmd("LOADN," + ",".join(hx(v) for v in list(mean) + list(std)))


def separar(w, H, D, C, M):
    """Vector plano -> diccionario de matrices (mismas formas que la estructura de C)."""
    G = 4 * H
    cortes = [("w_ih", (G, M)), ("w_hh", (G, H)), ("b", (G,)),
              ("w1", (D, H)), ("b1", (D,)), ("w2", (C, D)), ("b2", (C,))]
    P, k = {}, 0
    for nombre, forma in cortes:
        n = int(np.prod(forma))
        P[nombre] = np.asarray(w[k:k + n], dtype=np.float32).reshape(forma)
        k += n
    if k != len(w):
        raise ValueError(f"se esperaban {k} parametros y llegaron {len(w)}")
    return P


def _sig(x):
    return (1.0 / (1.0 + np.exp(-x))).astype(np.float32)


def probabilidades(P, mean, std, Xq, H):
    """Forward en numpy (float32) igual que RNN_Forward. Xq: uint8 (n, T, M). Devuelve (n, C)."""
    x = ((Xq.astype(np.float32) / np.float32(ESCALA)) - mean) / std
    n, T, _ = x.shape
    h = np.zeros((n, H), np.float32)
    c = np.zeros((n, H), np.float32)
    for t in range(T):
        a = x[:, t] @ P["w_ih"].T + h @ P["w_hh"].T + P["b"]
        i, f = _sig(a[:, :H]), _sig(a[:, H:2 * H])
        g, o = np.tanh(a[:, 2 * H:3 * H]), _sig(a[:, 3 * H:])
        c = f * c + i * g
        h = (o * np.tanh(c)).astype(np.float32)
    d1 = np.maximum(h @ P["w1"].T + P["b1"], 0)
    z = d1 @ P["w2"].T + P["b2"]
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return (e / e.sum(axis=1, keepdims=True)).astype(np.float32)


def predecir(P, mean, std, Xq, H):
    return probabilidades(P, mean, std, Xq, H).argmax(axis=1)


def _arr(a):
    """Matriz/vector -> literal de C con float32 que ida y vuelta exacto (%.9g)."""
    a = np.asarray(a, dtype=np.float32)
    if a.ndim == 1:
        return "{" + ", ".join(f"{v:.9g}f" for v in a) + "}"
    return "{\n    " + ",\n    ".join(_arr(f) for f in a) + "\n}"


def escribir_header(ruta, P, mean, std, dims):
    H, D, C, T, M = dims
    texto = f"""#ifndef LSTM_PESOS_H
#define LSTM_PESOS_H

/* ============================================================================
 * PESOS ENTRENADOS DE LA LSTM  (generado por Host_entrenamiento.py {time.strftime('%Y-%m-%d %H:%M')})
 * No editar a mano. Arquitectura: LSTM({H}) + Dense({D}) + {C} clases, {T} pasos x {M} sensores.
 * Debe coincidir con rnn_cfg.h (RNN_H, RNN_D, RNN_C, RNN_T, RNN_M).
 * Entrada: uint8 = round(valor*{int(ESCALA)}) -> valor/{int(ESCALA)} -> (valor - LSTM_MEAN)/LSTM_STD
 * Compuertas en filas: i, f, g, o.
 * ============================================================================ */

#define LSTM_PESOS_H_DIM  {H}U, {D}U, {C}U, {T}U, {M}U

static const float LSTM_MEAN[{M}] = {_arr(mean)};
static const float LSTM_STD [{M}] = {_arr(std)};

static const float LSTM_W_IH[{4 * H}][{M}] = {_arr(P['w_ih'])};
static const float LSTM_W_HH[{4 * H}][{H}] = {_arr(P['w_hh'])};
static const float LSTM_B   [{4 * H}]     = {_arr(P['b'])};
static const float LSTM_W1  [{D}][{H}]     = {_arr(P['w1'])};
static const float LSTM_B1  [{D}]          = {_arr(P['b1'])};
static const float LSTM_W2  [{C}][{D}]     = {_arr(P['w2'])};
static const float LSTM_B2  [{C}]          = {_arr(P['b2'])};

#endif /* LSTM_PESOS_H */
"""
    with open(ruta, 'w', encoding='utf-8') as f:
        f.write(texto)


def guardar_npz(ruta, w, mean, std, dims):
    np.savez(ruta, w=w, mean=mean, std=std, dims=np.array(dims))


def cargar_npz(ruta, T=20):
    """Lee el .npz. Dos formatos validos:
      A) el de este modulo:  w (vector plano), mean, std, dims = (H, D, C, T, M)
      B) matrices sueltas:   w_ih, w_hh, b, w1, b1, w2, b2, mean, std y escalares H, D, C, M
         (T no viene en el archivo: se usa el argumento T, 20 pasos = ventana de 100 / paso 5)
    Tambien acepta las claves alternativas weights/pesos, media, desv."""
    d = np.load(ruta)

    def clave(*nombres):
        for n in nombres:
            if n in d.files:
                return d[n]
        raise KeyError(f"'{ruta}' no tiene ninguna de las claves {nombres}. Claves encontradas: {d.files}")

    mean = np.asarray(clave('mean', 'media'), dtype=np.float32)
    std = np.asarray(clave('std', 'desv'), dtype=np.float32)

    if 'w_ih' in d.files:                                   # formato B
        P = {k: np.asarray(d[k], dtype=np.float32) for k in ("w_ih", "w_hh", "b", "w1", "b1", "w2", "b2")}
        H, M = P["w_hh"].shape[1], P["w_ih"].shape[1]
        D, C = P["w1"].shape[0], P["w2"].shape[0]
        T = int(d['T']) if 'T' in d.files else T
        return P, mean, std, (H, D, C, T, M)

    w = clave('w', 'weights', 'pesos')                      # formato A
    H, D, C, T, M = [int(v) for v in clave('dims', 'dimensiones')]
    return separar(w, H, D, C, M), mean, std, (H, D, C, T, M)


def desde_torch(modelo, media, std, T):
    """Convierte la Red de LSTM.py (PyTorch, tipo 'lstm') al formato de este modulo.
    Devuelve (w_plano, mean, std, dims). Orden de compuertas de PyTorch: i, f, g, o (igual que el micro);
    el sesgo del micro es b_ih + b_hh."""
    sd = {k: v.detach().cpu().numpy().astype(np.float32) for k, v in modelo.state_dict().items()}
    w_ih, w_hh = sd['rnn.weight_ih_l0'], sd['rnn.weight_hh_l0']
    b = sd['rnn.bias_ih_l0'] + sd['rnn.bias_hh_l0']
    w = np.concatenate([w_ih.ravel(), w_hh.ravel(), b, sd['fc1.weight'].ravel(), sd['fc1.bias'],
                        sd['fc2.weight'].ravel(), sd['fc2.bias']]).astype(np.float32)
    H, M = w_hh.shape[1], w_ih.shape[1]
    D, C = sd['fc1.weight'].shape[0], sd['fc2.weight'].shape[0]
    return (w, np.asarray(media, dtype=np.float32).ravel(), np.asarray(std, dtype=np.float32).ravel(),
            (H, D, C, T, M))
