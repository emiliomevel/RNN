#ifndef APP_COMMAND_HANDLER_H_
#define APP_COMMAND_HANDLER_H_

/* ============================================================================
 * INTERPRETE DE COMANDOS (sin dependencias del hardware: se prueba en PC)
 *
 * Una linea = un comando, campos separados por comas. Todo numero es ENTERO
 * (sin punto decimal): loss y lr se envian x1e6, tiempos en microsegundos.
 *
 * Python -> micro
 *   PING
 *   INFO
 *   NORM,m0,m1,m2,s0,s1,s2        media/desv. del train (x1e6)
 *   INIT,semilla                  pesos nuevos
 *   CFG,lr_x1e6,clip_x1e6,lote
 *   MODE,TRAIN | MODE,LOCK        habilita / bloquea el entrenamiento
 *   TSEQ,etiqueta,v0..v59         ENTRENA con una secuencia (forward+BPTT)
 *   STEP                          aplica el lote parcial pendiente (fin de epoca)
 *   PSEQ,etiqueta,v0..v59         SOLO forward (val / test / en vivo)
 *   DUMP                          devuelve pesos (W,..), normalizacion (N,..) y DONE,dump
 *   LOAD,idx,h0..h7               carga pesos (hex float32); solo en MODE,TRAIN
 *   LOADN,m0,m1,m2,s0,s1,s2       carga media/desv. (hex float32); solo en MODE,TRAIN
 *   MODE,RUN                      entrena bloqueado + pipeline en vivo + control
 *   SRC,FEED | SRC,ADC            origen de las muestras en RUN (FEED = Python las inyecta)
 *   FEED,p1,p2,p3                 muestra inyectada (x10000); responde con la linea S
 *   LIVECFG,0|1                   disparo por quietud (STOP estatico) apagado/encendido
 *   STOP                          responde OK,idle
 *   (con APP_ENABLE_MOTOR) R<rpm>, S, T   comandos del motor
 *
 * micro -> Python
 *   OK[,...]   ERR,motivo   READY,...
   en RUN (una linea por muestra, mas eventos):
 *   S,p1,p2,p3,estado,us_ventana,us_adc      (x10000; estado: 0 warmup 1 armado 2 grabando 3 rearmar)
 *   V,v0..v59                                 ventana que vio la red (uint8)
 *   C,clase,conf_x1e4,us_inf,disparo,rpm,aplicado,us_decision,us_ventana
 *   (orden por muestra: V y C, si hay evento, y SIEMPRE al final la S)
 *   R,loss_x1e6,clase_predicha,tiempo_us      (respuesta a TSEQ y PSEQ)
 *   INFO,...
 * ============================================================================ */

void Command_Init(void);
void Command_HandleLine(char *line);
void Command_Service(void);              /* llamar en cada vuelta del main: muestreo en MODE,RUN */     /* modifica `line` al separar los campos */

#endif /* APP_COMMAND_HANDLER_H_ */
