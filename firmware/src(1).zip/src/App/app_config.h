#ifndef APP_CONFIG_H_
#define APP_CONFIG_H_

/* ============================================================================
 * CONFIGURACIÓN DE LA APLICACIÓN
 *
 * APP_ENABLE_MOTOR
 *   0 : etapa de ENTRENAMIENTO. No se inicializan encoder, PWM ni PID, y el
 *       motor queda apagado. Solo corre UART + red neuronal.
 *   1 : etapa de CONTROL. Se activa el lazo del motor (y los comandos R/S/T).
 * ============================================================================ */

#ifndef APP_ENABLE_MOTOR
#define APP_ENABLE_MOTOR   1
#endif

/* ============================================================================
 * APP_ENABLE_SENSORS
 *   0 : sin ADC (solo entrenamiento / pruebas por UART).
 *   1 : se inicializa el ADC de los 3 potenciometros y existe el modo MODE,RUN
 *       con muestras reales (requiere el ADC configurado en el .mex, ver README).
 *
 * APP_AUTORUN
 *   1 : al encender, el micro entra solo en MODE,RUN (pesos de lstm_pesos.h ya en
 *       flash, entrenamiento bloqueado). Funcionamiento autonomo, sin Python.
 *
 * RUN -> CONTROL (paso 9). Clase -> referencia de velocidad del motor (RPM),
 * igual que las etiquetas del recolector. Solo se actua si la confianza >= CONF_MIN.
 * Un disparo ESTATICO (perillas quietas) solo puede ordenar STOP (clase 0).
 * ============================================================================ */
#ifndef APP_ENABLE_SENSORS
#define APP_ENABLE_SENSORS 1
#endif
#ifndef APP_AUTORUN
#define APP_AUTORUN        1
#endif
#define APP_RPM_POR_CLASE  { 0, 150, 50, -150, -50 }   /* clases 0..4 */
#define APP_CONF_MIN       0.60f

#endif /* APP_CONFIG_H_ */
