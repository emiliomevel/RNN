/* ============================================================================
 * MAIN
 * Solo inicializa y reparte trabajo. Nada de lógica aquí.
 *
 *   APP_ENABLE_MOTOR = 0 (app_config.h): etapa de entrenamiento, motor apagado.
 *   APP_ENABLE_MOTOR = 1               : se activan encoder, PWM y el lazo PID.
 * ============================================================================ */

#include "Clock_Ip.h"
#include "IntCtrl_Ip.h"
#include "Siul2_Port_Ip.h"
#include "OsIf.h"
#include "Lpuart_Uart_Ip.h"

#include "app_config.h"
#include "uart_protocol.h"
#include "command_handler.h"
#if (APP_ENABLE_SENSORS != 0)
#include "app_sensors.h"
#endif

#if (APP_ENABLE_MOTOR != 0)
#include "Siul2_Icu_Ip.h"
#include "Pit_Ip.h"
#include "encoder.h"
#include "pid_control.h"
#endif

#define SIUL2_CONFIG   g_pin_mux_InitConfigArr_PortContainer_0_BOARD_InitPeripherals
#define SIUL2_PINS     NUM_OF_CONFIGURED_PINS_PortContainer_0_BOARD_InitPeripherals

int main(void)
{
    static char line[UART_RX_BUFFER_SIZE];     /* static: no consume pila */

    /* 1. Reloj (misma secuencia que ya te funcionaba) */
    Clock_Ip_Init(Clock_Ip_aClockConfig);
    Clock_Ip_InitClock(Clock_Ip_aClockConfig);
    while (CLOCK_IP_PLL_LOCKED != Clock_Ip_GetPllStatus())
    {
        __asm volatile ("nop");
    }
    Clock_Ip_DistributePll();
    OsIf_Init(NULL_PTR);

    /* 2. Interrupciones */
    IntCtrl_Ip_Init(&IntCtrlConfig_0);
    IntCtrl_Ip_EnableIrq(LPUART6_IRQn);
#if (APP_ENABLE_SENSORS != 0)
    IntCtrl_Ip_EnableIrq(ADC0_IRQn);
#endif
#if (APP_ENABLE_MOTOR != 0)
    IntCtrl_Ip_EnableIrq(SIUL_0_IRQn);
    IntCtrl_Ip_EnableIrq(PIT0_IRQn);
#endif

    /* 3. Pines */
    Siul2_Port_Ip_Init(SIUL2_PINS, SIUL2_CONFIG);

    /* 4. UART (LPUART6) + protocolo */
    Lpuart_Uart_Ip_Init(LPUART_INSTANCE, &Lpuart_Uart_Ip_xHwConfigPB_6);
    UART_Protocol_Init();

#if (APP_ENABLE_SENSORS != 0)
    Sensors_Init();                         /* ADC0 + calibracion + notificacion fin de cadena */
#endif

    /* 5. Red neuronal / entrenador */
    Command_Init();

#if (APP_ENABLE_MOTOR != 0)
    /* 6. Control del motor: encoder, PWM, PID y PIT de 10 ms */
    Encoder_Init();
    Siul2_Icu_Ip_Init(0, &Siul2_Icu_Ip_0_Config_PB);
    Siul2_Icu_Ip_EnableInterrupt(0, 1);
    Siul2_Icu_Ip_EnableInterrupt(0, 2);
    Siul2_Icu_Ip_EnableNotification(0, 1);
    Siul2_Icu_Ip_EnableNotification(0, 2);

    Emios_Mcl_Ip_Init(INSTANCE_0, &Emios_Mcl_Ip_Sa_1_Config);
    Emios_Pwm_Ip_InitChannel(EMIOS_PWM_IP_SA_I1_CH4_CFG, &Emios_Pwm_Ip_Sa_I1_Ch4);
    Emios_Pwm_Ip_InitChannel(EMIOS_PWM_IP_SA_I1_CH3_CFG, &Emios_Pwm_Ip_Sa_I1_Ch3);
    Set_Motor_PWM(0.0f);
    PID_Init();

    Pit_Ip_Init(0, &PIT_0_InitConfig_PB);
    Pit_Ip_InitChannel(0, PIT_0_CH_2);
    Pit_Ip_EnableChannelInterrupt(0, 2);
    Pit_Ip_StartChannel(0, 2, 300000U);
#endif

    for (;;)
    {
        UART_Protocol_Service();
        Command_Service();                  /* muestreo 50 Hz + ventana + inferencia en MODE,RUN */
        if (UART_Protocol_PollLine(line, sizeof(line)) != 0)
        {
            Command_HandleLine(line);
        }
    }
}
