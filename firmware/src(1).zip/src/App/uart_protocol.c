#include "uart_protocol.h"
#include "ring_buffer.h"
#include <string.h>

/* ============================================================================
 * UART POR INTERRUPCIONES
 *
 *  RX : la recepción de 1 byte está SIEMPRE armada. En cada byte, el callback
 *       (interrupción) lo mete al anillo RX y re-arma. El main no tiene que
 *       estar mirando: aunque esté entrenando, los bytes se acumulan.
 *       El main saca las líneas del anillo con UART_Protocol_PollLine().
 *
 *  TX : UART_Protocol_SendLine() solo encola bytes (no bloquea salvo cola llena).
 *       UART_Protocol_Service() -que se llama desde el main y cada lote del
 *       entrenamiento- lanza AsyncSend por bloques de UART_TX_CHUNK. El callback
 *       solo marca "libre" cuando termina cada bloque.
 *       AsyncSend siempre se invoca desde el main, nunca desde la interrupción.
 * ============================================================================ */

static uint8_t           s_rx_byte;                       /* destino de la recepción de 1 byte */
static uint8_t           s_rx_store[UART_RX_RING_SIZE];
static RingBuffer        s_rx_ring;
static char              s_line_store[UART_RX_BUFFER_SIZE];
static LineReader        s_line;

static uint8_t           s_tx_store[UART_TX_RING_SIZE];
static RingBuffer        s_tx_ring;
static uint8_t           s_tx_chunk[UART_TX_CHUNK];
static volatile uint8_t  s_tx_busy = 0U;
static uint32_t          s_tx_start_us = 0U;

volatile uint32_t g_uart_rx_overflow = 0U;
volatile uint32_t g_uart_rx_errors   = 0U;
volatile uint32_t g_uart_tx_timeouts = 0U;
volatile uint32_t g_uart_tx_dropped  = 0U;

static void RxArm(void)
{
    Lpuart_Uart_Ip_SetRxBuffer(LPUART_INSTANCE, &s_rx_byte, 1U);
    Lpuart_Uart_Ip_AsyncReceive(LPUART_INSTANCE, &s_rx_byte, 1U);
}

void UART_Protocol_Init(void)
{
    Ring_Init(&s_rx_ring, s_rx_store, (uint16_t)sizeof(s_rx_store));
    Ring_Init(&s_tx_ring, s_tx_store, (uint16_t)sizeof(s_tx_store));
    LineReader_Init(&s_line, s_line_store, (uint16_t)sizeof(s_line_store));
    s_tx_busy = 0U;
    Lpuart_Uart_Ip_AsyncReceive(LPUART_INSTANCE, &s_rx_byte, 1U);
}

/* ---------------------------- interrupción ---------------------------- */
void Uart_Callback(const uint8 HwInstance,
                   const Lpuart_Uart_Ip_EventType Event,
                   const void *UserData)
{
    (void)HwInstance;
    (void)UserData;

    switch (Event)
    {
        case LPUART_UART_IP_EVENT_RX_FULL:
            if (Ring_Push(&s_rx_ring, s_rx_byte) != 0) { g_uart_rx_overflow++; }
            RxArm();                                  /* siempre listo para el siguiente byte */
            break;

        case LPUART_UART_IP_EVENT_ERROR:
            g_uart_rx_errors++;
            RxArm();
            break;

        case LPUART_UART_IP_EVENT_TX_EMPTY:

            break;
        case LPUART_UART_IP_EVENT_END_TRANSFER:
                    s_tx_busy=0U;
                    break;
        default:
            break;
    }
}

/* ------------------------------- RX (main) ------------------------------- */
int UART_Protocol_PollLine(char *dst, uint32_t max)
{
    return LineReader_Poll(&s_line, &s_rx_ring, dst, max);
}

/* ------------------------------- TX (main) ------------------------------- */
void UART_Protocol_Service(void)
{
    uint8_t b;
    uint16_t n = 0U;

    if (s_tx_busy != 0U)
    {
        /* salida de emergencia si el callback de fin de TX nunca llegó */
        if ((App_TimeUs() - s_tx_start_us) > UART_TX_TIMEOUT_US)
        {
            g_uart_tx_timeouts++;
            s_tx_busy = 0U;
        }
        else
        {
            return;
        }
    }

    while ((n < UART_TX_CHUNK) && (Ring_Pop(&s_tx_ring, &b) == 0))
    {
        s_tx_chunk[n++] = b;
    }
    if (n > 0U)
    {
        s_tx_start_us = App_TimeUs();
        s_tx_busy = 1U;
        (void)Lpuart_Uart_Ip_AsyncSend(LPUART_INSTANCE, s_tx_chunk, (uint32_t)n);
    }
}

static void TxPutByte(uint8_t b)
{
    uint32_t t0;
    if (Ring_Push(&s_tx_ring, b) == 0) { return; }

    /* cola llena: dejar que el hardware drene, con tiempo límite */
    t0 = App_TimeUs();
    while (Ring_Push(&s_tx_ring, b) != 0)
    {
        UART_Protocol_Service();
        if ((App_TimeUs() - t0) > UART_TX_TIMEOUT_US)
        {
            g_uart_tx_dropped++;
            return;
        }
    }
}

void UART_Protocol_SendLine(const char *s)
{
    while (*s != '\0') { TxPutByte((uint8_t)*s++); }
    TxPutByte((uint8_t)'\r');
    TxPutByte((uint8_t)'\n');
    UART_Protocol_Service();                          /* arranca la transmisión */
}
