#include "command_handler.h"
#include "app_config.h"
#include "app_io.h"
#include "rnn_model.h"
#include "rnn_trainer.h"
#include "rnn_live.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if (APP_ENABLE_MOTOR != 0) && !defined(APP_SIM)
#include "pid_control.h"
#define COMMAND_HAS_MOTOR 1
#endif

#define COMMAND_FW_VERSION  "rnn-train-0.2-online"

static char s_out[1024]; /* admite V + 150 valores (RNN_T=50) */
#define SEND(...)  do { (void)snprintf(s_out, sizeof(s_out), __VA_ARGS__); \
                        UART_Protocol_SendLine(s_out); } while (0)

/* ----------------------------------------------------------------------------
 * Utilidades de texto
 * ---------------------------------------------------------------------------- */
static char *next_tok(char **p)
{
    char *s = *p;
    char *c;
    if (s == NULL) { return NULL; }
    c = strchr(s, ',');
    if (c != NULL) { *c = '\0'; *p = c + 1; } else { *p = NULL; }
    return s;
}

static int parse_i32(const char *s, int32_t *out)
{
    int32_t v = 0;
    int neg = 0;
    if ((s == NULL) || (*s == '\0')) { return -1; }
    if (*s == '-') { neg = 1; s++; }
    if (*s == '\0') { return -1; }
    while (*s != '\0')
    {
        if ((*s < '0') || (*s > '9')) { return -1; }
        v = (v * 10) + (int32_t)(*s - '0');
        s++;
    }
    *out = neg ? -v : v;
    return 0;
}

static int parse_hex32(const char *s, uint32_t *out)
{
    uint32_t v = 0U;
    uint32_t n = 0U;
    if (s == NULL) { return -1; }
    while (*s != '\0')
    {
        char c = *s++;
        uint32_t d;
        if      ((c >= '0') && (c <= '9')) { d = (uint32_t)(c - '0'); }
        else if ((c >= 'A') && (c <= 'F')) { d = (uint32_t)(c - 'A') + 10U; }
        else if ((c >= 'a') && (c <= 'f')) { d = (uint32_t)(c - 'a') + 10U; }
        else { return -1; }
        v = (v << 4U) | d;
        if (++n > 8U) { return -1; }
    }
    if (n == 0U) { return -1; }
    *out = v;
    return 0;
}

static uint32_t f2bits(real_t f)
{
    uint32_t b;
    float x = (float)f;
    memcpy(&b, &x, sizeof(b));
    return b;
}

static real_t bits2f(uint32_t b)
{
    float x;
    memcpy(&x, &b, sizeof(x));
    return (real_t)x;
}

/* real -> entero escalado, seguro ante NaN / negativos / desbordes */
static uint32_t to_u32(real_t v, real_t scale)
{
    real_t s = v * scale;
    if (!(s >= (real_t)0.0)) { return (s != s) ? 0xFFFFFFFFU : 0U; }
    if (s > (real_t)4.0e9)   { return 4000000000U; }
    return (uint32_t)(s + (real_t)0.5);
}

/* ----------------------------------------------------------------------------
 * Comandos
 * ---------------------------------------------------------------------------- */
static void cmd_info(void)
{
    /* Mismo formato que la version anterior; los campos de dataset van en 0. */
    SEND("INFO,%s,%lu,%u,%u,%u,%u,%u,%lu,%lu,%u",
         COMMAND_FW_VERSION,
         (unsigned long)Trainer_NumParams(),
         (unsigned)RNN_H, (unsigned)RNN_D, (unsigned)RNN_C, (unsigned)RNN_T, (unsigned)RNN_M,
         (unsigned long)Trainer_MemoryBytes(),
         0UL,
         (unsigned)Trainer_IsEnabled());
}

static void cmd_norm(char *rest)
{
    real_t mean[RNN_M], std[RNN_M];
    uint32_t j;
    for (j = 0U; j < (2U * RNN_M); j++)
    {
        int32_t v;
        if (parse_i32(next_tok(&rest), &v) != 0) { SEND("ERR,norm"); return; }
        if (j < RNN_M) { mean[j] = (real_t)v / (real_t)1.0e6; }
        else           { std[j - RNN_M] = (real_t)v / (real_t)1.0e6; }
    }
    Trainer_SetNorm(mean, std);
    SEND("OK");
}

static void cmd_cfg(char *rest)
{
    int32_t lr, clip, batch;
    if ((parse_i32(next_tok(&rest), &lr) != 0)   ||
        (parse_i32(next_tok(&rest), &clip) != 0) ||
        (parse_i32(next_tok(&rest), &batch) != 0) ||
        (lr <= 0) || (clip < 0) || (batch < 1) || (batch > 64))
    {
        SEND("ERR,cfg");
        return;
    }
    Trainer_SetHyper((real_t)lr / (real_t)1.0e6, (real_t)clip / (real_t)1.0e6, (uint32_t)batch);
    SEND("OK");
}

/* TSEQ (train = 1) y PSEQ (train = 0): etiqueta + RNN_T*RNN_M valores uint8 */
static void cmd_seq_run(char *rest, int train)
{
    static uint8_t vals[TRAINER_SEQ_LEN];
    int32_t label, v;
    uint32_t k, pred = 0U, t0, us;
    real_t loss = (real_t)0.0;
    int rc = TRAINER_OK;

    if ((parse_i32(next_tok(&rest), &label) != 0) || (label < 0) || (label >= (int32_t)RNN_C))
    {
        SEND("ERR,seq_header");
        return;
    }
    for (k = 0U; k < TRAINER_SEQ_LEN; k++)
    {
        if ((parse_i32(next_tok(&rest), &v) != 0) || (v < 0) || (v > 255))
        {
            SEND("ERR,seq_len,%lu", (unsigned long)k);
            return;
        }
        vals[k] = (uint8_t)v;
    }

    t0 = App_TimeUs();
    if (train) { rc = Trainer_TrainSample(vals, (uint32_t)label, &loss, &pred); }
    else       { pred = Trainer_Predict(vals, (uint32_t)label, &loss, NULL); }
    us = App_TimeUs() - t0;                      /* solo calculo, sin UART */

    if (rc == TRAINER_ERR_LOCKED) { SEND("ERR,locked"); return; }
    if (rc != TRAINER_OK)         { SEND("ERR,train,%d", rc); return; }

    SEND("R,%lu,%lu,%lu",
         (unsigned long)to_u32(loss, (real_t)1.0e6),
         (unsigned long)pred,
         (unsigned long)us);
}

/* DUMP: manda los pesos como patrones de bits float32 en hexadecimal (sin perdida):
 *   W,indice_inicial,h0,..,h7      (8 por linea)
 *   N,mean0,mean1,mean2,std0,std1,std2
 *   DONE,dump,n_parametros                                                    */
static void cmd_dump(void)
{
    uint32_t i, j, n;
    int len;
    real_t mean[RNN_M], std[RNN_M];

    for (i = 0U; i < Trainer_NumParams(); i += 8U)
    {
        n = Trainer_NumParams() - i;
        if (n > 8U) { n = 8U; }
        len = snprintf(s_out, sizeof(s_out), "W,%lu", (unsigned long)i);
        for (j = 0U; j < n; j++)
        {
            len += snprintf(&s_out[len], sizeof(s_out) - (size_t)len, ",%08lX",
                            (unsigned long)f2bits(Trainer_GetParam(i + j)));
        }
        UART_Protocol_SendLine(s_out);
    }
    Trainer_GetNorm(mean, std);
    len = snprintf(s_out, sizeof(s_out), "N");
    for (j = 0U; j < RNN_M; j++)
        { len += snprintf(&s_out[len], sizeof(s_out) - (size_t)len, ",%08lX", (unsigned long)f2bits(mean[j])); }
    for (j = 0U; j < RNN_M; j++)
        { len += snprintf(&s_out[len], sizeof(s_out) - (size_t)len, ",%08lX", (unsigned long)f2bits(std[j])); }
    UART_Protocol_SendLine(s_out);
    SEND("DONE,dump,%lu", (unsigned long)Trainer_NumParams());
}

/* LOAD,indice_inicial,h0..hk (k<=7)   carga pesos (solo si el interruptor esta en TRAIN)
 * LOADN,m0,m1,m2,s0,s1,s2             carga media/desv. (hex float32)                    */
static void cmd_load(char *rest)
{
    int32_t start;
    uint32_t cnt = 0U, h;
    char *t;
    real_t vals[8];

    if ((parse_i32(next_tok(&rest), &start) != 0) || (start < 0)) { SEND("ERR,load_idx"); return; }
    while ((rest != NULL) && (cnt < 8U))
    {
        t = next_tok(&rest);
        if (parse_hex32(t, &h) != 0) { SEND("ERR,load_hex"); return; }
        vals[cnt++] = bits2f(h);
    }
    if ((cnt == 0U) || ((uint32_t)start + cnt > Trainer_NumParams())) { SEND("ERR,load_range"); return; }
    if (Trainer_IsEnabled() == 0U) { SEND("ERR,locked"); return; }
    for (h = 0U; h < cnt; h++) { (void)Trainer_SetParam((uint32_t)start + h, vals[h]); }
    SEND("OK");
}

static void cmd_loadn(char *rest)
{
    real_t v[2U * RNN_M];
    uint32_t j, h;
    for (j = 0U; j < (2U * RNN_M); j++)
    {
        if (parse_hex32(next_tok(&rest), &h) != 0) { SEND("ERR,loadn"); return; }
        v[j] = bits2f(h);
    }
    if (Trainer_IsEnabled() == 0U) { SEND("ERR,locked"); return; }
    Trainer_SetNorm(&v[0], &v[RNN_M]);
    SEND("OK");
}

#ifdef COMMAND_HAS_MOTOR
static void cmd_telemetry(void)
{
    /* SP_User, SP_Filtered, Current_RPM, PWM_Command */
    SEND("%.2f,%.2f,%.2f,%.2f",
         (double)Target_RPM_User, (double)Target_RPM_Filtered,
         (double)Current_RPM, (double)Last_Command_PWM);
}
#endif

/* ----------------------------------------------------------------------------
 * MODO RUN: muestras -> ventana -> clase -> referencia del motor
 * ---------------------------------------------------------------------------- */
static uint8_t s_run = 0U;
#ifdef APP_SIM
static uint8_t s_src_feed = 1U;          /* en el simulador las muestras entran por FEED */
#else
static uint8_t s_src_feed = 0U;          /* en el micro, por el ADC                      */
#endif
static const int32_t s_rpm_clase[RNN_C] = APP_RPM_POR_CLASE;
static int32_t s_rpm_actual = 0;

static void enter_run(void)
{
    Trainer_SetEnabled(0U);              /* RUN implica entrenamiento bloqueado */
    Live_Init();
    s_run = 1U;
}

/* Decide y actua. Devuelve 1 si se aplico la referencia. us_act = tiempo de la decision. */
static uint8_t apply_class(const LiveEvent *ev, uint32_t *us_act)
{
    uint32_t t0 = App_TimeUs();
    uint8_t apply = 0U;

    if (ev->conf >= (real_t)APP_CONF_MIN)
    {
        apply = ((ev->trigger == LIVE_TRIG_STATIC) && (ev->cls != 0U)) ? 0U : 1U;  /* quieto: solo STOP */
    }
    if (apply != 0U)
    {
        s_rpm_actual = s_rpm_clase[ev->cls];
#ifdef COMMAND_HAS_MOTOR
        Target_RPM_User = (float)s_rpm_actual;     /* referencia r(t) del PID */
#endif
    }
    *us_act = App_TimeUs() - t0;
    return apply;
}

static void process_sample(const real_t smp[RNN_M])
{
    LiveEvent ev;
    uint32_t t0, us_push, us_act = 0U, k;
    uint8_t aplicado;
    int e, len;

    t0 = App_TimeUs();
    e = Live_Push(smp, &ev);
    us_push = App_TimeUs() - t0;
    if (e != 0) { us_push -= ev.us_inf; }          /* tiempo de actualizar la ventana, sin la inferencia */

    if (e != 0)
    {
        len = snprintf(s_out, sizeof(s_out), "V");
        for (k = 0U; k < TRAINER_SEQ_LEN; k++)
        {
            len += snprintf(&s_out[len], sizeof(s_out) - (size_t)len, ",%u", (unsigned)ev.win[k]);
        }
        UART_Protocol_SendLine(s_out);

        aplicado = apply_class(&ev, &us_act);
        SEND("C,%u,%lu,%lu,%u,%ld,%u,%lu,%lu",
             (unsigned)ev.cls, (unsigned long)to_u32(ev.conf, (real_t)10000.0),
             (unsigned long)ev.us_inf, (unsigned)ev.trigger,
             (long)s_rpm_actual, (unsigned)aplicado, (unsigned long)us_act, (unsigned long)us_push);
    }

    /* La linea S va SIEMPRE al final: es el acuse de la muestra (V y C, si hay, la preceden). */
    SEND("S,%lu,%lu,%lu,%u,%lu,%lu",
         (unsigned long)to_u32(smp[0], (real_t)10000.0), (unsigned long)to_u32(smp[1], (real_t)10000.0),
         (unsigned long)to_u32(smp[2], (real_t)10000.0), (unsigned)Live_State(),
         (unsigned long)us_push, (unsigned long)Sensors_LastAcqUs());
}

void Command_Service(void)
{
#if (APP_ENABLE_SENSORS != 0)
    float smp[RNN_M];
    if ((s_run != 0U) && (s_src_feed == 0U) && (Sensors_Poll(smp) != 0))
    {
        process_sample(smp);
    }
#endif
}

static void cmd_feed(char *rest)
{
    real_t smp[RNN_M];
    int32_t v;
    uint32_t j;
    if ((s_run == 0U) || (s_src_feed == 0U)) { SEND("ERR,feed_mode"); return; }
    for (j = 0U; j < RNN_M; j++)
    {
        if (parse_i32(next_tok(&rest), &v) != 0) { SEND("ERR,feed"); return; }
        smp[j] = (real_t)v / (real_t)10000.0;
    }
    process_sample(smp);                  /* responde con la linea S (sirve de acuse) */
}

/* ----------------------------------------------------------------------------
 * API
 * ---------------------------------------------------------------------------- */
void Command_Init(void)
{
    Trainer_Init(1U);
#if (RNN_USE_FLASH_WEIGHTS != 0U)
Trainer_LoadFlash();
#endif

#if (APP_AUTORUN != 0) && (RNN_USE_FLASH_WEIGHTS != 0U)
enter_run();
#endif
    SEND("READY,%s", COMMAND_FW_VERSION);
}

void Command_HandleLine(char *line)
{
    char *rest = line;
    char *tok = next_tok(&rest);
    int32_t v;

    if (tok == NULL) { return; }

    if      (strcmp(tok, "PING")  == 0) { SEND("OK,PONG"); }
    else if (strcmp(tok, "INFO")  == 0) { cmd_info(); }
    else if (strcmp(tok, "NORM")  == 0) { cmd_norm(rest); }
    else if (strcmp(tok, "CFG")   == 0) { cmd_cfg(rest); }
    else if (strcmp(tok, "TSEQ")  == 0) { cmd_seq_run(rest, 1); }
    else if (strcmp(tok, "PSEQ")  == 0) { cmd_seq_run(rest, 0); }
    else if (strcmp(tok, "STEP")  == 0)
    {
        if (Trainer_Step() == TRAINER_OK) { SEND("OK"); } else { SEND("ERR,locked"); }
    }
    else if (strcmp(tok, "FEED")  == 0) { cmd_feed(rest); }
    else if (strcmp(tok, "SRC")   == 0)
    {
        char *m = next_tok(&rest);
        if      ((m != NULL) && (strcmp(m, "FEED") == 0)) { s_src_feed = 1U; SEND("OK,SRC,FEED"); }
        else if ((m != NULL) && (strcmp(m, "ADC")  == 0)) { s_src_feed = 0U; SEND("OK,SRC,ADC"); }
        else                                              { SEND("ERR,src"); }
    }
    else if (strcmp(tok, "LIVECFG") == 0)
    {
        if (parse_i32(next_tok(&rest), &v) != 0) { SEND("ERR,livecfg"); }
        else { Live_SetStatic((v != 0) ? 1U : 0U); SEND("OK"); }
    }
    else if (strcmp(tok, "DUMP")  == 0) { cmd_dump(); }
    else if (strcmp(tok, "LOAD")  == 0) { cmd_load(rest); }
    else if (strcmp(tok, "LOADN") == 0) { cmd_loadn(rest); }
    else if (strcmp(tok, "STOP")  == 0) { SEND("OK,idle"); }
    else if (strcmp(tok, "INIT")  == 0)
    {
        if (parse_i32(next_tok(&rest), &v) != 0) { v = 1; }
        Trainer_Init((uint32_t)v);
        SEND("OK");
    }
    else if (strcmp(tok, "MODE") == 0)
    {
        char *m = next_tok(&rest);
        if      ((m != NULL) && (strcmp(m, "TRAIN") == 0)) { s_run = 0U; Trainer_SetEnabled(1U); SEND("OK,MODE,TRAIN"); }
        else if ((m != NULL) && (strcmp(m, "LOCK")  == 0)) { s_run = 0U; Trainer_SetEnabled(0U); SEND("OK,MODE,LOCK"); }
        else if ((m != NULL) && (strcmp(m, "RUN")   == 0)) { enter_run(); SEND("OK,MODE,RUN"); }
        else                                               { SEND("ERR,mode"); }
    }
#ifdef COMMAND_HAS_MOTOR
    else if (((tok[0] == 'R') || (tok[0] == 'r')) && (tok[1] != '\0'))
    {
        Target_RPM_User = (float)atof(&tok[1]);
        SEND("[OK] Target RPM: %.2f", (double)Target_RPM_User);
    }
    else if (((tok[0] == 'S') || (tok[0] == 's')) && (tok[1] == '\0'))
    {
        Target_RPM_User = 0.0f;
        SEND("[OK] Motor Detenido");
    }
    else if (((tok[0] == 'T') || (tok[0] == 't')) && (tok[1] == '\0'))
    {
        cmd_telemetry();
    }
#endif
    else
    {
        SEND("ERR,unknown,%.20s", tok);
    }
}
