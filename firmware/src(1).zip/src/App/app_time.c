#include "app_io.h"
#include "OsIf.h"

/* ----------------------------------------------------------------------------
 * Reloj en microsegundos sobre el contador del sistema de OsIf.
 *
 * Se acumulan TICKS (no microsegundos) y solo se convierte la parte entera,
 * para no perder las fracciones cuando se llama muy seguido (por ejemplo en el
 * ciclo de espera del TX).
 * Supone que el contador corre a una frecuencia de MHz enteros (típico).
 * Hay que llamarlo antes de que el contador de OsIf dé una vuelta completa;
 * el entrenador lo llama en cada lote y el TX mientras espera.
 * ---------------------------------------------------------------------------- */
uint32_t App_TimeUs(void)
{
    static uint32_t s_ref = 0U;
    static uint32_t s_acc_ticks = 0U;
    static uint32_t s_us = 0U;
    static uint32_t s_ticks_per_us = 0U;

    if (s_ticks_per_us == 0U)
    {
        s_ticks_per_us = OsIf_MicrosToTicks(1000U, OSIF_COUNTER_SYSTEM) / 1000U;
        if (s_ticks_per_us == 0U) { s_ticks_per_us = 1U; }
        s_ref = OsIf_GetCounter(OSIF_COUNTER_SYSTEM);
    }

    s_acc_ticks += OsIf_GetElapsed(&s_ref, OSIF_COUNTER_SYSTEM);
    {
        uint32_t add = s_acc_ticks / s_ticks_per_us;
        s_acc_ticks -= add * s_ticks_per_us;
        s_us += add;
    }
    return s_us;
}
