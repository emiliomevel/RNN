#ifndef APP_UART_PROTOCOL_H_
#define APP_UART_PROTOCOL_H_

#include "Lpuart_Uart_Ip.h"
#include <stdint.h>
#include <stdbool.h>
#include "app_io.h"

/* LPUART6 (PTA15 / PTA16): el puerto con comunicación directa por el cable */
#ifndef LPUART_INSTANCE
#define LPUART_INSTANCE      (6U)
#endif

#define UART_RX_BUFFER_SIZE  1024U    /* TSEQ: 50x3 valores cuantizados + etiqueta */
#define UART_RX_RING_SIZE    1024U    /* bytes que la interrupción puede acumular       */
#define UART_TX_RING_SIZE    1024U    /* bytes pendientes de enviar                     */
#define UART_TX_CHUNK        64U      /* bytes por cada AsyncSend                       */
#define UART_TX_TIMEOUT_US   100000U

void UART_Protocol_Init(void);

/* Callback del driver. Su nombre debe coincidir con el configurado en el
 * Config Tools (LPUART6 -> Callback). */
void Uart_Callback(const uint8 HwInstance,
                   const Lpuart_Uart_Ip_EventType Event,
                   const void *UserData);

/* UART_Protocol_PollLine / SendLine / Service se declaran en app_io.h */

/* Diagnóstico (visibles en el depurador) */
extern volatile uint32_t g_uart_rx_overflow;   /* bytes perdidos porque el anillo RX se llenó */
extern volatile uint32_t g_uart_rx_errors;     /* errores de hardware (paridad, framing...)   */
extern volatile uint32_t g_uart_tx_timeouts;   /* TX que no terminó a tiempo                  */
extern volatile uint32_t g_uart_tx_dropped;    /* bytes descartados por cola TX llena         */

#endif /* APP_UART_PROTOCOL_H_ */
