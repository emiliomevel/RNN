#ifndef APP_IO_H_
#define APP_IO_H_

/* ============================================================================
 * ENTRADA/SALIDA DE LA APLICACIÓN (lo único que depende del hardware)
 * Implementaciones:  micro -> uart_protocol.c y app_time.c
 *                    PC    -> pc_sim/sim_io.c  (para probar el protocolo)
 * ============================================================================ */

#include <stdint.h>

/* 1 si hay una línea completa (sin el \n) y la copia en dst (máx. `max` con '\0'). No bloquea. */
int      UART_Protocol_PollLine(char *dst, uint32_t max);

/* Envía `s` + "\r\n". Espera (con tiempo límite) a que el TX esté libre. */
void     UART_Protocol_SendLine(const char *s);

/* Lanza la transmisión de lo que haya en cola. Se llama en el bucle del main y
 * durante tareas largas (el entrenador lo hace en cada lote). En el simulador no hace nada. */
void     UART_Protocol_Service(void);

/* Contador monotónico en µs (da la vuelta a los ~71 min). Llamarlo seguido. */
uint32_t App_TimeUs(void);

/* ---- Sensores (ADC de los 3 potenciometros) ---------------------------------
 * Sensors_Poll: devuelve 1 cuando toca una muestra nueva (cada 20 ms = 50 Hz) y la
 * entrega ya normalizada (0..1) y filtrada con el mismo EMA del recolector.
 * Implementaciones:  micro -> app_sensors.c     PC -> pc_sim/sim_io.c (devuelve 0)   */
int      Sensors_Poll(float s[3]);
uint32_t Sensors_LastAcqUs(void);      /* duracion de la ultima adquisicion (us) */

#endif /* APP_IO_H_ */
