#ifndef ML_RNN_TRAINER_H_
#define ML_RNN_TRAINER_H_

/* ============================================================================
 * ENTRENADOR EN LINEA (sin dataset en el micro)
 *
 * Python manda UNA secuencia a la vez (RNN_T x RNN_M valores uint8 = 60 bytes).
 *   - Trainer_TrainSample : forward + BPTT, acumula gradiente y aplica Adam
 *                           cada `batch` secuencias.  Solo funciona si el
 *                           interruptor esta en TRAIN.
 *   - Trainer_Predict     : SOLO forward. No toca pesos, gradientes ni Adam.
 *                           Es lo que se usa en validacion, test y en vivo.
 * ============================================================================ */

#include <stdint.h>
#include "rnn_model.h"

#define TRAINER_OK            0
#define TRAINER_ERR_LOCKED   (-1)

#define TRAINER_SEQ_LEN      (RNN_T * RNN_M)
#define TRAINER_SCALE        200.0f     /* uint8 = round(valor * 200), igual que el host */

void     Trainer_Init(uint32_t seed);                                  /* pesos nuevos      */
void     Trainer_SetHyper(real_t lr, real_t clip, uint32_t batch);
void     Trainer_SetNorm(const real_t mean[RNN_M], const real_t std[RNN_M]);
void     Trainer_GetNorm(real_t mean[RNN_M], real_t std[RNN_M]);       /* para inferencia en vivo */

/* Interruptor: 1 = se puede entrenar, 0 ("LOCK") = los pesos NO cambian. */
void     Trainer_SetEnabled(uint8_t enabled);
uint8_t  Trainer_IsEnabled(void);

int      Trainer_TrainSample(const uint8_t v[TRAINER_SEQ_LEN], uint32_t label,
                             real_t *loss, uint32_t *pred);
int      Trainer_Step(void);                                           /* cierra lote parcial */
uint32_t Trainer_Predict(const uint8_t v[TRAINER_SEQ_LEN], uint32_t label, real_t *loss,
                         real_t *conf);                                /* conf puede ser NULL */

/* Pesos como arreglo plano (orden de RnnParams: w_ih, w_hh, b, w1, b1, w2, b2).
 * SetParam respeta el interruptor: con LOCK devuelve TRAINER_ERR_LOCKED.        */
real_t   Trainer_GetParam(uint32_t i);
int      Trainer_SetParam(uint32_t i, real_t v);

#ifdef RNN_USE_FLASH_WEIGHTS
/* Copia a RAM los pesos y la normalizacion del header generado por Python (lstm_pesos.h). */
void     Trainer_LoadFlash(void);
#endif

uint32_t Trainer_NumParams(void);
uint32_t Trainer_MemoryBytes(void);                                    /* modelo + cache      */
const RnnModel *Trainer_Model(void);

#endif /* ML_RNN_TRAINER_H_ */
