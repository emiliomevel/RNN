#ifndef RNN_CFG_H
#define RNN_CFG_H

/* MODO DE PESOS:
 * 0U = entrenamiento desde Python (BPTT + Adam).
 * 1U = inferencia autonoma con pesos fijos de lstm_weights.h.
 */
#define RNN_USE_FLASH_WEIGHTS 0U
/* ============================================================================
 * DIMENSIONES DEL MODELO (se fijan en compilación: no hay malloc en el micro)
 *
 *   Entrada (RNN_T pasos x RNN_M sensores)
 *     -> LSTM (RNN_H unidades)
 *     -> Dense (RNN_D) + ReLU
 *     -> Dense (RNN_C) + softmax
 *
 * Deben coincidir con lo que se valida en Python (05_lstm.py):
 *   Dataset: 250 muestras a 50 Hz (5 s), submuestreo paso = 5 -> 50 pasos LSTM.
 *   No usar RNN_T=250 para entrenar sin optimizar primero RnnCache/linker.
 *
 * Nota sobre RNN_H: el estudio de neuronas dio acc_val 0.991 con 8 unidades
 * y 0.996 con 16 (dentro del ruido), pero 8 unidades usan ~4x menos memoria
 * y tiempo. El S32K312 tiene poca SRAM (~96 KB en total), por eso 8 es el
 * valor por defecto. Con -DRNN_H=16 se compila la versión grande.
 * ============================================================================ */

#ifndef RNN_M
#define RNN_M   3U     /* sensores (p1, p2, p3)                      */
#endif
#ifndef RNN_H
#define RNN_H   8U     /* unidades de la capa LSTM (ver nota abajo)  */
#endif
#ifndef RNN_D
#define RNN_D   8U     /* neuronas de la capa Dense intermedia       */
#endif
#ifndef RNN_C
#define RNN_C   5U     /* clases (0..4)                              */
#endif
#ifndef RNN_T
#define RNN_T   50U    /* 250 muestras crudas / paso 5 = 50 pasos LSTM */
#endif

#define RNN_G   (4U * RNN_H)   /* filas de compuertas: i, f, g, o (en ese orden) */

#endif /* RNN_CFG_H */
