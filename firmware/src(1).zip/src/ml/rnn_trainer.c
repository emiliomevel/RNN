#include "rnn_trainer.h"
#include <string.h>

static RnnModel s_model;
static RnnCache s_cache;

static real_t   s_lr      = (real_t)0.01;
static real_t   s_clip    = (real_t)1.0;
static uint32_t s_batch   = 16U;
static uint32_t s_pending = 0U;          /* secuencias acumuladas sin aplicar */
static uint8_t  s_enabled = 1U;

static real_t   s_mean[RNN_M];
static real_t   s_std[RNN_M];

/* uint8 -> real, normalizado con la media/desviacion del entrenamiento */
static void to_input(const uint8_t *p, real_t x[RNN_T][RNN_M])
{
    uint32_t t, j;
    for (t = 0U; t < RNN_T; t++)
    {
        for (j = 0U; j < RNN_M; j++)
        {
            real_t v = (real_t)p[t * RNN_M + j] / (real_t)TRAINER_SCALE;
            x[t][j] = (v - s_mean[j]) / s_std[j];
        }
    }
}

void Trainer_Init(uint32_t seed)
{
    uint32_t j;
    RNN_Init(&s_model, seed);
    s_pending = 0U;
    for (j = 0U; j < RNN_M; j++) { s_mean[j] = (real_t)0.0; s_std[j] = (real_t)1.0; }
}

void Trainer_SetHyper(real_t lr, real_t clip, uint32_t batch)
{
    s_lr = lr;
    s_clip = clip;
    s_batch = (batch == 0U) ? 1U : batch;
}

void Trainer_SetNorm(const real_t mean[RNN_M], const real_t std[RNN_M])
{
    uint32_t j;
    for (j = 0U; j < RNN_M; j++)
    {
        s_mean[j] = mean[j];
        s_std[j]  = (std[j] > (real_t)1.0e-6) ? std[j] : (real_t)1.0;
    }
}

void Trainer_GetNorm(real_t mean[RNN_M], real_t std[RNN_M])
{
    uint32_t j;
    for (j = 0U; j < RNN_M; j++) { mean[j] = s_mean[j]; std[j] = s_std[j]; }
}

void Trainer_SetEnabled(uint8_t enabled)
{
    s_enabled = (enabled != 0U) ? 1U : 0U;
    if (s_enabled == 0U)
    {
        RNN_ZeroGrad(&s_model);          /* al bloquear se descarta lo pendiente */
        s_pending = 0U;
    }
}

uint8_t Trainer_IsEnabled(void) { return s_enabled; }

int Trainer_TrainSample(const uint8_t v[TRAINER_SEQ_LEN], uint32_t label,
                        real_t *loss, uint32_t *pred)
{
    real_t x[RNN_T][RNN_M];

    if (s_enabled == 0U)    { return TRAINER_ERR_LOCKED; }
    if (label >= RNN_C)     { return -2; }

    to_input(v, x);
    *pred = RNN_Forward(&s_model, x, &s_cache);
    *loss = RNN_Loss(&s_cache, label);
    RNN_Backward(&s_model, &s_cache, label, (real_t)1.0 / (real_t)s_batch);

    s_pending++;
    if (s_pending >= s_batch)
    {
        RNN_AdamStep(&s_model, s_lr, s_clip);      /* un paso de pesos por lote */
        s_pending = 0U;
    }
    return TRAINER_OK;
}

int Trainer_Step(void)
{
    if (s_enabled == 0U) { return TRAINER_ERR_LOCKED; }
    if (s_pending > 0U)
    {
        /* lote incompleto: el gradiente se acumuló con 1/batch, se reescala */
        real_t *g = (real_t *)&s_model.g;
        real_t k = (real_t)s_batch / (real_t)s_pending;
        uint32_t i;
        for (i = 0U; i < RNN_NPARAMS; i++) { g[i] *= k; }
        RNN_AdamStep(&s_model, s_lr, s_clip);
        s_pending = 0U;
    }
    return TRAINER_OK;
}

/* SOLO forward: no hay Backward ni Adam en esta ruta. */
uint32_t Trainer_Predict(const uint8_t v[TRAINER_SEQ_LEN], uint32_t label, real_t *loss,
                         real_t *conf)
{
    real_t x[RNN_T][RNN_M];
    uint32_t pred;

    to_input(v, x);
    pred = RNN_Forward(&s_model, x, &s_cache);
    if (loss != 0) { *loss = (label < RNN_C) ? RNN_Loss(&s_cache, label) : (real_t)0.0; }
    if (conf != 0) { *conf = s_cache.prob[pred]; }
    return pred;
}

real_t Trainer_GetParam(uint32_t i)
{
    return (i < RNN_NPARAMS) ? ((const real_t *)&s_model.w)[i] : (real_t)0.0;
}

int Trainer_SetParam(uint32_t i, real_t v)
{
    if (s_enabled == 0U) { return TRAINER_ERR_LOCKED; }
    if (i >= RNN_NPARAMS) { return -2; }
    ((real_t *)&s_model.w)[i] = v;
    return TRAINER_OK;
}

#if (RNN_USE_FLASH_WEIGHTS != 0U)
#include "lstm_weights.h"      /* generado por Host_entrenamiento.py: pesos float en flash */

_Static_assert(sizeof(LSTM_W_IH) == sizeof(s_model.w.w_ih), "lstm_pesos.h: W_IH no coincide con rnn_cfg.h");
_Static_assert(sizeof(LSTM_W_HH) == sizeof(s_model.w.w_hh), "lstm_pesos.h: W_HH no coincide con rnn_cfg.h");
_Static_assert(sizeof(LSTM_B)    == sizeof(s_model.w.b),    "lstm_pesos.h: B no coincide con rnn_cfg.h");
_Static_assert(sizeof(LSTM_W1)   == sizeof(s_model.w.w1),   "lstm_pesos.h: W1 no coincide con rnn_cfg.h");
_Static_assert(sizeof(LSTM_B1)   == sizeof(s_model.w.b1),   "lstm_pesos.h: B1 no coincide con rnn_cfg.h");
_Static_assert(sizeof(LSTM_W2)   == sizeof(s_model.w.w2),   "lstm_pesos.h: W2 no coincide con rnn_cfg.h");
_Static_assert(sizeof(LSTM_B2)   == sizeof(s_model.w.b2),   "lstm_pesos.h: B2 no coincide con rnn_cfg.h");

void Trainer_LoadFlash(void)
{
    memcpy(s_model.w.w_ih, LSTM_W_IH, sizeof(LSTM_W_IH));
    memcpy(s_model.w.w_hh, LSTM_W_HH, sizeof(LSTM_W_HH));
    memcpy(s_model.w.b,    LSTM_B,    sizeof(LSTM_B));
    memcpy(s_model.w.w1,   LSTM_W1,   sizeof(LSTM_W1));
    memcpy(s_model.w.b1,   LSTM_B1,   sizeof(LSTM_B1));
    memcpy(s_model.w.w2,   LSTM_W2,   sizeof(LSTM_W2));
    memcpy(s_model.w.b2,   LSTM_B2,   sizeof(LSTM_B2));
    Trainer_SetNorm(LSTM_MEAN, LSTM_STD);
}
#endif

uint32_t Trainer_NumParams(void)   { return RNN_NPARAMS; }
uint32_t Trainer_MemoryBytes(void) { return (uint32_t)(sizeof(s_model) + sizeof(s_cache)); }
const RnnModel *Trainer_Model(void){ return &s_model; }
