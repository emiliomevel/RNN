#ifndef RNN_MODEL_H
#define RNN_MODEL_H

/* ============================================================================
 * NÚCLEO LSTM: forward, backward (BPTT) y Adam.
 * C puro: sin malloc, sin printf, sin dependencias del hardware.
 * Se puede compilar en PC (para pruebas) y en el micro sin cambios.
 *
 * Convención de pesos (igual que PyTorch, salvo que aquí hay UN solo sesgo
 * por compuerta, b = b_ih + b_hh):
 *   filas 0..H-1 = compuerta de entrada (i)   H..2H-1 = olvido (f)
 *   filas 2H..3H-1 = candidato (g)            3H..4H-1 = salida (o)
 * ============================================================================ */

#include <stdint.h>
#include "rnn_cfg.h"

#ifdef RNN_USE_DOUBLE
typedef double real_t;      /* solo para pruebas en PC (gradient check) */
#else
typedef float  real_t;      /* en el micro: precisión simple (FPU)       */
#endif

/* Todos los campos son real_t consecutivos, así que la estructura se puede
 * recorrer como un arreglo plano (Adam, norma del gradiente, envío a Python). */
typedef struct {
    real_t w_ih[RNN_G][RNN_M];
    real_t w_hh[RNN_G][RNN_H];
    real_t b   [RNN_G];
    real_t w1  [RNN_D][RNN_H];
    real_t b1  [RNN_D];
    real_t w2  [RNN_C][RNN_D];
    real_t b2  [RNN_C];
} RnnParams;

#define RNN_NPARAMS  ((uint32_t)(sizeof(RnnParams) / sizeof(real_t)))

typedef struct {
    RnnParams w;       /* pesos                                   */
    RnnParams g;       /* gradiente acumulado del lote            */
    RnnParams m;       /* Adam: primer momento                    */
    RnnParams v;       /* Adam: segundo momento                   */
    uint32_t   step;    /* contador de pasos de Adam               */
    uint32_t   rng;     /* estado del generador pseudoaleatorio    */
} RnnModel;

/* Valores intermedios de UNA secuencia. Hacen falta para la retropropagación. */
typedef struct {
    real_t x [RNN_T][RNN_M];        /* entrada normalizada               */
    real_t h [RNN_T + 1U][RNN_H];   /* h[t] = estado oculto ANTES del paso t */
    real_t c [RNN_T + 1U][RNN_H];
    real_t gi[RNN_T][RNN_H];        /* compuertas i, f, o y candidato g  */
    real_t gf[RNN_T][RNN_H];
    real_t gg[RNN_T][RNN_H];
    real_t go[RNN_T][RNN_H];
    real_t tc[RNN_T][RNN_H];        /* tanh(c_t)                         */
    real_t pre1[RNN_D];              /* antes de ReLU                     */
    real_t d1  [RNN_D];              /* después de ReLU                   */
    real_t prob[RNN_C];              /* salida softmax                    */
} RnnCache;

/* Inicializa pesos (uniforme +-1/sqrt(fan) como PyTorch), gradientes y Adam en 0. */
void   RNN_Init(RnnModel *mdl, uint32_t seed);

/* Pasada hacia adelante. Llena `k` y devuelve la clase con mayor probabilidad. */
uint32_t RNN_Forward(const RnnModel *mdl, const real_t x[RNN_T][RNN_M], RnnCache *k);

/* Entropía cruzada de la última pasada: -log(prob[label]). */
real_t RNN_Loss(const RnnCache *k, uint32_t label);

/* Retropropagación a través del tiempo. SUMA el gradiente de esta secuencia
 * (multiplicado por `scale`, normalmente 1/tamaño_de_lote) en mdl->g.         */
void   RNN_Backward(RnnModel *mdl, const RnnCache *k, uint32_t label, real_t scale);

void   RNN_ZeroGrad(RnnModel *mdl);
real_t RNN_GradNorm(const RnnModel *mdl);

/* Un paso del optimizador: recorta la norma global del gradiente a `clip`
 * (0 = sin recorte), aplica Adam y deja los gradientes en cero.              */
void   RNN_AdamStep(RnnModel *mdl, real_t lr, real_t clip);

#endif /* RNN_MODEL_H */
