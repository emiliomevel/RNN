#include "rnn_live.h"
#include "app_io.h"
#include <math.h>
#include <string.h>

static uint8_t  s_hist[LIVE_VENTANA][RNN_M];   /* ultimas LIVE_VENTANA muestras (uint8), circular */
static uint32_t s_wr;                          /* proxima posicion de escritura                    */
static real_t   s_recent[LIVE_N_BASE][RNN_M];  /* ultimas LIVE_N_BASE muestras (float), circular   */
static uint32_t s_rwr;
static uint32_t s_count;                       /* muestras recibidas                               */
static uint32_t s_calm_run;                    /* muestras seguidas quietas                         */
static uint32_t s_rec_left;                    /* muestras que faltan para cerrar la ventana        */
static real_t   s_base[RNN_M];
static uint8_t  s_state;
static uint8_t  s_static_en = 1U;
static uint8_t  s_static_done;

void Live_Init(void)
{
    memset(s_hist, 0, sizeof(s_hist));
    memset(s_recent, 0, sizeof(s_recent));
    s_wr = 0U; s_rwr = 0U; s_count = 0U; s_calm_run = 0U; s_rec_left = 0U;
    s_state = LIVE_ST_WARMUP; s_static_done = 0U;
}

void    Live_SetStatic(uint8_t enabled) { s_static_en = (enabled != 0U) ? 1U : 0U; }
uint8_t Live_State(void)                { return s_state; }

static uint8_t quant(real_t v)
{
    real_t q = v * (real_t)TRAINER_SCALE;
    if (q < (real_t)0.0)   { q = (real_t)0.0; }
    if (q > (real_t)255.0) { q = (real_t)255.0; }
    return (uint8_t)lrintf((float)q);
}

/* dispersion maxima (max-min) entre canales de las ultimas LIVE_N_BASE muestras */
static real_t spread10(void)
{
    uint32_t j, i;
    real_t worst = (real_t)0.0;
    for (j = 0U; j < RNN_M; j++)
    {
        real_t lo = s_recent[0][j], hi = s_recent[0][j];
        for (i = 1U; i < LIVE_N_BASE; i++)
        {
            if (s_recent[i][j] < lo) { lo = s_recent[i][j]; }
            if (s_recent[i][j] > hi) { hi = s_recent[i][j]; }
        }
        if ((hi - lo) > worst) { worst = hi - lo; }
    }
    return worst;
}

static void mean10(real_t out[RNN_M])
{
    uint32_t j, i;
    for (j = 0U; j < RNN_M; j++)
    {
        real_t a = (real_t)0.0;
        for (i = 0U; i < LIVE_N_BASE; i++) { a += s_recent[i][j]; }
        out[j] = a / (real_t)LIVE_N_BASE;
    }
}

/* arma la ventana desde la historia (de la mas vieja a la mas nueva) y clasifica */
static void clasificar(LiveEvent *ev, uint8_t trigger)
{
    uint32_t t, j;
    uint32_t t0;
    uint32_t pred;
    real_t conf;

    for (t = 0U; t < RNN_T; t++)
    {
        const uint8_t *m = s_hist[(s_wr + (t * LIVE_PASO)) % LIVE_VENTANA];   /* s_wr = la mas vieja */
        for (j = 0U; j < RNN_M; j++) { ev->win[(t * RNN_M) + j] = m[j]; }
    }
    t0 = App_TimeUs();
    pred = Trainer_Predict(ev->win, 0U, NULL, &conf);
    ev->us_inf = App_TimeUs() - t0;
    ev->cls = (uint8_t)pred;
    ev->conf = conf;
    ev->trigger = trigger;
}

int Live_Push(const real_t s[RNN_M], LiveEvent *ev)
{
    uint32_t j;
    int out = 0;
    real_t dev = (real_t)0.0;

    /* historia */
    for (j = 0U; j < RNN_M; j++)
    {
        s_hist[s_wr][j] = quant(s[j]);
        s_recent[s_rwr][j] = s[j];
    }
    s_wr = (s_wr + 1U) % LIVE_VENTANA;
    s_rwr = (s_rwr + 1U) % LIVE_N_BASE;
    s_count++;

    switch (s_state)
    {
    case LIVE_ST_WARMUP:
        if (s_count > (LIVE_WARMUP + LIVE_N_BASE)) { s_state = LIVE_ST_REARM; s_calm_run = 0U; }
        break;

    case LIVE_ST_REARM:                     /* espera a que las perillas esten quietas */
        if (spread10() < (real_t)LIVE_CALM) { s_calm_run++; } else { s_calm_run = 0U; }
        if (s_calm_run >= LIVE_REARM_CALM)       /* quieto el tiempo suficiente: el gesto termino */
        {
            mean10(s_base);
            s_state = LIVE_ST_ARMED;
            s_static_done = 0U;
        }
        break;

    case LIVE_ST_ARMED:
        for (j = 0U; j < RNN_M; j++)
        {
            real_t d = fabsf((float)(s[j] - s_base[j]));
            if (d > dev) { dev = d; }
        }
        if (dev > (real_t)LIVE_ONSET)       /* ONSET: la ventana ya incluye N_PRE muestras previas */
        {
            s_state = LIVE_ST_RECORDING;
            s_rec_left = LIVE_VENTANA - (LIVE_N_PRE + 1U);
            s_calm_run = 0U;
        }
        else if (spread10() < (real_t)LIVE_CALM)
        {
            mean10(s_base);                 /* sigue la deriva lenta del reposo */
            s_calm_run++;
            if ((s_static_en != 0U) && (s_static_done == 0U) && (s_calm_run >= LIVE_VENTANA))
            {
                clasificar(ev, LIVE_TRIG_STATIC);
                s_static_done = 1U;
                out = 1;
            }
        }
        else
        {
            s_calm_run = 0U;
        }
        break;

    case LIVE_ST_RECORDING:
        if (s_rec_left > 0U) { s_rec_left--; }
        if (s_rec_left == 0U)
        {
            clasificar(ev, LIVE_TRIG_ONSET);
            s_state = LIVE_ST_REARM;
            out = 1;
        }
        break;

    default:
        break;
    }
    return out;
}
