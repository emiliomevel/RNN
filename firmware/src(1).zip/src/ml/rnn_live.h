#ifndef ML_RNN_LIVE_H_
#define ML_RNN_LIVE_H_

/* ============================================================================
 * PIPELINE EN VIVO (sin hardware): muestras filtradas -> ventana -> clase
 *
 * Replica lo que hacia el recolector de datos (Dataset.py):
 *   - se ignoran las primeras LIVE_WARMUP muestras (el filtro EMA arranca en 0)
 *   - reposo = media de las ultimas LIVE_N_BASE muestras (quietas)
 *   - ONSET: alguna perilla se desvia mas de LIVE_ONSET respecto al reposo
 *   - la ventana arranca LIVE_N_PRE muestras antes del onset y dura LIVE_VENTANA
 *     muestras; se toma 1 de cada LIVE_PASO -> RNN_T pasos; uint8 = round(v*200)
 * Ademas, si LIVE_VENTANA muestras seguidas estan quietas (nadie toca las perillas)
 * se clasifica esa ventana UNA vez (disparo estatico = el "STOP" del dataset).
 * ============================================================================ */

#include <stdint.h>
#include "rnn_model.h"
#include "rnn_trainer.h"

#define LIVE_PASO        5U
#define LIVE_VENTANA     (RNN_T * LIVE_PASO)   /* 250 muestras a 50 Hz = 5 s cuando RNN_T=50 */
#define LIVE_WARMUP      40U
#define LIVE_N_BASE      10U
#define LIVE_N_PRE       5U
#define LIVE_ONSET       0.04f
#ifndef LIVE_REARM_CALM
#define LIVE_REARM_CALM  50U                  /* muestras quietas seguidas (1 s) para volver a armar tras un gesto */
#endif
#define LIVE_CALM        0.012f                /* dispersion maxima (10 muestras) para "quieto" */

#define LIVE_TRIG_ONSET    0U
#define LIVE_TRIG_STATIC   1U

#define LIVE_ST_WARMUP     0U
#define LIVE_ST_ARMED      1U
#define LIVE_ST_RECORDING  2U
#define LIVE_ST_REARM      3U

typedef struct
{
    uint8_t  win[TRAINER_SEQ_LEN];   /* la entrada exacta que vio la red (RNN_T x RNN_M) */
    uint8_t  trigger;                /* LIVE_TRIG_ONSET / LIVE_TRIG_STATIC               */
    uint8_t  cls;                    /* clase predicha                                   */
    real_t   conf;                   /* probabilidad de esa clase                        */
    uint32_t us_inf;                 /* tiempo del forward (us)                          */
} LiveEvent;

void    Live_Init(void);
void    Live_SetStatic(uint8_t enabled);
/* Procesa UNA muestra normalizada (0..~1) a 50 Hz. Devuelve 1 si hay un evento nuevo en *ev. */
int     Live_Push(const real_t s[RNN_M], LiveEvent *ev);
uint8_t Live_State(void);

#endif /* ML_RNN_LIVE_H_ */
