#include "rnn_model.h"
#include <math.h>
#include <string.h>

#ifdef RNN_USE_DOUBLE
#define R_EXP   exp
#define R_TANH  tanh
#define R_LOG   log
#define R_SQRT  sqrt
#define R_POW   pow
#else
#define R_EXP   expf
#define R_TANH  tanhf
#define R_LOG   logf
#define R_SQRT  sqrtf
#define R_POW   powf
#endif

#define H   RNN_H
#define M   RNN_M
#define D   RNN_D
#define C   RNN_C
#define T   RNN_T
#define G   RNN_G

/* ---------------------------------------------------------------------------
 * Utilidades
 * --------------------------------------------------------------------------- */
static real_t sigmoid(real_t x)
{
    return (real_t)1.0 / ((real_t)1.0 + R_EXP(-x));
}

/* xorshift32: generador simple y suficiente para inicializar pesos */
static uint32_t rng_next(uint32_t *s)
{
    uint32_t x = *s;
    x ^= x << 13U;
    x ^= x >> 17U;
    x ^= x << 5U;
    *s = x;
    return x;
}

/* uniforme en [-a, a] */
static real_t rng_uniform(uint32_t *s, real_t a)
{
    real_t u = (real_t)(rng_next(s) >> 8U) / (real_t)16777216.0;   /* [0,1) */
    return ((real_t)2.0 * u - (real_t)1.0) * a;
}

static void fill_uniform(real_t *p, uint32_t n, real_t a, uint32_t *s)
{
    uint32_t i;
    for (i = 0U; i < n; i++) { p[i] = rng_uniform(s, a); }
}

/* ---------------------------------------------------------------------------
 * Inicialización
 * --------------------------------------------------------------------------- */
void RNN_Init(RnnModel *mdl, uint32_t seed)
{
    uint32_t s = (seed == 0U) ? 0x9E3779B9U : seed;
    real_t aH = (real_t)1.0 / R_SQRT((real_t)H);
    real_t aD = (real_t)1.0 / R_SQRT((real_t)D);

    memset(mdl, 0, sizeof(*mdl));
    mdl->rng = s;

    fill_uniform(&mdl->w.w_ih[0][0], G * M, aH, &s);
    fill_uniform(&mdl->w.w_hh[0][0], G * H, aH, &s);
    fill_uniform(&mdl->w.b[0],       G,     aH, &s);
    fill_uniform(&mdl->w.w1[0][0],   D * H, aH, &s);   /* Linear(H, D): 1/sqrt(H) */
    fill_uniform(&mdl->w.b1[0],      D,     aH, &s);
    fill_uniform(&mdl->w.w2[0][0],   C * D, aD, &s);   /* Linear(D, C): 1/sqrt(D) */
    fill_uniform(&mdl->w.b2[0],      C,     aD, &s);
}

/* ---------------------------------------------------------------------------
 * Forward
 * --------------------------------------------------------------------------- */
uint32_t RNN_Forward(const RnnModel *mdl, const real_t x[RNN_T][RNN_M], RnnCache *k)
{
    const RnnParams *w = &mdl->w;
    real_t pre[G];
    real_t logits[C];
    real_t vmax, sum;
    uint32_t t, r, j, u, d, cl, best;

    memcpy(k->x, x, sizeof(k->x));
    memset(k->h[0], 0, sizeof(k->h[0]));
    memset(k->c[0], 0, sizeof(k->c[0]));

    for (t = 0U; t < T; t++)
    {
        /* a = W_ih * x_t + W_hh * h_(t-1) + b   (las 4H compuertas de golpe) */
        for (r = 0U; r < G; r++)
        {
            real_t a = w->b[r];
            for (j = 0U; j < M; j++) { a += w->w_ih[r][j] * k->x[t][j]; }
            for (j = 0U; j < H; j++) { a += w->w_hh[r][j] * k->h[t][j]; }
            pre[r] = a;
        }

        for (u = 0U; u < H; u++)
        {
            real_t i_ = sigmoid(pre[u]);
            real_t f_ = sigmoid(pre[H + u]);
            real_t g_ = R_TANH(pre[2U * H + u]);
            real_t o_ = sigmoid(pre[3U * H + u]);
            real_t c_ = f_ * k->c[t][u] + i_ * g_;          /* memoria de largo plazo */
            real_t tc = R_TANH(c_);

            k->gi[t][u] = i_;
            k->gf[t][u] = f_;
            k->gg[t][u] = g_;
            k->go[t][u] = o_;
            k->c[t + 1U][u] = c_;
            k->tc[t][u] = tc;
            k->h[t + 1U][u] = o_ * tc;                      /* lo que reporta la celda */
        }
    }

    /* Dense(D) + ReLU sobre el último estado oculto */
    for (d = 0U; d < D; d++)
    {
        real_t a = w->b1[d];
        for (j = 0U; j < H; j++) { a += w->w1[d][j] * k->h[T][j]; }
        k->pre1[d] = a;
        k->d1[d] = (a > (real_t)0.0) ? a : (real_t)0.0;
    }

    /* Dense(C) + softmax estable */
    vmax = (real_t)-1.0e30;
    for (cl = 0U; cl < C; cl++)
    {
        real_t a = w->b2[cl];
        for (d = 0U; d < D; d++) { a += w->w2[cl][d] * k->d1[d]; }
        logits[cl] = a;
        if (a > vmax) { vmax = a; }
    }
    sum = (real_t)0.0;
    for (cl = 0U; cl < C; cl++)
    {
        k->prob[cl] = R_EXP(logits[cl] - vmax);
        sum += k->prob[cl];
    }
    best = 0U;
    for (cl = 0U; cl < C; cl++)
    {
        k->prob[cl] /= sum;
        if (k->prob[cl] > k->prob[best]) { best = cl; }
    }
    return best;
}

real_t RNN_Loss(const RnnCache *k, uint32_t label)
{
    real_t p = k->prob[label];
    if (p < (real_t)1.0e-12) { p = (real_t)1.0e-12; }
    return -R_LOG(p);
}

/* ---------------------------------------------------------------------------
 * Backward (retropropagación a través del tiempo)
 * --------------------------------------------------------------------------- */
void RNN_Backward(RnnModel *mdl, const RnnCache *k, uint32_t label, real_t scale)
{
    RnnParams *g = &mdl->g;
    const RnnParams *w = &mdl->w;
    real_t dlog[C], dd1[D], dpre1[D], dh[H], dc[H], dhp[H], da[G];
    uint32_t t, r, j, u, d, cl;

    /* Softmax + entropía cruzada: dL/dlogits = p - onehot */
    for (cl = 0U; cl < C; cl++)
    {
        dlog[cl] = (k->prob[cl] - ((cl == label) ? (real_t)1.0 : (real_t)0.0)) * scale;
    }

    /* Dense(C) */
    for (d = 0U; d < D; d++) { dd1[d] = (real_t)0.0; }
    for (cl = 0U; cl < C; cl++)
    {
        g->b2[cl] += dlog[cl];
        for (d = 0U; d < D; d++)
        {
            g->w2[cl][d] += dlog[cl] * k->d1[d];
            dd1[d] += w->w2[cl][d] * dlog[cl];
        }
    }

    /* ReLU + Dense(D) */
    for (j = 0U; j < H; j++) { dh[j] = (real_t)0.0; }
    for (d = 0U; d < D; d++)
    {
        dpre1[d] = (k->pre1[d] > (real_t)0.0) ? dd1[d] : (real_t)0.0;
        g->b1[d] += dpre1[d];
        for (j = 0U; j < H; j++)
        {
            g->w1[d][j] += dpre1[d] * k->h[T][j];
            dh[j] += w->w1[d][j] * dpre1[d];
        }
    }

    /* BPTT: del último paso al primero. Los mismos pesos se usan en todos los
     * pasos, así que sus gradientes se SUMAN a lo largo del tiempo.            */
    for (u = 0U; u < H; u++) { dc[u] = (real_t)0.0; }

    for (t = T; t-- > 0U; )
    {
        for (u = 0U; u < H; u++)
        {
            real_t i_ = k->gi[t][u];
            real_t f_ = k->gf[t][u];
            real_t g_ = k->gg[t][u];
            real_t o_ = k->go[t][u];
            real_t tc = k->tc[t][u];

            /* h = o * tanh(c)  y  c = f*c_prev + i*g */
            real_t d_o  = dh[u] * tc;
            real_t dct  = dc[u] + dh[u] * o_ * ((real_t)1.0 - tc * tc);
            real_t d_i  = dct * g_;
            real_t d_g  = dct * i_;
            real_t d_f  = dct * k->c[t][u];

            da[u]            = d_i * i_ * ((real_t)1.0 - i_);        /* sigmoide */
            da[H + u]        = d_f * f_ * ((real_t)1.0 - f_);
            da[2U * H + u]   = d_g * ((real_t)1.0 - g_ * g_);        /* tanh     */
            da[3U * H + u]   = d_o * o_ * ((real_t)1.0 - o_);

            dc[u] = dct * f_;                                         /* hacia c_(t-1) */
        }

        for (j = 0U; j < H; j++) { dhp[j] = (real_t)0.0; }
        for (r = 0U; r < G; r++)
        {
            g->b[r] += da[r];
            for (j = 0U; j < M; j++) { g->w_ih[r][j] += da[r] * k->x[t][j]; }
            for (j = 0U; j < H; j++)
            {
                g->w_hh[r][j] += da[r] * k->h[t][j];
                dhp[j] += w->w_hh[r][j] * da[r];                      /* hacia h_(t-1) */
            }
        }
        for (j = 0U; j < H; j++) { dh[j] = dhp[j]; }
    }
}

/* ---------------------------------------------------------------------------
 * Optimizador
 * --------------------------------------------------------------------------- */
void RNN_ZeroGrad(RnnModel *mdl)
{
    memset(&mdl->g, 0, sizeof(mdl->g));
}

real_t RNN_GradNorm(const RnnModel *mdl)
{
    const real_t *p = (const real_t *)&mdl->g;
    real_t s = (real_t)0.0;
    uint32_t i;
    for (i = 0U; i < RNN_NPARAMS; i++) { s += p[i] * p[i]; }
    return R_SQRT(s);
}

void RNN_AdamStep(RnnModel *mdl, real_t lr, real_t clip)
{
    const real_t b1 = (real_t)0.9;
    const real_t b2 = (real_t)0.999;
    const real_t eps = (real_t)1.0e-8;
    real_t *w  = (real_t *)&mdl->w;
    real_t *gr = (real_t *)&mdl->g;
    real_t *m  = (real_t *)&mdl->m;
    real_t *v  = (real_t *)&mdl->v;
    real_t escala = (real_t)1.0;
    real_t c1, c2;
    uint32_t i;

    if (clip > (real_t)0.0)
    {
        real_t n = RNN_GradNorm(mdl);
        if (n > clip) { escala = clip / (n + (real_t)1.0e-6); }
    }

    mdl->step++;
    c1 = (real_t)1.0 - R_POW(b1, (real_t)mdl->step);    /* corrección de sesgo */
    c2 = (real_t)1.0 - R_POW(b2, (real_t)mdl->step);

    for (i = 0U; i < RNN_NPARAMS; i++)
    {
        real_t gi = gr[i] * escala;
        m[i] = b1 * m[i] + ((real_t)1.0 - b1) * gi;
        v[i] = b2 * v[i] + ((real_t)1.0 - b2) * gi * gi;
        w[i] -= lr * (m[i] / c1) / (R_SQRT(v[i] / c2) + eps);
    }
    RNN_ZeroGrad(mdl);
}
