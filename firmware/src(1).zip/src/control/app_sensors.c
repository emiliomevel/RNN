/* ============================================================================
 * SENSORES: 3 potenciometros por ADC0 (canales 0, 1, 2), 50 Hz, igual que el
 * firmware con el que se grabo el dataset:
 *   - conversion en cadena normal con notificacion de fin de cadena
 *   - normalizacion  raw / 2660  (SIN recortar)
 *   - filtro exponencial alpha = 0.15, que arranca en 0
 * La unica diferencia: el periodo de 20 ms sale del contador de microsegundos
 * (exacto) y no de un bucle de NOPs.
 * ============================================================================ */
#include "app_sensors.h"
#include "app_io.h"
#include "Adc_Sar_Ip.h"

#define ADC_SAR_POT1        0U
#define ADC_SAR_POT2        1U
#define ADC_SAR_POT3        2U
#define ADC_RAW_MAX_REAL    2660.0f
#define ADC_FILTER_ALPHA    0.15f
#define SAMPLE_PERIOD_US    20000U
#define ADC_TIMEOUT_US      2000U

static volatile boolean s_notif = FALSE;
static volatile uint16  s_pot[3];
static float            s_filt[3] = {0.0f, 0.0f, 0.0f};
static uint32_t         s_next_us;
static uint32_t         s_acq_us;

/* Nombre y firma IGUALES a los del recolector: es el callback de fin de cadena
 * que se asigna en el .mex (Adc_Sar_Ip -> AdcHwUnitNotifChainN). */
void AdcEndOfChainNotif(void)
{
    s_pot[0] = Adc_Sar_Ip_GetConvData(ADCHWUNIT_0_INSTANCE, ADC_SAR_POT1);
    s_pot[1] = Adc_Sar_Ip_GetConvData(ADCHWUNIT_0_INSTANCE, ADC_SAR_POT2);
    s_pot[2] = Adc_Sar_Ip_GetConvData(ADCHWUNIT_0_INSTANCE, ADC_SAR_POT3);
    s_notif = TRUE;
}

void Sensors_Init(void)
{
    uint8 i;
    Adc_Sar_Ip_Init(ADCHWUNIT_0_INSTANCE, &AdcHwUnit_0);
    for (i = 0U; i <= 5U; i++) { Adc_Sar_Ip_DoCalibration(ADCHWUNIT_0_INSTANCE); }
    Adc_Sar_Ip_EnableNotifications(ADCHWUNIT_0_INSTANCE, ADC_SAR_IP_NOTIF_FLAG_NORMAL_ENDCHAIN);
    s_next_us = App_TimeUs();
}

uint32_t Sensors_LastAcqUs(void) { return s_acq_us; }

int Sensors_Poll(float s[3])
{
    uint32_t now = App_TimeUs();
    uint32_t t0;
    uint32_t j;

    if ((int32_t)(now - s_next_us) < 0) { return 0; }          /* todavia no toca */
    s_next_us += SAMPLE_PERIOD_US;
    if ((int32_t)(now - s_next_us) > (int32_t)(5U * SAMPLE_PERIOD_US)) { s_next_us = now + SAMPLE_PERIOD_US; }

    s_notif = FALSE;
    t0 = App_TimeUs();
    Adc_Sar_Ip_StartConversion(ADCHWUNIT_0_INSTANCE, ADC_SAR_IP_CONV_CHAIN_NORMAL);
    while (s_notif != TRUE)
    {
        if ((App_TimeUs() - t0) > ADC_TIMEOUT_US) { return 0; }   /* ADC no respondio: se omite */
    }
    s_acq_us = App_TimeUs() - t0;

    for (j = 0U; j < 3U; j++)
    {
        float v = ((float)s_pot[j]) / ADC_RAW_MAX_REAL;
        s_filt[j] = (ADC_FILTER_ALPHA * v) + ((1.0f - ADC_FILTER_ALPHA) * s_filt[j]);
        s[j] = s_filt[j];
    }
    return 1;
}
