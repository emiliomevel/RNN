#ifndef CONTROL_PID_CONTROL_H_
#define CONTROL_PID_CONTROL_H_

#include "Emios_Pwm_Ip.h"
#include "Emios_Mcl_Ip.h"
#include <stdint.h>

/* Configuración de Hardware PWM eMIOS */
#define INSTANCE_0        ((uint8)1U)
#define CHANNEL_4         ((uint8)4U) /* PTA14 - Avanzar */
#define CHANNEL_3         ((uint8)3U) /* PTA13 - Retroceder */

/* Tiempos y Filtros */
#define SAMPLE_TIME_S     0.01f   /* Muestreo de 10 ms (100 Hz) */
#define TAU_REF_FILTER    0.2f    /* Constante de tiempo del filtro (200 ms) */

/* Límites de PWM */
#define PWM_MAX           1000.0f
#define PWM_MIN          -1000.0f

/* Estructura del Controlador PID */
typedef struct {
    float Kp;
    float Ki;
    float Kd;
    float integral;
    float prev_error;
} PIDController;

/* Variables Globales de Control Exportadas */
extern PIDController pid_speed;
extern volatile float Target_RPM_User;
extern volatile float Target_RPM_Filtered;
extern volatile float Current_RPM;
extern volatile float Last_Command_PWM;

/* Prototipos de Funciones */
void PID_Init(void);
float Compute_PID(PIDController *pid, float setpoint, float measured);
void Set_Motor_PWM(float command_pwm);
void Update_Filtered_Reference(void);
void Speed_Control_Task(void);
void PIT_Callback(void);

#endif /* CONTROL_PID_CONTROL_H_ */
