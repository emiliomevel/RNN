#include "pid_control.h"
#include "encoder.h"
#include <math.h>

#define RPM_CONVERSION_FACTOR ((60.0f / ENCODER_CPR) / SAMPLE_TIME_S)
static const float ALPHA_REF = SAMPLE_TIME_S / (TAU_REF_FILTER + SAMPLE_TIME_S);

PIDController pid_speed = {
    .Kp = 5.0f,
    .Ki = 0.5f,
    .Kd = 0.1f,
    .integral = 0.0f,
    .prev_error = 0.0f
};


volatile float Target_RPM_User = 0.0f;
volatile float Target_RPM_Filtered = 0.0f;
volatile float Current_RPM = 0.0f;
volatile float Last_Command_PWM = 0.0f;

static int32_t last_position = 0;

void PID_Init(void)
{
    pid_speed.integral = 0.0f;
    pid_speed.prev_error = 0.0f;
    Target_RPM_Filtered = Target_RPM_User;
    last_position = Encoder_Position;
}

float Compute_PID(PIDController *pid, float setpoint, float measured)
{
    float error = setpoint - measured;

    /* 1. Proporcional */
    float p_term = pid->Kp * error;

    /* 2. Integral con Clamp Anti-Windup */
    pid->integral += error * SAMPLE_TIME_S;
    float max_i_limit = 800.0f;
    if (pid->integral > max_i_limit)  pid->integral = max_i_limit;
    if (pid->integral < -max_i_limit) pid->integral = -max_i_limit;

    float i_term = pid->Ki * pid->integral;

    /* 3. Derivativo */
    float derivative = (error - pid->prev_error) / SAMPLE_TIME_S;
    float d_term = pid->Kd * derivative;

    pid->prev_error = error;

    /* 4. Salida Saturada */
    float output = p_term + i_term + d_term;
    if (output > PWM_MAX)       output = PWM_MAX;
    else if (output < PWM_MIN)  output = PWM_MIN;

    return output;
}

void Update_Filtered_Reference(void)
{
    Target_RPM_Filtered = (ALPHA_REF * Target_RPM_User) + ((1.0f - ALPHA_REF) * Target_RPM_Filtered);
}




void Set_Motor_PWM(float command_pwm)
{
    if (command_pwm > 0.0f)
    {
        Emios_Pwm_Ip_SetDutyCycle(INSTANCE_0, CHANNEL_3, 0U);
        Emios_Pwm_Ip_SetDutyCycle(INSTANCE_0, CHANNEL_4, (uint16_t)command_pwm);
    }
    else if (command_pwm < 0.0f)
    {
        Emios_Pwm_Ip_SetDutyCycle(INSTANCE_0, CHANNEL_4, 0U);
        Emios_Pwm_Ip_SetDutyCycle(INSTANCE_0, CHANNEL_3, (uint16_t)(-command_pwm));
    }
    else
    {
        Emios_Pwm_Ip_SetDutyCycle(INSTANCE_0, CHANNEL_4, 0U);
        Emios_Pwm_Ip_SetDutyCycle(INSTANCE_0, CHANNEL_3, 0U);
    }
}

void Speed_Control_Task(void)
{
    int32_t current_pos = Encoder_Position;
    int32_t delta_pos = current_pos - last_position;
    last_position = current_pos;

    Current_RPM = (float)delta_pos * RPM_CONVERSION_FACTOR;

    Update_Filtered_Reference();
    Last_Command_PWM = Compute_PID(&pid_speed, Target_RPM_Filtered, Current_RPM);
    Set_Motor_PWM(Last_Command_PWM);

    if ((Target_RPM_User == 0.0f) && (fabsf(Target_RPM_Filtered) < 5.0f)){
        pid_speed.integral = 0.0f;
        pid_speed.prev_error = 0.0f;
        Last_Command_PWM = 0.0f;
        Set_Motor_PWM(0.0f);
        return;
    }
}

void PIT_Callback(void)
{
    Speed_Control_Task();
}
