#include "encoder.h"

volatile int32_t Encoder_Position = 0;
volatile uint8_t Encoder_Direction = 0; /* 1: CW, 0: CCW */

static volatile uint8_t u8LastState = 0U;

static inline uint8_t Read_Pin_A_Fast(void)
{
    return (uint8_t)Siul2_Dio_Ip_ReadPin(Canal_A_PORT, Canal_A_PIN);
}

static inline uint8_t Read_Pin_B_Fast(void)
{
    return (uint8_t)Siul2_Dio_Ip_ReadPin(Canal_B_PORT, Canal_B_PIN);
}

static inline void Process_Encoder_Quadrature(void)
{
    static const int8_t QuadratureTable[16] = {
         0,  1, -1,  0,
        -1,  0,  0,  1,
         1,  0,  0, -1,
         0, -1,  1,  0
    };

    uint8_t u8CurrentState = (Read_Pin_A_Fast() << 1U) | Read_Pin_B_Fast();
    uint8_t u8Index = (u8LastState << 2U) | u8CurrentState;

    int8_t s8Step = QuadratureTable[u8Index];

    if (s8Step != 0)
    {
        Encoder_Position += s8Step;
        Encoder_Direction = (uint8_t)(s8Step > 0 ? 1U : 0U);
    }

    u8LastState = u8CurrentState;
}

void Encoder_Init(void)
{
    u8LastState = (Read_Pin_A_Fast() << 1U) | Read_Pin_B_Fast();
}

void ENCODER_A(void)
{
    Process_Encoder_Quadrature();
}

void ENCODER_B(void)
{
    Process_Encoder_Quadrature();
}
