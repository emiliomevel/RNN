#ifndef APP_SENSORS_H_
#define APP_SENSORS_H_
/* Solo para el micro: inicializa ADC0 (3 potenciometros). Sensors_Poll esta en app_io.h */
void Sensors_Init(void);
#endif
