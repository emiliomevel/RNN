#ifndef CONTROL_ENCODER_H_
#define CONTROL_ENCODER_H_

#include "Siul2_Dio_Ip.h"
#include "Siul2_Port_Ip_Cfg.h"
#include <stdint.h>


/* Parámetros cinemáticos del Encoder */
#define ENCODER_CPR       3332.0f /* 17 * 4 * 49 */

/* Variables exportadas */
extern volatile int32_t Encoder_Position;
extern volatile uint8_t Encoder_Direction;

/* Prototipos de Funciones */
void Encoder_Init(void);
void ENCODER_A(void);
void ENCODER_B(void);
int32_t Encoder_GetPositionAndResetDelta(void);

#endif /* CONTROL_ENCODER_H_ */
